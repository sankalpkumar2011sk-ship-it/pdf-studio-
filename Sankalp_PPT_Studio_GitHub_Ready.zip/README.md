# Sankalp PPT Studio

Android PowerPoint presentation maker, slide editor, viewer, template gallery, and PDF exporter.

## Download the Android app

The APK included with this project is:

`app/src/ppt.apk`

After publishing this repository, create a GitHub Release and attach this APK as a release asset. Users can then download the APK from the repository's **Releases** page.

## Source code

The Android application source is under `app/src/main/java/`.

## Project structure

- `app/src/main/java/` — Kotlin application source
- `app/src/main/res/` — Android resources, fonts, and launcher icons
- `app/src/main/AndroidManifest.xml` — Android manifest
- `app/build.gradle.kts` — app build configuration
- `gradle/libs.versions.toml` — dependency versions
- `app/src/ppt.apk` — included Android APK

## Build note

This archive contains `gradle/wrapper/gradle-wrapper.properties`, but does not include the Gradle wrapper launcher files (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar`). The included APK can still be downloaded directly. To build from source, open the project in Android Studio with a compatible Gradle installation or add the standard Gradle Wrapper files.

## Secrets and signing

Do not commit real API keys, passwords, signing keystores, or `.env` files. `.env.example` is a placeholder template only. Keep release signing credentials private.
