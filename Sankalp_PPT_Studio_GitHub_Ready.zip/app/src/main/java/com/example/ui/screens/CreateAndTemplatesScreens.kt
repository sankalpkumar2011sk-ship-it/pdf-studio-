package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.PresentationTemplateInfo
import com.example.data.TemplateCatalog
import com.example.engine.SlideRendererAndPdfExporter
import com.example.model.BuiltInThemes
import com.example.model.PresentationTheme
import com.example.model.SlideAspectRatio

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePresentationScreen(
    defaultRatio: SlideAspectRatio,
    defaultThemeId: String,
    onBack: () -> Unit,
    onCreateBlank: (String, SlideAspectRatio, String, Float, Float) -> Unit,
    onOpenTemplateGallery: () -> Unit
) {
    BackHandler { onBack() }

    var presentationName by remember { mutableStateOf("Executive Strategy Deck") }
    var selectedRatio by remember { mutableStateOf(defaultRatio) }
    var customWidthText by remember { mutableStateOf("960") }
    var customHeightText by remember { mutableStateOf("600") }
    var selectedThemeId by remember { mutableStateOf(defaultThemeId) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create New Presentation", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("create_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                OutlinedTextField(
                    value = presentationName,
                    onValueChange = { presentationName = it },
                    label = { Text("Presentation Name") },
                    placeholder = { Text("Enter presentation title...") },
                    leadingIcon = { Icon(Icons.Default.Title, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("presentation_name_input")
                )
            }

            // Starting Mode: Blank vs Template Gallery
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "1. Starting Structure",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Icon(Icons.Default.Crop169, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Blank Presentation", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                Text("Clean title & content slides", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        OutlinedCard(
                            onClick = onOpenTemplateGallery,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("choose_template_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Icon(Icons.Default.AutoAwesomeMosaic, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Choose a Template", fontWeight = FontWeight.Bold)
                                Text("Browse 21 ready decks", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }

            // Aspect Ratio Selection
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "2. Slide Aspect Ratio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SlideAspectRatio.entries.forEach { ratio ->
                            val isSelected = selectedRatio == ratio
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedRatio = ratio },
                                label = { Text(ratio.label) },
                                leadingIcon = if (isSelected) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                } else null,
                                modifier = Modifier.testTag("ratio_chip_${ratio.name}")
                            )
                        }
                    }
                    if (selectedRatio == SlideAspectRatio.CUSTOM) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = customWidthText,
                                onValueChange = { customWidthText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Width (pt)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = customHeightText,
                                onValueChange = { customHeightText = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Height (pt)") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Initial Theme Selector (9 Built-in Themes)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "3. Presentation Theme (${BuiltInThemes.ALL.size} Themes)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    BuiltInThemes.ALL.chunked(3).forEach { rowThemes ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowThemes.forEach { theme ->
                                ThemePreviewSelectorCard(
                                    theme = theme,
                                    isSelected = selectedThemeId == theme.id,
                                    onClick = { selectedThemeId = theme.id },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        val cw = customWidthText.toFloatOrNull()?.coerceIn(360f, 1920f) ?: 960f
                        val ch = customHeightText.toFloatOrNull()?.coerceIn(240f, 1440f) ?: 600f
                        onCreateBlank(presentationName, selectedRatio, selectedThemeId, cw, ch)
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("confirm_create_presentation_button")
                ) {
                    Icon(Icons.Default.RocketLaunch, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Start Editing Presentation", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun ThemePreviewSelectorCard(
    theme: PresentationTheme,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = Color(SlideRendererAndPdfExporter.parseColorSafe(theme.bgHex))
    val titleColor = Color(SlideRendererAndPdfExporter.parseColorSafe(theme.titleColorHex))
    val accentColor = Color(SlideRendererAndPdfExporter.parseColorSafe(theme.primaryAccentHex))
    val secondaryColor = Color(SlideRendererAndPdfExporter.parseColorSafe(theme.secondaryAccentHex))

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .border(
                width = if (isSelected) 2.5.dp else 1.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("theme_card_${theme.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(bgColor)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(accentColor))
                Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(secondaryColor))
            }
            Text(
                text = "Aa",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )
            Text(
                text = theme.name,
                style = MaterialTheme.typography.labelMedium,
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesGalleryScreen(
    onBack: () -> Unit,
    onSelectTemplate: (PresentationTemplateInfo) -> Unit
) {
    BackHandler { onBack() }

    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    val filteredTemplates = remember(selectedCategory, searchQuery) {
        TemplateCatalog.TEMPLATES.filter { tpl ->
            val matchesCat = selectedCategory == "All" || tpl.category.equals(selectedCategory, ignoreCase = true)
            val matchesSearch = searchQuery.isBlank() ||
                tpl.title.contains(searchQuery, ignoreCase = true) ||
                tpl.category.contains(searchQuery, ignoreCase = true) ||
                tpl.subtitle.contains(searchQuery, ignoreCase = true)
            matchesCat && matchesSearch
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Template Gallery (${TemplateCatalog.TEMPLATES.size})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("templates_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search 21 editable templates by category or topic...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TemplateCatalog.CATEGORIES) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat) },
                        modifier = Modifier.testTag("template_cat_$cat")
                    )
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 168.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredTemplates, key = { it.id }) { tpl ->
                    val bgCol = Color(SlideRendererAndPdfExporter.parseColorSafe(tpl.bgHex))
                    val accCol = Color(SlideRendererAndPdfExporter.parseColorSafe(tpl.accentHex))
                    val theme = BuiltInThemes.getById(tpl.themeId)
                    val txtCol = Color(SlideRendererAndPdfExporter.parseColorSafe(theme.titleColorHex))

                    Card(
                        onClick = { onSelectTemplate(tpl) },
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("template_item_${tpl.id}")
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .background(bgCol)
                                    .padding(12.dp)
                            ) {
                                Surface(
                                    color = accCol,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = tpl.category,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Column(modifier = Modifier.align(Alignment.BottomStart)) {
                                    Text(
                                        text = tpl.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = txtCol,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "5 Editable Slides • Charts & Tables",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = txtCol.copy(alpha = 0.72f)
                                    )
                                }
                            }
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = tpl.subtitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Text(
                                        text = "Use Template →",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
