package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.*

@Composable
fun ImageEditingPanel(
    element: SlideElement?,
    onPickGalleryImage: () -> Unit,
    onPickDocumentImage: () -> Unit,
    onTakeCameraPhoto: () -> Unit,
    onReplaceGalleryImage: () -> Unit,
    onUpdateElement: ((SlideElement) -> SlideElement) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onPickGalleryImage,
                modifier = Modifier
                    .weight(1f)
                    .testTag("insert_image_gallery_button")
            ) {
                Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gallery")
            }
            OutlinedButton(
                onClick = onPickDocumentImage,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Files")
            }
            OutlinedButton(
                onClick = onTakeCameraPhoto,
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PhotoCamera, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Camera")
            }
        }

        if (element != null && element.type == ElementType.IMAGE) {
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = onReplaceGalleryImage) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Replace")
                }
                OutlinedButton(onClick = { onUpdateElement { it.copy(flipHorizontal = !it.flipHorizontal) } }) {
                    Icon(Icons.Default.Flip, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Flip H")
                }
                OutlinedButton(onClick = { onUpdateElement { it.copy(flipVertical = !it.flipVertical) } }) {
                    Text("Flip V")
                }
                OutlinedButton(onClick = { onUpdateElement { it.copy(rotation = (it.rotation + 90f) % 360f) } }) {
                    Icon(Icons.Default.RotateRight, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Rotate 90°")
                }
            }

            Text("Crop Image Margins (${(element.cropLeft * 100).toInt()}%)", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = element.cropLeft,
                onValueChange = { c ->
                    onUpdateElement {
                        it.copy(cropLeft = c, cropRight = c, cropTop = c * 0.8f, cropBottom = c * 0.8f)
                    }
                },
                valueRange = 0f..0.35f,
                modifier = Modifier.testTag("image_crop_slider")
            )

            Text("Transparency (${(element.opacity * 100).toInt()}%)", style = MaterialTheme.typography.labelMedium)
            Slider(
                value = element.opacity,
                onValueChange = { op -> onUpdateElement { it.copy(opacity = op) } },
                valueRange = 0.15f..1f
            )

            Text("Border Color & Thickness", style = MaterialTheme.typography.labelMedium)
            ColorSwatchRow(
                selectedHex = element.borderColorHex,
                allowClear = true,
                onClear = { onUpdateElement { it.copy(borderColorHex = null, borderWidth = 0f) } },
                onSelectColor = { hex -> onUpdateElement { it.copy(borderColorHex = hex, borderWidth = it.borderWidth.coerceAtLeast(3f)) } }
            )
        }
    }
}

@Composable
fun ShapesLibraryPanel(
    element: SlideElement?,
    onInsertShape: (ShapeKind) -> Unit,
    onOpenFreehandPad: () -> Unit,
    onUpdateElement: ((SlideElement) -> SlideElement) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Insert Shape (20 Shapes + Freehand)", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = onOpenFreehandPad) {
                Icon(Icons.Default.Draw, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Freehand Draw")
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ShapeKind.entries.filter { it != ShapeKind.FREEHAND }.forEach { kind ->
                AssistChip(
                    onClick = { onInsertShape(kind) },
                    label = { Text(kind.label) },
                    modifier = Modifier.testTag("insert_shape_${kind.name}")
                )
            }
        }

        if (element != null && element.type == ElementType.SHAPE) {
            HorizontalDivider()
            Text("Shape Fill Color", style = MaterialTheme.typography.labelMedium)
            ColorSwatchRow(
                selectedHex = element.fillColorHex,
                onSelectColor = { hex -> onUpdateElement { it.copy(fillColorHex = hex) } }
            )

            Text("Gradient Fill End Color (Optional)", style = MaterialTheme.typography.labelMedium)
            ColorSwatchRow(
                selectedHex = element.gradientEndColorHex,
                allowClear = true,
                onClear = { onUpdateElement { it.copy(gradientEndColorHex = null) } },
                onSelectColor = { hex -> onUpdateElement { it.copy(gradientEndColorHex = hex) } }
            )

            Text("Border Color", style = MaterialTheme.typography.labelMedium)
            ColorSwatchRow(
                selectedHex = element.borderColorHex,
                allowClear = true,
                onClear = { onUpdateElement { it.copy(borderColorHex = null, borderWidth = 0f) } },
                onSelectColor = { hex -> onUpdateElement { it.copy(borderColorHex = hex, borderWidth = it.borderWidth.coerceAtLeast(2.5f)) } }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = element.hasShadow,
                    onClick = { onUpdateElement { it.copy(hasShadow = !it.hasShadow) } },
                    label = { Text("Drop Shadow") }
                )
                OutlinedTextField(
                    value = element.text,
                    onValueChange = { txt -> onUpdateElement { it.copy(text = txt) } },
                    label = { Text("Shape Text Label") },
                    singleLine = true,
                    modifier = Modifier.width(200.dp)
                )
            }
        }
    }
}

@Composable
fun TableEditingPanel(
    element: SlideElement?,
    onInsertTable: (Int, Int) -> Unit,
    onUpdateElement: ((SlideElement) -> SlideElement) -> Unit
) {
    var newRows by remember { mutableIntStateOf(3) }
    var newCols by remember { mutableIntStateOf(3) }
    var selectedRow by remember { mutableIntStateOf(0) }
    var selectedCol by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (element == null || element.type != ElementType.TABLE) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Rows: $newRows", fontWeight = FontWeight.SemiBold)
                Row {
                    IconButton(onClick = { newRows = (newRows - 1).coerceAtLeast(1) }) { Icon(Icons.Default.Remove, null) }
                    IconButton(onClick = { newRows = (newRows + 1).coerceAtMost(8) }) { Icon(Icons.Default.Add, null) }
                }
                Text("Cols: $newCols", fontWeight = FontWeight.SemiBold)
                Row {
                    IconButton(onClick = { newCols = (newCols - 1).coerceAtLeast(1) }) { Icon(Icons.Default.Remove, null) }
                    IconButton(onClick = { newCols = (newCols + 1).coerceAtMost(6) }) { Icon(Icons.Default.Add, null) }
                }
                Button(
                    onClick = { onInsertTable(newRows, newCols) },
                    modifier = Modifier.testTag("confirm_insert_table_button")
                ) {
                    Text("Insert Table")
                }
            }
            return
        }

        val rSafe = selectedRow.coerceIn(0, (element.tableRows - 1).coerceAtLeast(0))
        val cSafe = selectedCol.coerceIn(0, (element.tableCols - 1).coerceAtLeast(0))
        val currentCellText = element.tableCells.getOrNull(rSafe)?.getOrNull(cSafe) ?: ""

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = {
                val nextRows = element.tableRows + 1
                val newRow = List(element.tableCols) { "Cell" }
                onUpdateElement { it.copy(tableRows = nextRows, tableCells = it.tableCells + listOf(newRow), height = it.height + 42f) }
            }) { Text("+ Row") }

            OutlinedButton(onClick = {
                if (element.tableRows > 1) {
                    onUpdateElement { it.copy(tableRows = it.tableRows - 1, tableCells = it.tableCells.dropLast(1)) }
                }
            }) { Text("- Row") }

            OutlinedButton(onClick = {
                val nextCols = element.tableCols + 1
                val updated = element.tableCells.mapIndexed { rIdx, row ->
                    row + (if (rIdx == 0) "Header $nextCols" else "Cell")
                }
                onUpdateElement { it.copy(tableCols = nextCols, tableCells = updated) }
            }) { Text("+ Column") }

            OutlinedButton(onClick = {
                if (element.tableCols > 1) {
                    val updated = element.tableCells.map { it.dropLast(1) }
                    onUpdateElement { it.copy(tableCols = it.tableCols - 1, tableCells = updated) }
                }
            }) { Text("- Column") }

            FilterChip(
                selected = element.tableMergedFirstRow,
                onClick = { onUpdateElement { it.copy(tableMergedFirstRow = !it.tableMergedFirstRow) } },
                label = { Text("Merge Header") }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Cell [R${rSafe + 1}, C${cSafe + 1}]:", fontWeight = FontWeight.Bold)
            IconButton(onClick = { selectedRow = (rSafe + 1) % element.tableRows }) {
                Icon(Icons.Default.SwapVert, contentDescription = "Next Row")
            }
            IconButton(onClick = { selectedCol = (cSafe + 1) % element.tableCols }) {
                Icon(Icons.Default.SwapHoriz, contentDescription = "Next Column")
            }
            OutlinedTextField(
                value = currentCellText,
                onValueChange = { txt ->
                    val updated = element.tableCells.mapIndexed { r, row ->
                        if (r != rSafe) row else row.mapIndexed { c, cell -> if (c == cSafe) txt else cell }
                    }
                    onUpdateElement { it.copy(tableCells = updated) }
                },
                label = { Text("Edit Cell Value") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
        }

        Text("Header Background Color", style = MaterialTheme.typography.labelMedium)
        ColorSwatchRow(
            selectedHex = element.tableHeaderBgHex,
            onSelectColor = { hex -> onUpdateElement { it.copy(tableHeaderBgHex = hex) } }
        )
    }
}

@Composable
fun BackgroundAndDesignPanel(
    slide: SlideModel,
    currentThemeId: String,
    onUpdateBackground: (SlideBackground, Boolean) -> Unit,
    onPickBackgroundImage: () -> Unit,
    onApplyTheme: (String, Boolean) -> Unit,
    onChangeLayout: (SlideLayoutType) -> Unit
) {
    var applyToAll by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Slide Background & Theme", fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = applyToAll, onCheckedChange = { applyToAll = it })
                Text("Apply to All Slides", style = MaterialTheme.typography.labelMedium)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = slide.background.type == BackgroundType.SOLID,
                onClick = { onUpdateBackground(slide.background.copy(type = BackgroundType.SOLID), applyToAll) },
                label = { Text("Solid") }
            )
            FilterChip(
                selected = slide.background.type == BackgroundType.GRADIENT,
                onClick = { onUpdateBackground(slide.background.copy(type = BackgroundType.GRADIENT), applyToAll) },
                label = { Text("Gradient") }
            )
            OutlinedButton(onClick = onPickBackgroundImage) {
                Icon(Icons.Default.Image, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Image BG")
            }
        }

        Text("Background Color", style = MaterialTheme.typography.labelMedium)
        ColorSwatchRow(
            selectedHex = slide.background.colorHex,
            onSelectColor = { hex ->
                onUpdateBackground(slide.background.copy(colorHex = hex), applyToAll)
            }
        )

        if (slide.background.type == BackgroundType.GRADIENT) {
            Text("Gradient Second Color", style = MaterialTheme.typography.labelMedium)
            ColorSwatchRow(
                selectedHex = slide.background.gradientEndHex,
                onSelectColor = { hex ->
                    onUpdateBackground(slide.background.copy(gradientEndHex = hex), applyToAll)
                }
            )
        }

        HorizontalDivider()
        Text("Presentation Theme", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BuiltInThemes.ALL.forEach { th ->
                FilterChip(
                    selected = currentThemeId == th.id,
                    onClick = { onApplyTheme(th.id, true) },
                    label = { Text(th.name) }
                )
            }
        }

        Text("Slide Layout", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SlideLayoutType.entries.forEach { layout ->
                FilterChip(
                    selected = slide.layoutType == layout,
                    onClick = { onChangeLayout(layout) },
                    label = { Text(layout.displayName) }
                )
            }
        }
    }
}

@Composable
fun ObjectFormatAndLayerPanel(
    element: SlideElement?,
    onBringForward: () -> Unit,
    onSendBackward: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onUpdateElement: ((SlideElement) -> SlideElement) -> Unit
) {
    if (element == null) {
        Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
            Text("Tap any object on the slide to adjust position, size, rotation, or layer order.")
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(onClick = onBringForward) {
                Icon(Icons.Default.FlipToFront, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Bring Forward")
            }
            FilledTonalButton(onClick = onSendBackward) {
                Icon(Icons.Default.FlipToBack, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Send Backward")
            }
            OutlinedButton(onClick = onDuplicate) {
                Icon(Icons.Default.ContentCopy, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Duplicate")
            }
            OutlinedButton(
                onClick = onDelete,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Delete")
            }
        }

        Text("Rotation: ${element.rotation.toInt()}°", style = MaterialTheme.typography.labelMedium)
        Slider(
            value = element.rotation,
            onValueChange = { r -> onUpdateElement { it.copy(rotation = r) } },
            valueRange = 0f..360f
        )

        Text("Opacity: ${(element.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
        Slider(
            value = element.opacity,
            onValueChange = { op -> onUpdateElement { it.copy(opacity = op) } },
            valueRange = 0.1f..1f
        )
    }
}
