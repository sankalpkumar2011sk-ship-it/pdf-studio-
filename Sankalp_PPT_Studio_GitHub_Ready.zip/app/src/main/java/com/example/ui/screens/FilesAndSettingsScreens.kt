package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.UserSettings
import com.example.data.local.PresentationEntity
import com.example.model.AppLanguage
import com.example.model.AppThemeMode
import com.example.model.BuiltInThemes
import com.example.model.SlideAspectRatio
import com.example.viewmodel.SortOption
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyPresentationsScreen(
    presentations: List<PresentationEntity>,
    searchQuery: String,
    sortOption: SortOption,
    isGridView: Boolean,
    onSearchChange: (String) -> Unit,
    onSortChange: (SortOption) -> Unit,
    onToggleGridView: () -> Unit,
    onBack: () -> Unit,
    onImportPptx: () -> Unit,
    onOpenPresentation: (String, Boolean) -> Unit,
    onRenamePresentation: (String, String) -> Unit,
    onDuplicatePresentation: (String) -> Unit,
    onSharePresentation: (String, Boolean) -> Unit,
    onDeletePresentation: (String) -> Unit
) {
    BackHandler { onBack() }

    var renameTarget by remember { mutableStateOf<PresentationEntity?>(null) }
    var deleteTarget by remember { mutableStateOf<PresentationEntity?>(null) }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    val sortedAndFiltered = remember(presentations, searchQuery, sortOption) {
        val filtered = if (searchQuery.isBlank()) presentations
        else presentations.filter { it.name.contains(searchQuery.trim(), ignoreCase = true) }
        when (sortOption) {
            SortOption.DATE -> filtered.sortedByDescending { it.lastModified }
            SortOption.NAME -> filtered.sortedBy { it.name.lowercase(Locale.getDefault()) }
            SortOption.SIZE -> filtered.sortedByDescending { it.fileSizeBytes }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Presentations (${sortedAndFiltered.size})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("files_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onImportPptx, modifier = Modifier.testTag("files_import_button")) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Import PPTX")
                    }
                    IconButton(onClick = onToggleGridView, modifier = Modifier.testTag("files_toggle_grid_button")) {
                        Icon(
                            imageVector = if (isGridView) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                            contentDescription = "Toggle Grid/List View"
                        )
                    }
                    Box {
                        IconButton(onClick = { sortMenuExpanded = true }) {
                            Icon(Icons.Default.Sort, contentDescription = "Sort Presentations")
                        }
                        DropdownMenu(
                            expanded = sortMenuExpanded,
                            onDismissRequest = { sortMenuExpanded = false }
                        ) {
                            SortOption.entries.forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(opt.label) },
                                    leadingIcon = {
                                        if (sortOption == opt) Icon(Icons.Default.Check, contentDescription = null)
                                    },
                                    onClick = {
                                        onSortChange(opt)
                                        sortMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search presentations by name...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("my_presentations_search_input")
            )

            if (sortedAndFiltered.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.FolderOff, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No matching presentations found", style = MaterialTheme.typography.titleMedium)
                    }
                }
            } else if (isGridView) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 170.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(sortedAndFiltered, key = { it.id }) { entity ->
                        PresentationGridCard(
                            entity = entity,
                            onOpenEditor = { onOpenPresentation(entity.id, false) },
                            onOpenViewer = { onOpenPresentation(entity.id, true) },
                            onRename = { renameTarget = entity },
                            onDuplicate = { onDuplicatePresentation(entity.id) },
                            onSharePptx = { onSharePresentation(entity.id, false) },
                            onExportPdf = { onSharePresentation(entity.id, true) },
                            onDelete = { deleteTarget = entity }
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(sortedAndFiltered, key = { it.id }) { entity ->
                        RecentPresentationRowCard(
                            entity = entity,
                            onOpenEditor = { onOpenPresentation(entity.id, false) },
                            onOpenViewer = { onOpenPresentation(entity.id, true) },
                            onRename = { renameTarget = entity },
                            onDuplicate = { onDuplicatePresentation(entity.id) },
                            onSharePptx = { onSharePresentation(entity.id, false) },
                            onExportPdf = { onSharePresentation(entity.id, true) },
                            onDelete = { deleteTarget = entity }
                        )
                    }
                }
            }
        }
    }

    if (renameTarget != null) {
        val target = renameTarget!!
        var newName by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Presentation") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newName.isNotBlank()) onRenamePresentation(target.id, newName.trim())
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }

    if (deleteTarget != null) {
        val target = deleteTarget!!
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete Presentation?") },
            text = { Text("Delete \"${target.name}\"? This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePresentation(target.id)
                        deleteTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PresentationGridCard(
    entity: PresentationEntity,
    onOpenEditor: () -> Unit,
    onOpenViewer: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onSharePptx: () -> Unit,
    onExportPdf: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("dd MMM", Locale.getDefault()) }
    val sizeKb = (entity.fileSizeBytes / 1024L).coerceAtLeast(1L)

    Card(
        onClick = onOpenEditor,
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(104.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val thumbFile = entity.thumbnailPath?.let { File(it) }
                if (thumbFile != null && thumbFile.exists()) {
                    AsyncImage(
                        model = thumbFile,
                        contentDescription = entity.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Default.Slideshow, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = entity.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${entity.slideCount} slides • ${sizeKb}KB • ${dateFormat.format(Date(entity.lastModified))}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options")
                    }
                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                        DropdownMenuItem(text = { Text("Open in Editor") }, onClick = { menuExpanded = false; onOpenEditor() })
                        DropdownMenuItem(text = { Text("Open in Viewer") }, onClick = { menuExpanded = false; onOpenViewer() })
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { menuExpanded = false; onRename() })
                        DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menuExpanded = false; onDuplicate() })
                        DropdownMenuItem(text = { Text("Share PPTX") }, onClick = { menuExpanded = false; onSharePptx() })
                        DropdownMenuItem(text = { Text("Export PDF") }, onClick = { menuExpanded = false; onExportPdf() })
                        DropdownMenuItem(
                            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                            onClick = { menuExpanded = false; onDelete() }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: UserSettings,
    cacheSizeBytes: Long,
    onBack: () -> Unit,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onClearCache: () -> Unit
) {
    BackHandler { onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings & Preferences", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App Theme
            item {
                SettingsSectionCard(title = "Appearance & Language") {
                    Text("App Theme", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { onUpdateSettings { it.copy(themeMode = mode) } },
                                label = { Text(mode.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Interface Language (English / हिन्दी)", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = settings.language == lang,
                                onClick = { onUpdateSettings { it.copy(language = lang) } },
                                label = { Text(lang.label) }
                            )
                        }
                    }
                }
            }

            // Presentation Defaults
            item {
                SettingsSectionCard(title = "Presentation Defaults") {
                    Text("Default Slide Ratio", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SlideAspectRatio.entries.forEach { ratio ->
                            FilterChip(
                                selected = settings.defaultAspectRatio == ratio,
                                onClick = { onUpdateSettings { it.copy(defaultAspectRatio = ratio) } },
                                label = { Text(ratio.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Default Presentation Theme", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BuiltInThemes.ALL.take(3).forEach { th ->
                            FilterChip(
                                selected = settings.defaultThemeId == th.id,
                                onClick = { onUpdateSettings { it.copy(defaultThemeId = th.id) } },
                                label = { Text(th.name) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Autosave & Crash Recovery", style = MaterialTheme.typography.titleMedium)
                            Text("Automatically save edits in the background", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.autosaveEnabled,
                            onCheckedChange = { enabled -> onUpdateSettings { it.copy(autosaveEnabled = enabled) } },
                            modifier = Modifier.testTag("settings_autosave_switch")
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Default Export Format", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("PPTX", "PDF", "PNG").forEach { fmt ->
                            FilterChip(
                                selected = settings.defaultExportFormat == fmt,
                                onClick = { onUpdateSettings { it.copy(defaultExportFormat = fmt) } },
                                label = { Text(fmt) }
                            )
                        }
                    }
                }
            }

            // Thumbnail Cache Management
            item {
                SettingsSectionCard(title = "Storage & Thumbnail Cache") {
                    val kb = cacheSizeBytes / 1024L
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Cached Slide Thumbnails", style = MaterialTheme.typography.titleMedium)
                            Text("Current usage: $kb KB", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(
                            onClick = onClearCache,
                            modifier = Modifier.testTag("clear_cache_button")
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clear Cache")
                        }
                    }
                }
            }

            // Privacy, About & Help
            item {
                SettingsSectionCard(title = "About, Privacy & Security") {
                    Text("Sankalp PPT Studio — Professional PowerPoint Maker & Viewer", fontWeight = FontWeight.Bold)
                    Text("Version 1.0.0 (OOXML Engine Build 2026)", style = MaterialTheme.typography.bodyMedium)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    Text("Privacy & Offline Guarantee:", fontWeight = FontWeight.SemiBold)
                    Text(
                        "• 100% Local Processing: All .pptx and .pdf files are created, parsed, and rendered locally on your device.\n" +
                            "• Zero Cloud Uploads: Your presentation documents never leave your phone.\n" +
                            "• Scoped Storage & ZIP-Bomb Protection: Imports are validated against malformed archives and path traversal.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}
