package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Primary Palette - Inspired by modern presentation studio (Warm Terracotta & Deep Slate)
val PptPrimaryLight = Color(0xFFC43E1C)
val PptOnPrimaryLight = Color(0xFFFFFFFF)
val PptPrimaryContainerLight = Color(0xFFFFDBD1)
val PptOnPrimaryContainerLight = Color(0xFF3B0900)

val PptSecondaryLight = Color(0xFF2B5B84)
val PptOnSecondaryLight = Color(0xFFFFFFFF)
val PptSecondaryContainerLight = Color(0xFFD4E3FF)
val PptOnSecondaryContainerLight = Color(0xFF001C38)

val PptTertiaryLight = Color(0xFF7B5800)
val PptOnTertiaryLight = Color(0xFFFFFFFF)
val PptTertiaryContainerLight = Color(0xFFFFDEA1)
val PptOnTertiaryContainerLight = Color(0xFF271900)

val PptBackgroundLight = Color(0xFFFBF8F6)
val PptOnBackgroundLight = Color(0xFF1E1B1A)
val PptSurfaceLight = Color(0xFFFFFFFF)
val PptOnSurfaceLight = Color(0xFF1E1B1A)
val PptSurfaceVariantLight = Color(0xFFF2ECE9)
val PptOnSurfaceVariantLight = Color(0xFF51443F)
val PptOutlineLight = Color(0xFF83746E)

// Dark Theme Palette
val PptPrimaryDark = Color(0xFFFFB5A0)
val PptOnPrimaryDark = Color(0xFF601400)
val PptPrimaryContainerDark = Color(0xFF962B0B)
val PptOnPrimaryContainerDark = Color(0xFFFFDBD1)

val PptSecondaryDark = Color(0xFFA4C9FE)
val PptOnSecondaryDark = Color(0xFF00315B)
val PptSecondaryContainerDark = Color(0xFF084876)
val PptOnSecondaryContainerDark = Color(0xFFD4E3FF)

val PptTertiaryDark = Color(0xFFF7BE48)
val PptOnTertiaryDark = Color(0xFF412D00)
val PptTertiaryContainerDark = Color(0xFF5D4200)
val PptOnTertiaryContainerDark = Color(0xFFFFDEA1)

val PptBackgroundDark = Color(0xFF141214)
val PptOnBackgroundDark = Color(0xFFE9E0DE)
val PptSurfaceDark = Color(0xFF1E1B1D)
val PptOnSurfaceDark = Color(0xFFE9E0DE)
val PptSurfaceVariantDark = Color(0xFF2D282A)
val PptOnSurfaceVariantDark = Color(0xFFD6C2BC)
val PptOutlineDark = Color(0xFF9E8D87)
