package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PptPrimaryDark,
    onPrimary = PptOnPrimaryDark,
    primaryContainer = PptPrimaryContainerDark,
    onPrimaryContainer = PptOnPrimaryContainerDark,
    secondary = PptSecondaryDark,
    onSecondary = PptOnSecondaryDark,
    secondaryContainer = PptSecondaryContainerDark,
    onSecondaryContainer = PptOnSecondaryContainerDark,
    tertiary = PptTertiaryDark,
    onTertiary = PptOnTertiaryDark,
    tertiaryContainer = PptTertiaryContainerDark,
    onTertiaryContainer = PptOnTertiaryContainerDark,
    background = PptBackgroundDark,
    onBackground = PptOnBackgroundDark,
    surface = PptSurfaceDark,
    onSurface = PptOnSurfaceDark,
    surfaceVariant = PptSurfaceVariantDark,
    onSurfaceVariant = PptOnSurfaceVariantDark,
    outline = PptOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = PptPrimaryLight,
    onPrimary = PptOnPrimaryLight,
    primaryContainer = PptPrimaryContainerLight,
    onPrimaryContainer = PptOnPrimaryContainerLight,
    secondary = PptSecondaryLight,
    onSecondary = PptOnSecondaryLight,
    secondaryContainer = PptSecondaryContainerLight,
    onSecondaryContainer = PptOnSecondaryContainerLight,
    tertiary = PptTertiaryLight,
    onTertiary = PptOnTertiaryLight,
    tertiaryContainer = PptTertiaryContainerLight,
    onTertiaryContainer = PptOnTertiaryContainerLight,
    background = PptBackgroundLight,
    onBackground = PptOnBackgroundLight,
    surface = PptSurfaceLight,
    onSurface = PptOnSurfaceLight,
    surfaceVariant = PptSurfaceVariantLight,
    onSurfaceVariant = PptOnSurfaceVariantLight,
    outline = PptOutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
