package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.FormatAlignLeft
import androidx.compose.material.icons.automirrored.filled.FormatAlignRight
import androidx.compose.material.icons.automirrored.filled.FormatIndentDecrease
import androidx.compose.material.icons.automirrored.filled.FormatIndentIncrease
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.SlideRendererAndPdfExporter
import com.example.model.*

val STUDIO_COLOR_PALETTE = listOf(
    "#0F172A", "#FFFFFF", "#C43E1C", "#1D4ED8", "#0EA5E9",
    "#15803D", "#F59E0B", "#9333EA", "#EC4899", "#475569",
    "#FEF3C7", "#DBEAFE", "#DCFCE7", "#F3E8FF"
)

val AVAILABLE_FONT_FAMILIES = listOf(
    "Plus Jakarta Sans",
    "Playfair Display",
    "Roboto Mono",
    "Noto Sans Devanagari"
)

@Composable
fun ColorSwatchRow(
    selectedHex: String?,
    onSelectColor: (String) -> Unit,
    allowClear: Boolean = false,
    onClear: () -> Unit = {}
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (allowClear) {
            item {
                OutlinedButton(
                    onClick = onClear,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("None", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        items(STUDIO_COLOR_PALETTE) { hex ->
            val col = Color(SlideRendererAndPdfExporter.parseColorSafe(hex))
            val isSelected = selectedHex.equals(hex, ignoreCase = true)
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(col)
                    .border(
                        width = if (isSelected) 3.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.5f),
                        shape = CircleShape
                    )
                    .clickable { onSelectColor(hex) }
            )
        }
    }
}

@Composable
fun TextFormattingPanel(
    element: SlideElement?,
    onInsertTextBox: () -> Unit,
    onUpdateElement: ((SlideElement) -> SlideElement) -> Unit,
    onCopyText: () -> Unit,
    onPasteText: () -> Unit,
    onOpenFullTextDialog: () -> Unit
) {
    if (element == null || (element.type != ElementType.TEXT && element.type != ElementType.SHAPE)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Select a text box on the slide or insert a new one", style = MaterialTheme.typography.bodyMedium)
            Button(
                onClick = onInsertTextBox,
                modifier = Modifier.testTag("panel_insert_textbox_button")
            ) {
                Icon(Icons.Default.TextFields, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Insert New Text Box")
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = element.text,
                onValueChange = { newText -> onUpdateElement { it.copy(text = newText) } },
                label = { Text("Text Content (English / हिन्दी)") },
                maxLines = 3,
                modifier = Modifier
                    .weight(1f)
                    .testTag("editor_text_field")
            )
            FilledTonalIconButton(onClick = onOpenFullTextDialog) {
                Icon(Icons.Default.EditNote, contentDescription = "Expand Text Editor")
            }
        }

        // Font Family Chips
        Text("Font Family", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AVAILABLE_FONT_FAMILIES.forEach { fontName ->
                FilterChip(
                    selected = element.fontFamily == fontName,
                    onClick = { onUpdateElement { it.copy(fontFamily = fontName) } },
                    label = { Text(fontName) }
                )
            }
        }

        // Font Size + Style Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onUpdateElement { it.copy(fontSize = (it.fontSize - 2f).coerceAtLeast(10f)) } }) {
                    Icon(Icons.Default.TextDecrease, contentDescription = "Decrease Font Size")
                }
                Text("${element.fontSize.toInt()} pt", fontWeight = FontWeight.Bold)
                IconButton(onClick = { onUpdateElement { it.copy(fontSize = (it.fontSize + 2f).coerceAtMost(72f)) } }) {
                    Icon(Icons.Default.TextIncrease, contentDescription = "Increase Font Size")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = element.isBold,
                    onClick = { onUpdateElement { it.copy(isBold = !it.isBold) } },
                    label = { Text("B", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("toggle_bold_chip")
                )
                FilterChip(
                    selected = element.isItalic,
                    onClick = { onUpdateElement { it.copy(isItalic = !it.isItalic) } },
                    label = { Text("I") }
                )
                FilterChip(
                    selected = element.isUnderline,
                    onClick = { onUpdateElement { it.copy(isUnderline = !it.isUnderline) } },
                    label = { Text("U") }
                )
                FilterChip(
                    selected = element.isStrikethrough,
                    onClick = { onUpdateElement { it.copy(isStrikethrough = !it.isStrikethrough) } },
                    label = { Text("S") }
                )
            }
        }

        // Alignment, Lists, Indent & Copy/Paste
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onUpdateElement { it.copy(textAlign = TextAlignOption.LEFT) } }) {
                Icon(Icons.AutoMirrored.Filled.FormatAlignLeft, contentDescription = "Align Left")
            }
            IconButton(onClick = { onUpdateElement { it.copy(textAlign = TextAlignOption.CENTER) } }) {
                Icon(Icons.Default.FormatAlignCenter, contentDescription = "Align Center")
            }
            IconButton(onClick = { onUpdateElement { it.copy(textAlign = TextAlignOption.RIGHT) } }) {
                Icon(Icons.AutoMirrored.Filled.FormatAlignRight, contentDescription = "Align Right")
            }
            IconButton(
                onClick = {
                    val next = if (element.listType == ListStyleType.BULLET) ListStyleType.NONE else ListStyleType.BULLET
                    onUpdateElement { it.copy(listType = next) }
                }
            ) {
                Icon(Icons.AutoMirrored.Filled.FormatListBulleted, contentDescription = "Bullet List")
            }
            IconButton(
                onClick = {
                    val next = if (element.listType == ListStyleType.NUMBERED) ListStyleType.NONE else ListStyleType.NUMBERED
                    onUpdateElement { it.copy(listType = next) }
                }
            ) {
                Icon(Icons.Default.FormatListNumbered, contentDescription = "Numbered List")
            }
            IconButton(onClick = { onUpdateElement { it.copy(indentLevel = (it.indentLevel + 1).coerceAtMost(4)) } }) {
                Icon(Icons.AutoMirrored.Filled.FormatIndentIncrease, contentDescription = "Increase Indent")
            }
            IconButton(onClick = { onUpdateElement { it.copy(indentLevel = (it.indentLevel - 1).coerceAtLeast(0)) } }) {
                Icon(Icons.AutoMirrored.Filled.FormatIndentDecrease, contentDescription = "Decrease Indent")
            }
            OutlinedButton(onClick = onCopyText) { Text("Copy") }
            OutlinedButton(onClick = onPasteText) { Text("Paste") }
        }

        Text("Text Color", style = MaterialTheme.typography.labelMedium)
        ColorSwatchRow(
            selectedHex = element.textColorHex,
            onSelectColor = { hex -> onUpdateElement { it.copy(textColorHex = hex) } }
        )

        Text("Text Box Fill & Highlight", style = MaterialTheme.typography.labelMedium)
        ColorSwatchRow(
            selectedHex = element.fillColorHex,
            allowClear = true,
            onClear = { onUpdateElement { it.copy(fillColorHex = null, highlightColorHex = null) } },
            onSelectColor = { hex -> onUpdateElement { it.copy(fillColorHex = hex) } }
        )
    }
}

@Composable
fun FreehandDrawingDialog(
    onDismiss: () -> Unit,
    onConfirmDrawing: (List<Point2D>) -> Unit
) {
    val points = remember { mutableStateListOf<Point2D>() }
    var canvasWidth by remember { mutableFloatStateOf(1f) }
    var canvasHeight by remember { mutableFloatStateOf(1f) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Freehand Slide Drawing") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Draw with your finger inside the canvas below:", style = MaterialTheme.typography.bodyMedium)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF8FAFC))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    canvasWidth = size.width.toFloat().coerceAtLeast(1f)
                                    canvasHeight = size.height.toFloat().coerceAtLeast(1f)
                                    points.add(Point2D((offset.x / canvasWidth).coerceIn(0f, 1f), (offset.y / canvasHeight).coerceIn(0f, 1f)))
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    val pos = change.position
                                    points.add(Point2D((pos.x / canvasWidth).coerceIn(0f, 1f), (pos.y / canvasHeight).coerceIn(0f, 1f)))
                                }
                            )
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (points.size >= 2) {
                            val path = Path()
                            points.forEachIndexed { idx, pt ->
                                val px = pt.x * size.width
                                val py = pt.y * size.height
                                if (idx == 0) path.moveTo(px, py) else path.lineTo(px, py)
                            }
                            drawPath(path, color = Color(0xFFC43E1C), style = Stroke(width = 6f))
                        }
                    }
                }
                TextButton(onClick = { points.clear() }) {
                    Text("Clear Stroke")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (points.size >= 2) onConfirmDrawing(points.toList())
                    onDismiss()
                }
            ) {
                Text("Insert Drawing")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun ChartDataEditorDialog(
    element: SlideElement,
    onDismiss: () -> Unit,
    onSaveChart: (SlideElement) -> Unit
) {
    var chartTitle by remember(element.id) { mutableStateOf(element.chartTitle) }
    var chartKind by remember(element.id) { mutableStateOf(element.chartKind) }
    var categoriesText by remember(element.id) { mutableStateOf(element.chartCategories.joinToString(", ")) }
    var showLegend by remember(element.id) { mutableStateOf(element.showLegend) }
    var showLabels by remember(element.id) { mutableStateOf(element.showDataLabels) }
    var showGrid by remember(element.id) { mutableStateOf(element.showGridLines) }

    val seriesStates = remember(element.id) {
        mutableStateListOf<Triple<String, String, String>>().apply {
            element.chartSeries.forEach { s ->
                add(Triple(s.name, s.values.joinToString(", "), s.colorHex))
            }
            if (isEmpty()) {
                add(Triple("Revenue", "40, 55, 72, 90", "#1D4ED8"))
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Chart Data & Type") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Charts are editable in PPT Studio and embedded as high-resolution graphics in exported .pptx files for universal compatibility.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ChartKind.entries.forEach { kind ->
                        FilterChip(
                            selected = chartKind == kind,
                            onClick = { chartKind = kind },
                            label = { Text(kind.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = chartTitle,
                    onValueChange = { chartTitle = it },
                    label = { Text("Chart Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = categoriesText,
                    onValueChange = { categoriesText = it },
                    label = { Text("Categories (comma-separated)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                seriesStates.forEachIndexed { idx, triple ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Series ${idx + 1}", fontWeight = FontWeight.Bold)
                                if (seriesStates.size > 1) {
                                    TextButton(onClick = { seriesStates.removeAt(idx) }) {
                                        Text("Remove", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = triple.first,
                                onValueChange = { seriesStates[idx] = triple.copy(first = it) },
                                label = { Text("Series Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = triple.second,
                                onValueChange = { seriesStates[idx] = triple.copy(second = it) },
                                label = { Text("Values (comma-separated numbers)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        val palette = listOf("#1D4ED8", "#0EA5E9", "#C43E1C", "#10B981", "#F59E0B")
                        val color = palette[seriesStates.size % palette.size]
                        seriesStates.add(Triple("Series ${seriesStates.size + 1}", "30, 45, 60, 75", color))
                    }
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Data Series")
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = showLegend, onClick = { showLegend = !showLegend }, label = { Text("Legend") })
                    FilterChip(selected = showLabels, onClick = { showLabels = !showLabels }, label = { Text("Values") })
                    FilterChip(selected = showGrid, onClick = { showGrid = !showGrid }, label = { Text("Grid") })
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cats = categoriesText.split(",").map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("Q1", "Q2", "Q3", "Q4") }
                    val newSeries = seriesStates.map { (name, valsStr, col) ->
                        val parsedVals = valsStr.split(",").mapNotNull { it.trim().toFloatOrNull() }.ifEmpty { listOf(10f, 20f, 30f, 40f) }
                        ChartSeries(name.ifBlank { "Series" }, parsedVals, col)
                    }
                    onSaveChart(
                        element.copy(
                            chartKind = chartKind,
                            chartTitle = chartTitle,
                            chartCategories = cats,
                            chartSeries = newSeries,
                            showLegend = showLegend,
                            showDataLabels = showLabels,
                            showGridLines = showGrid
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("Apply Chart")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
