package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.NavigateBefore
import androidx.compose.material.icons.automirrored.filled.NavigateNext
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.PresentationDocument
import com.example.model.SlideModel
import com.example.ui.components.SlideCanvasView
import com.example.ui.components.SlideThumbnailCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PresentationViewerScreen(
    document: PresentationDocument,
    selectedSlideIndex: Int,
    onSelectSlide: (Int) -> Unit,
    onExitViewer: () -> Unit,
    onSwitchToEditor: () -> Unit,
    onStartSlideshow: () -> Unit,
    onExportPdf: () -> Unit
) {
    BackHandler { onExitViewer() }

    val currentSlide = document.slides.getOrElse(selectedSlideIndex) {
        document.slides.firstOrNull() ?: SlideModel()
    }

    var zoomScale by remember { mutableFloatStateOf(1f) }
    var showOverviewGrid by remember { mutableStateOf(false) }
    var showSearchBar by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showSpeakerNotes by remember { mutableStateOf(false) }

    val searchMatches = remember(document, searchQuery) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim()
            document.slides.mapIndexedNotNull { index, s ->
                val hasText = s.elements.any { el ->
                    el.text.contains(q, ignoreCase = true) ||
                        el.chartTitle.contains(q, ignoreCase = true) ||
                        el.tableCells.any { r -> r.any { c -> c.contains(q, ignoreCase = true) } }
                } || s.speakerNotes.contains(q, ignoreCase = true)
                if (hasText) index else null
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onExitViewer, modifier = Modifier.testTag("viewer_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit Viewer")
                    }
                },
                title = {
                    Column {
                        Text(
                            text = document.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Viewer • Slide ${selectedSlideIndex + 1} of ${document.slides.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSearchBar = !showSearchBar },
                        modifier = Modifier.testTag("viewer_search_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search Slides")
                    }
                    IconButton(
                        onClick = { showOverviewGrid = !showOverviewGrid },
                        modifier = Modifier.testTag("viewer_overview_button")
                    ) {
                        Icon(Icons.Default.GridView, contentDescription = "Slide Overview")
                    }
                    IconButton(
                        onClick = { showSpeakerNotes = !showSpeakerNotes },
                        modifier = Modifier.testTag("viewer_notes_button")
                    ) {
                        Icon(Icons.Default.SpeakerNotes, contentDescription = "Speaker Notes")
                    }
                    IconButton(
                        onClick = onSwitchToEditor,
                        modifier = Modifier.testTag("viewer_edit_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Presentation")
                    }
                    IconButton(
                        onClick = onStartSlideshow,
                        modifier = Modifier.testTag("viewer_fullscreen_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Full-Screen Slideshow",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Column {
                    // Thumbnail Strip
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        itemsIndexed(document.slides, key = { _, s -> s.id }) { idx, s ->
                            SlideThumbnailCard(
                                document = document,
                                slide = s,
                                slideNumber = idx + 1,
                                isSelected = idx == selectedSlideIndex,
                                onClick = { onSelectSlide(idx) },
                                modifier = Modifier.height(52.dp)
                            )
                        }
                    }
                    HorizontalDivider()
                    // Navigation Controls Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalIconButton(
                            onClick = { if (selectedSlideIndex > 0) onSelectSlide(selectedSlideIndex - 1) },
                            enabled = selectedSlideIndex > 0,
                            modifier = Modifier.testTag("viewer_prev_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous Slide")
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Slide ${selectedSlideIndex + 1} / ${document.slides.size}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            TextButton(onClick = { zoomScale = if (zoomScale == 1f) 1.35f else 1f }) {
                                Text(if (zoomScale == 1f) "Fit Screen" else "${(zoomScale * 100).toInt()}%")
                            }
                        }

                        FilledTonalIconButton(
                            onClick = { if (selectedSlideIndex < document.slides.lastIndex) onSelectSlide(selectedSlideIndex + 1) },
                            enabled = selectedSlideIndex < document.slides.lastIndex,
                            modifier = Modifier.testTag("viewer_next_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next Slide")
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Slide Text Search Bar
            AnimatedVisibility(visible = showSearchBar) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search text across all slides...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (searchQuery.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        if (searchMatches.isEmpty()) {
                            Text("No slides contain \"$searchQuery\"", style = MaterialTheme.typography.labelMedium)
                        } else {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(searchMatches) { _, matchIdx ->
                                    FilterChip(
                                        selected = selectedSlideIndex == matchIdx,
                                        onClick = { onSelectSlide(matchIdx) },
                                        label = { Text("Match: Slide ${matchIdx + 1}") }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (showOverviewGrid) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(document.slides) { idx, s ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            SlideThumbnailCard(
                                document = document,
                                slide = s,
                                slideNumber = idx + 1,
                                isSelected = idx == selectedSlideIndex,
                                onClick = {
                                    onSelectSlide(idx)
                                    showOverviewGrid = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Slide ${idx + 1}", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            } else {
                var swipeAccum by remember { mutableFloatStateOf(0f) }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(12.dp)
                        .pointerInput(selectedSlideIndex) {
                            detectHorizontalDragGestures(
                                onDragEnd = {
                                    if (swipeAccum < -90f && selectedSlideIndex < document.slides.lastIndex) {
                                        onSelectSlide(selectedSlideIndex + 1)
                                    } else if (swipeAccum > 90f && selectedSlideIndex > 0) {
                                        onSelectSlide(selectedSlideIndex - 1)
                                    }
                                    swipeAccum = 0f
                                },
                                onHorizontalDrag = { _, dragAmount ->
                                    swipeAccum += dragAmount
                                }
                            )
                        }
                        .pointerInput(Unit) {
                            detectTransformGestures { _, _, zoom, _ ->
                                zoomScale = (zoomScale * zoom).coerceIn(0.6f, 2.2f)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    SlideCanvasView(
                        document = document,
                        slide = currentSlide,
                        selectedElementId = null,
                        isInteractive = false,
                        zoomScale = zoomScale,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Speaker Notes Drawer
            AnimatedVisibility(visible = showSpeakerNotes) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Speaker Notes — Slide ${selectedSlideIndex + 1}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentSlide.speakerNotes.ifBlank { "No speaker notes recorded for this slide." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SlideshowScreen(
    document: PresentationDocument,
    selectedSlideIndex: Int,
    onSelectSlide: (Int) -> Unit,
    onExitSlideshow: () -> Unit
) {
    BackHandler { onExitSlideshow() }

    val visibleSlideIndices = remember(document.slides) {
        val nonHidden = document.slides.indices.filter { !document.slides[it].isHidden }
        nonHidden.ifEmpty { document.slides.indices.toList() }
    }

    val currentPosInVisible = visibleSlideIndices.indexOf(selectedSlideIndex).takeIf { it >= 0 } ?: 0
    val currentSlide = document.slides.getOrElse(visibleSlideIndices.getOrElse(currentPosInVisible) { 0 }) {
        document.slides.firstOrNull() ?: SlideModel()
    }

    var showControls by remember { mutableStateOf(false) }
    var isBlackScreen by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        runCatching { focusRequester.requestFocus() }
    }

    fun goNext() {
        if (currentPosInVisible < visibleSlideIndices.lastIndex) {
            onSelectSlide(visibleSlideIndices[currentPosInVisible + 1])
        }
    }

    fun goPrevious() {
        if (currentPosInVisible > 0) {
            onSelectSlide(visibleSlideIndices[currentPosInVisible - 1])
        }
    }

    var swipeDelta by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown) {
                    when (event.key) {
                        Key.DirectionRight, Key.Spacebar, Key.Enter -> { goNext(); true }
                        Key.DirectionLeft, Key.Backspace -> { goPrevious(); true }
                        Key.B -> { isBlackScreen = !isBlackScreen; true }
                        Key.Escape -> { onExitSlideshow(); true }
                        else -> false
                    }
                } else false
            }
            .pointerInput(currentPosInVisible, isBlackScreen) {
                detectTapGestures(
                    onTap = { offset ->
                        if (isBlackScreen) {
                            isBlackScreen = false
                            return@detectTapGestures
                        }
                        val w = size.width.toFloat().coerceAtLeast(1f)
                        when {
                            offset.x > w * 0.65f -> goNext()
                            offset.x < w * 0.35f -> goPrevious()
                            else -> showControls = !showControls
                        }
                    }
                )
            }
            .pointerInput(currentPosInVisible) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (swipeDelta < -80f) goNext()
                        else if (swipeDelta > 80f) goPrevious()
                        swipeDelta = 0f
                    },
                    onHorizontalDrag = { _, dragAmount ->
                        swipeDelta += dragAmount
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (isBlackScreen) {
            Text(
                text = "Black Screen Mode — Tap anywhere to resume slideshow",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            AnimatedContent(
                targetState = currentSlide,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "slideshow_transition"
            ) { slideState ->
                // Note: Speaker notes are strictly excluded from the audience-facing slideshow view
                SlideCanvasView(
                    document = document,
                    slide = slideState,
                    selectedElementId = null,
                    isInteractive = false,
                    zoomScale = 1f,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                )
            }
        }

        // Floating HUD Overlay (Auto-hidden unless tapped or triggered)
        AnimatedVisibility(
            visible = showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 20.dp)
        ) {
            Surface(
                color = Color(0xCC1E1B1D),
                shape = RoundedCornerShape(28.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    IconButton(
                        onClick = { goPrevious() },
                        enabled = currentPosInVisible > 0,
                        modifier = Modifier.testTag("slideshow_prev_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.NavigateBefore, contentDescription = "Previous", tint = Color.White)
                    }
                    Text(
                        text = "${currentPosInVisible + 1} / ${visibleSlideIndices.size}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = { goNext() },
                        enabled = currentPosInVisible < visibleSlideIndices.lastIndex,
                        modifier = Modifier.testTag("slideshow_next_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.NavigateNext, contentDescription = "Next", tint = Color.White)
                    }
                    IconButton(
                        onClick = { isBlackScreen = !isBlackScreen },
                        modifier = Modifier.testTag("slideshow_black_screen_button")
                    ) {
                        Icon(Icons.Default.Brightness2, contentDescription = "Black Screen", tint = Color.White)
                    }
                    FilledTonalButton(
                        onClick = onExitSlideshow,
                        modifier = Modifier.testTag("slideshow_exit_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Exit Slideshow")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Exit")
                    }
                }
            }
        }

        // Always-accessible subtle Exit button in top-right corner
        IconButton(
            onClick = onExitSlideshow,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(12.dp)
                .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50))
                .testTag("slideshow_top_exit_button")
        ) {
            Icon(Icons.Default.Close, contentDescription = "Exit Slideshow", tint = Color.White)
        }
    }
}
