package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.engine.SlideRendererAndPdfExporter
import com.example.model.PresentationDocument
import com.example.model.SlideElement
import com.example.model.SlideModel
import kotlin.math.roundToInt

@Composable
fun SlideCanvasView(
    document: PresentationDocument,
    slide: SlideModel,
    selectedElementId: String?,
    isInteractive: Boolean,
    zoomScale: Float = 1f,
    onSelectElement: (String?) -> Unit = {},
    onMoveElement: (String, Float, Float) -> Unit = { _, _, _ -> },
    onResizeElement: (String, Float, Float) -> Unit = { _, _, _ -> },
    onRotateElement: (String, Float) -> Unit = { _, _ -> },
    onDoubleTapElement: (SlideElement) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val logicalW = document.logicalWidth.coerceAtLeast(320f)
    val logicalH = document.logicalHeight.coerceAtLeast(240f)
    val aspectRatio = logicalW / logicalH

    BoxWithConstraints(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        val maxW = maxWidth
        val maxH = maxHeight
        val containerRatio = maxW.value / maxH.value.coerceAtLeast(1f)

        val baseWidthDp = if (containerRatio > aspectRatio) {
            maxH * aspectRatio
        } else {
            maxW
        }
        val baseHeightDp = baseWidthDp / aspectRatio

        val displayWidthDp = baseWidthDp * zoomScale.coerceIn(0.5f, 2.5f)
        val displayHeightDp = baseHeightDp * zoomScale.coerceIn(0.5f, 2.5f)

        val density = LocalDensity.current
        val displayWidthPx = with(density) { displayWidthDp.toPx() }.coerceAtLeast(1f)
        val scaleFactor = displayWidthPx / logicalW

        Box(
            modifier = Modifier
                .size(displayWidthDp, displayHeightDp)
                .shadow(if (isInteractive) 6.dp else 2.dp, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White)
                .pointerInput(isInteractive, slide.id) {
                    if (isInteractive) {
                        detectTapGestures(
                            onTap = { tapOffset ->
                                val lx = tapOffset.x / scaleFactor
                                val ly = tapOffset.y / scaleFactor
                                val hit = slide.elements
                                    .sortedByDescending { it.zIndex }
                                    .firstOrNull { el ->
                                        lx >= el.x && lx <= (el.x + el.width) &&
                                            ly >= el.y && ly <= (el.y + el.height)
                                    }
                                onSelectElement(hit?.id)
                            },
                            onDoubleTap = { tapOffset ->
                                val lx = tapOffset.x / scaleFactor
                                val ly = tapOffset.y / scaleFactor
                                val hit = slide.elements
                                    .sortedByDescending { it.zIndex }
                                    .firstOrNull { el ->
                                        lx >= el.x && lx <= (el.x + el.width) &&
                                            ly >= el.y && ly <= (el.y + el.height)
                                    }
                                if (hit != null) {
                                    onSelectElement(hit.id)
                                    onDoubleTapElement(hit)
                                }
                            }
                        )
                    }
                }
        ) {
            // Native Canvas rendering of the slide (ensures 100% WYSIWYG parity with PDF/PNG export)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val s = size.width / logicalW
                SlideRendererAndPdfExporter.renderSlideToCanvas(
                    canvas = drawContext.canvas.nativeCanvas,
                    doc = document,
                    slide = slide,
                    scale = s
                )
            }

            // Interactive Selection & Drag/Resize Handles Overlay
            if (isInteractive && selectedElementId != null) {
                val selectedEl = slide.elements.find { it.id == selectedElementId }
                if (selectedEl != null) {
                    var dragOffsetX by remember(selectedEl.id, selectedEl.x) { mutableFloatStateOf(selectedEl.x) }
                    var dragOffsetY by remember(selectedEl.id, selectedEl.y) { mutableFloatStateOf(selectedEl.y) }
                    var currentW by remember(selectedEl.id, selectedEl.width) { mutableFloatStateOf(selectedEl.width) }
                    var currentH by remember(selectedEl.id, selectedEl.height) { mutableFloatStateOf(selectedEl.height) }

                    val boxXdp = with(density) { (dragOffsetX * scaleFactor).toDp() }
                    val boxYdp = with(density) { (dragOffsetY * scaleFactor).toDp() }
                    val boxWdp = with(density) { (currentW * scaleFactor).toDp() }.coerceAtLeast(24.dp)
                    val boxHdp = with(density) { (currentH * scaleFactor).toDp() }.coerceAtLeast(20.dp)

                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (dragOffsetX * scaleFactor).roundToInt(),
                                    (dragOffsetY * scaleFactor).roundToInt()
                                )
                            }
                            .size(boxWdp, boxHdp)
                            .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                            .pointerInput(selectedEl.id, scaleFactor) {
                                detectDragGestures(
                                    onDragEnd = {
                                        onMoveElement(
                                            selectedEl.id,
                                            dragOffsetX.coerceIn(0f, logicalW - 30f),
                                            dragOffsetY.coerceIn(0f, logicalH - 20f)
                                        )
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        dragOffsetX = (dragOffsetX + dragAmount.x / scaleFactor).coerceIn(0f, logicalW - 30f)
                                        dragOffsetY = (dragOffsetY + dragAmount.y / scaleFactor).coerceIn(0f, logicalH - 20f)
                                    }
                                )
                            }
                            .pointerInput(selectedEl.id) {
                                detectTapGestures(
                                    onDoubleTap = { onDoubleTapElement(selectedEl) }
                                )
                            }
                    ) {
                        // Top-left Rotate Handle
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset(x = (-10).dp, y = (-10).dp)
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary)
                                .pointerInput(selectedEl.id) {
                                    detectTapGestures {
                                        onRotateElement(selectedEl.id, (selectedEl.rotation + 15f) % 360f)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RotateRight,
                                contentDescription = "Rotate element",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        // Bottom-right Resize Handle
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .offset(x = 10.dp, y = 10.dp)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .pointerInput(selectedEl.id, scaleFactor) {
                                    detectDragGestures(
                                        onDragEnd = {
                                            onResizeElement(
                                                selectedEl.id,
                                                currentW.coerceIn(50f, logicalW),
                                                currentH.coerceIn(30f, logicalH)
                                            )
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            currentW = (currentW + dragAmount.x / scaleFactor).coerceIn(50f, logicalW)
                                            currentH = (currentH + dragAmount.y / scaleFactor).coerceIn(30f, logicalH)
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInFull,
                                contentDescription = "Resize element",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SlideThumbnailCard(
    document: PresentationDocument,
    slide: SlideModel,
    slideNumber: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    val borderWidth = if (isSelected) 2.5.dp else 1.dp

    Box(
        modifier = modifier
            .aspectRatio(document.logicalWidth / document.logicalHeight.coerceAtLeast(1f))
            .clip(RoundedCornerShape(6.dp))
            .border(borderWidth, borderColor, RoundedCornerShape(6.dp))
            .background(Color.White)
            .pointerInput(slide.id) {
                detectTapGestures(onTap = { onClick() })
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val s = size.width / document.logicalWidth.coerceAtLeast(1f)
            SlideRendererAndPdfExporter.renderSlideToCanvas(
                canvas = drawContext.canvas.nativeCanvas,
                doc = document,
                slide = slide,
                scale = s
            )
        }
    }
}
