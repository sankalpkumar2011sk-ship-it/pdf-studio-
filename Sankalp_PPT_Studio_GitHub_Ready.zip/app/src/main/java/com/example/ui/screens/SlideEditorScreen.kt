package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.*
import com.example.ui.components.*
import com.example.viewmodel.SaveStatus

enum class EditorToolTab(val label: String, val icon: ImageVector) {
    INSERT("Insert", Icons.Default.AddCircleOutline),
    TEXT("Text", Icons.Default.TextFields),
    IMAGE("Image", Icons.Default.Image),
    SHAPES("Shapes", Icons.Default.Category),
    TABLE("Table", Icons.Default.TableChart),
    CHART("Chart", Icons.Default.BarChart),
    BACKGROUND("Background", Icons.Default.Wallpaper),
    DESIGN("Design", Icons.Default.Palette),
    FORMAT("Format", Icons.Default.Tune)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SlideEditorScreen(
    document: PresentationDocument,
    selectedSlideIndex: Int,
    selectedElementId: String?,
    canUndo: Boolean,
    canRedo: Boolean,
    saveStatus: SaveStatus,
    hasCopiedSlide: Boolean,
    onBack: () -> Unit,
    onRenamePresentation: (String) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onSaveNow: () -> Unit,
    onStartSlideshow: () -> Unit,
    onOpenInViewer: () -> Unit,
    onExportPptxSaf: () -> Unit,
    onExportPdfSaf: (List<Int>?) -> Unit,
    onShareFormat: (String) -> Unit,
    onSelectSlide: (Int) -> Unit,
    onAddSlide: (SlideLayoutType) -> Unit,
    onDuplicateSlide: (Int) -> Unit,
    onDeleteSlide: (Int) -> Unit,
    onMoveSlide: (Int, Int) -> Unit,
    onCopySlide: () -> Unit,
    onPasteSlide: () -> Unit,
    onToggleHideSlide: (Int) -> Unit,
    onUpdateSpeakerNotes: (String) -> Unit,
    onChangeLayout: (SlideLayoutType) -> Unit,
    onUpdateBackground: (SlideBackground, Boolean) -> Unit,
    onApplyTheme: (String, Boolean) -> Unit,
    onSelectElement: (String?) -> Unit,
    onInsertTextBox: () -> Unit,
    onInsertShape: (ShapeKind, List<Point2D>) -> Unit,
    onPickGalleryImage: () -> Unit,
    onPickDocumentImage: () -> Unit,
    onTakeCameraPhoto: () -> Unit,
    onReplaceGalleryImage: () -> Unit,
    onPickBackgroundImage: () -> Unit,
    onInsertTable: (Int, Int) -> Unit,
    onInsertChart: (ChartKind) -> Unit,
    onUpdateSelectedElement: (Boolean, (SlideElement) -> SlideElement) -> Unit,
    onUpdateElementById: (String, Boolean, (SlideElement) -> SlideElement) -> Unit,
    onDuplicateSelectedElement: () -> Unit,
    onDeleteSelectedElement: () -> Unit,
    onBringForward: () -> Unit,
    onSendBackward: () -> Unit,
    onCopyText: () -> Unit,
    onPasteText: () -> Unit
) {
    BackHandler { onBack() }

    val currentSlide = document.slides.getOrElse(selectedSlideIndex) {
        document.slides.firstOrNull() ?: SlideModel()
    }
    val selectedElement = currentSlide.elements.find { it.id == selectedElementId }

    var activeToolTab by remember { mutableStateOf<EditorToolTab?>(null) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var showExportMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showAddSlideLayoutDialog by remember { mutableStateOf(false) }
    var showSpeakerNotesDialog by remember { mutableStateOf(false) }
    var showFullTextDialog by remember { mutableStateOf(false) }
    var showFreehandDialog by remember { mutableStateOf(false) }
    var showChartEditorDialog by remember { mutableStateOf(false) }
    var showPdfRangeDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("editor_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Column(
                        modifier = Modifier
                            .clickable { showRenameDialog = true }
                            .testTag("editor_title_header")
                    ) {
                        Text(
                            text = document.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val statusText = when (saveStatus) {
                            SaveStatus.SAVING -> "Autosaving..."
                            SaveStatus.SAVED -> "Saved • Slide ${selectedSlideIndex + 1}/${document.slides.size}"
                            SaveStatus.ERROR -> "Save Error"
                            SaveStatus.IDLE -> "Slide ${selectedSlideIndex + 1}/${document.slides.size}"
                        }
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onUndo,
                        enabled = canUndo,
                        modifier = Modifier.testTag("editor_undo_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(
                        onClick = onRedo,
                        enabled = canRedo,
                        modifier = Modifier.testTag("editor_redo_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "Redo")
                    }
                    IconButton(
                        onClick = onSaveNow,
                        modifier = Modifier.testTag("editor_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save PPTX")
                    }
                    IconButton(
                        onClick = onStartSlideshow,
                        modifier = Modifier.testTag("editor_play_slideshow_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Slideshow",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Box {
                        IconButton(
                            onClick = { showExportMenu = true },
                            modifier = Modifier.testTag("editor_export_button")
                        ) {
                            Icon(Icons.Default.IosShare, contentDescription = "Export & Share")
                        }
                        DropdownMenu(
                            expanded = showExportMenu,
                            onDismissRequest = { showExportMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Save As PowerPoint (.pptx)") },
                                leadingIcon = { Icon(Icons.Default.SaveAlt, contentDescription = null) },
                                onClick = { showExportMenu = false; onExportPptxSaf() }
                            )
                            DropdownMenuItem(
                                text = { Text("Export PDF (All Slides)") },
                                leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                                onClick = { showExportMenu = false; onExportPdfSaf(null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Export PDF (Slide Range...)") },
                                leadingIcon = { Icon(Icons.Default.FilterNone, contentDescription = null) },
                                onClick = { showExportMenu = false; showPdfRangeDialog = true }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Share PowerPoint (.pptx)") },
                                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                                onClick = { showExportMenu = false; onShareFormat("PPTX") }
                            )
                            DropdownMenuItem(
                                text = { Text("Share PDF Document (.pdf)") },
                                leadingIcon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                                onClick = { showExportMenu = false; onShareFormat("PDF") }
                            )
                            DropdownMenuItem(
                                text = { Text("Export Current Slide Image (.png)") },
                                leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                                onClick = { showExportMenu = false; onShareFormat("PNG") }
                            )
                            DropdownMenuItem(
                                text = { Text("Export Current Slide Image (.jpg)") },
                                leadingIcon = { Icon(Icons.Default.Photo, contentDescription = null) },
                                onClick = { showExportMenu = false; onShareFormat("JPG") }
                            )
                        }
                    }

                    Box {
                        IconButton(
                            onClick = { showMoreMenu = true },
                            modifier = Modifier.testTag("editor_more_button")
                        ) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More Options")
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Speaker Notes") },
                                leadingIcon = { Icon(Icons.Default.SpeakerNotes, contentDescription = null) },
                                onClick = { showMoreMenu = false; showSpeakerNotesDialog = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Switch to Presentation Viewer") },
                                leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null) },
                                onClick = { showMoreMenu = false; onOpenInViewer() }
                            )
                            DropdownMenuItem(
                                text = { Text("Duplicate Current Slide") },
                                leadingIcon = { Icon(Icons.Default.ControlPointDuplicate, contentDescription = null) },
                                onClick = { showMoreMenu = false; onDuplicateSlide(selectedSlideIndex) }
                            )
                            DropdownMenuItem(
                                text = { Text("Copy Current Slide") },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                                onClick = { showMoreMenu = false; onCopySlide() }
                            )
                            if (hasCopiedSlide) {
                                DropdownMenuItem(
                                    text = { Text("Paste Slide") },
                                    leadingIcon = { Icon(Icons.Default.ContentPaste, contentDescription = null) },
                                    onClick = { showMoreMenu = false; onPasteSlide() }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text(if (currentSlide.isHidden) "Unhide Slide" else "Hide Slide in Slideshow") },
                                leadingIcon = { Icon(Icons.Default.VisibilityOff, contentDescription = null) },
                                onClick = { showMoreMenu = false; onToggleHideSlide(selectedSlideIndex) }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Current Slide", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = { showMoreMenu = false; onDeleteSlide(selectedSlideIndex) }
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
            ) {
                // Active Tool Drawer (Compact & Easily Dismissible so it never blocks the slide)
                AnimatedVisibility(visible = activeToolTab != null) {
                    Surface(
                        tonalElevation = 4.dp,
                        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 250.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = activeToolTab?.label ?: "",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                TextButton(
                                    onClick = { activeToolTab = null },
                                    modifier = Modifier.testTag("close_tool_sheet_button")
                                ) {
                                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Dismiss panel")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Done")
                                }
                            }
                            HorizontalDivider()
                            when (activeToolTab) {
                                EditorToolTab.INSERT -> {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .padding(16.dp),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        FilledTonalButton(
                                            onClick = { showAddSlideLayoutDialog = true },
                                            modifier = Modifier.testTag("insert_new_slide_button")
                                        ) {
                                            Icon(Icons.Default.AddToPhotos, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("New Slide")
                                        }
                                        FilledTonalButton(
                                            onClick = onInsertTextBox,
                                            modifier = Modifier.testTag("insert_textbox_quick_button")
                                        ) {
                                            Icon(Icons.Default.TextFields, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Text Box")
                                        }
                                        FilledTonalButton(
                                            onClick = onPickGalleryImage,
                                            modifier = Modifier.testTag("insert_image_quick_button")
                                        ) {
                                            Icon(Icons.Default.Image, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Image")
                                        }
                                        FilledTonalButton(
                                            onClick = { onInsertShape(ShapeKind.ROUNDED_RECTANGLE, emptyList()) },
                                            modifier = Modifier.testTag("insert_shape_quick_button")
                                        ) {
                                            Icon(Icons.Default.Category, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Shape")
                                        }
                                        FilledTonalButton(
                                            onClick = { onInsertTable(3, 3) },
                                            modifier = Modifier.testTag("insert_table_quick_button")
                                        ) {
                                            Icon(Icons.Default.TableChart, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Table")
                                        }
                                        FilledTonalButton(
                                            onClick = { onInsertChart(ChartKind.COLUMN) },
                                            modifier = Modifier.testTag("insert_chart_quick_button")
                                        ) {
                                            Icon(Icons.Default.BarChart, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Chart")
                                        }
                                        FilledTonalButton(onClick = { showFreehandDialog = true }) {
                                            Icon(Icons.Default.Draw, null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Freehand")
                                        }
                                    }
                                }

                                EditorToolTab.TEXT -> {
                                    TextFormattingPanel(
                                        element = selectedElement,
                                        onInsertTextBox = onInsertTextBox,
                                        onUpdateElement = { tf -> onUpdateSelectedElement(true, tf) },
                                        onCopyText = onCopyText,
                                        onPasteText = onPasteText,
                                        onOpenFullTextDialog = { showFullTextDialog = true }
                                    )
                                }

                                EditorToolTab.IMAGE -> {
                                    ImageEditingPanel(
                                        element = selectedElement,
                                        onPickGalleryImage = onPickGalleryImage,
                                        onPickDocumentImage = onPickDocumentImage,
                                        onTakeCameraPhoto = onTakeCameraPhoto,
                                        onReplaceGalleryImage = onReplaceGalleryImage,
                                        onUpdateElement = { tf -> onUpdateSelectedElement(true, tf) }
                                    )
                                }

                                EditorToolTab.SHAPES -> {
                                    ShapesLibraryPanel(
                                        element = selectedElement,
                                        onInsertShape = { kind -> onInsertShape(kind, emptyList()) },
                                        onOpenFreehandPad = { showFreehandDialog = true },
                                        onUpdateElement = { tf -> onUpdateSelectedElement(true, tf) }
                                    )
                                }

                                EditorToolTab.TABLE -> {
                                    TableEditingPanel(
                                        element = selectedElement,
                                        onInsertTable = onInsertTable,
                                        onUpdateElement = { tf -> onUpdateSelectedElement(true, tf) }
                                    )
                                }

                                EditorToolTab.CHART -> {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            ChartKind.entries.forEach { ck ->
                                                AssistChip(
                                                    onClick = { onInsertChart(ck) },
                                                    label = { Text("+ ${ck.label}") },
                                                    modifier = Modifier.testTag("add_chart_${ck.name}")
                                                )
                                            }
                                        }
                                        if (selectedElement != null && selectedElement.type == ElementType.CHART) {
                                            Button(
                                                onClick = { showChartEditorDialog = true },
                                                modifier = Modifier.testTag("open_chart_data_editor_button")
                                            ) {
                                                Icon(Icons.Default.Edit, contentDescription = null)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Edit Chart Data, Series & Labels")
                                            }
                                        }
                                    }
                                }

                                EditorToolTab.BACKGROUND, EditorToolTab.DESIGN -> {
                                    BackgroundAndDesignPanel(
                                        slide = currentSlide,
                                        currentThemeId = document.themeId,
                                        onUpdateBackground = onUpdateBackground,
                                        onPickBackgroundImage = onPickBackgroundImage,
                                        onApplyTheme = onApplyTheme,
                                        onChangeLayout = onChangeLayout
                                    )
                                }

                                EditorToolTab.FORMAT -> {
                                    ObjectFormatAndLayerPanel(
                                        element = selectedElement,
                                        onBringForward = onBringForward,
                                        onSendBackward = onSendBackward,
                                        onDuplicate = onDuplicateSelectedElement,
                                        onDelete = onDeleteSelectedElement,
                                        onUpdateElement = { tf -> onUpdateSelectedElement(true, tf) }
                                    )
                                }

                                null -> {}
                            }
                        }
                    }
                }

                // Bottom Scrollable Editing Toolbar (9 Tabs)
                HorizontalDivider()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    EditorToolTab.entries.forEach { tab ->
                        val isSelected = activeToolTab == tab
                        FilterChip(
                            selected = isSelected,
                            onClick = { activeToolTab = if (isSelected) null else tab },
                            label = { Text(tab.label) },
                            leadingIcon = {
                                Icon(tab.icon, contentDescription = tab.label, modifier = Modifier.size(18.dp))
                            },
                            modifier = Modifier.testTag("bottom_tab_${tab.name}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
        ) {
            // Top Zoom & Selected Element Quick Action Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Zoom & Fit-to-Screen Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { zoomScale = (zoomScale - 0.15f).coerceAtLeast(0.6f) },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", modifier = Modifier.size(18.dp))
                    }
                    TextButton(
                        onClick = { zoomScale = 1f },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("${(zoomScale * 100).toInt()}% Fit", style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(
                        onClick = { zoomScale = (zoomScale + 0.15f).coerceAtMost(2.0f) },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", modifier = Modifier.size(18.dp))
                    }
                }

                // Contextual Quick Actions when an object is selected
                if (selectedElement != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (selectedElement.type == ElementType.TEXT || selectedElement.type == ElementType.SHAPE) {
                            AssistChip(
                                onClick = { showFullTextDialog = true },
                                label = { Text("Edit Text") }
                            )
                        } else if (selectedElement.type == ElementType.CHART) {
                            AssistChip(
                                onClick = { showChartEditorDialog = true },
                                label = { Text("Edit Chart") }
                            )
                        }
                        IconButton(
                            onClick = onDuplicateSelectedElement,
                            modifier = Modifier.size(34.dp).testTag("quick_duplicate_element_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate Element", modifier = Modifier.size(18.dp))
                        }
                        IconButton(
                            onClick = onDeleteSelectedElement,
                            modifier = Modifier.size(34.dp).testTag("quick_delete_element_button")
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Element", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            // Central Slide Workspace Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                SlideCanvasView(
                    document = document,
                    slide = currentSlide,
                    selectedElementId = selectedElementId,
                    isInteractive = true,
                    zoomScale = zoomScale,
                    onSelectElement = { id -> onSelectElement(id) },
                    onMoveElement = { id, nx, ny ->
                        onUpdateElementById(id, true) { it.copy(x = nx, y = ny) }
                    },
                    onResizeElement = { id, nw, nh ->
                        onUpdateElementById(id, true) { it.copy(width = nw, height = nh) }
                    },
                    onRotateElement = { id, nRot ->
                        onUpdateElementById(id, true) { it.copy(rotation = nRot) }
                    },
                    onDoubleTapElement = { el ->
                        when (el.type) {
                            ElementType.TEXT, ElementType.SHAPE -> showFullTextDialog = true
                            ElementType.CHART -> showChartEditorDialog = true
                            ElementType.TABLE -> activeToolTab = EditorToolTab.TABLE
                            ElementType.IMAGE -> activeToolTab = EditorToolTab.IMAGE
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Slide Thumbnail Strip + Add / Reorder Slides
            Surface(
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    itemsIndexed(document.slides, key = { _, s -> s.id }) { idx, slideItem ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Box {
                                SlideThumbnailCard(
                                    document = document,
                                    slide = slideItem,
                                    slideNumber = idx + 1,
                                    isSelected = idx == selectedSlideIndex,
                                    onClick = { onSelectSlide(idx) },
                                    modifier = Modifier
                                        .height(58.dp)
                                        .testTag("slide_thumb_$idx")
                                )
                                if (slideItem.isHidden) {
                                    Icon(
                                        imageVector = Icons.Default.VisibilityOff,
                                        contentDescription = "Hidden Slide",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(2.dp)
                                            .size(14.dp)
                                    )
                                }
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                if (idx == selectedSlideIndex && idx > 0) {
                                    Icon(
                                        imageVector = Icons.Default.ChevronLeft,
                                        contentDescription = "Move Slide Left",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { onMoveSlide(idx, idx - 1) }
                                    )
                                }
                                Text(
                                    text = "${idx + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (idx == selectedSlideIndex) FontWeight.Bold else FontWeight.Normal,
                                    color = if (idx == selectedSlideIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (idx == selectedSlideIndex && idx < document.slides.lastIndex) {
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = "Move Slide Right",
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { onMoveSlide(idx, idx + 1) }
                                    )
                                }
                            }
                        }
                    }

                    // + Add Slide Button
                    item {
                        FilledTonalIconButton(
                            onClick = { showAddSlideLayoutDialog = true },
                            modifier = Modifier
                                .size(58.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .testTag("thumbnail_add_slide_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add New Slide")
                        }
                    }
                }
            }
        }
    }

    // Dialogs
    if (showRenameDialog) {
        var newName by remember(document.name) { mutableStateOf(document.name) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Presentation") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Presentation Title") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newName.isNotBlank()) onRenamePresentation(newName.trim())
                    showRenameDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddSlideLayoutDialog) {
        AlertDialog(
            onDismissRequest = { showAddSlideLayoutDialog = false },
            title = { Text("Add Slide — Choose Layout") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SlideLayoutType.entries.forEach { layout ->
                        OutlinedCard(
                            onClick = {
                                onAddSlide(layout)
                                showAddSlideLayoutDialog = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("add_slide_layout_${layout.name}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(layout.displayName, fontWeight = FontWeight.SemiBold)
                                Text(layout.hindiName, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAddSlideLayoutDialog = false }) { Text("Close") }
            }
        )
    }

    if (showSpeakerNotesDialog) {
        var notesText by remember(currentSlide.id) { mutableStateOf(currentSlide.speakerNotes) }
        AlertDialog(
            onDismissRequest = { showSpeakerNotesDialog = false },
            title = { Text("Speaker Notes (Slide ${selectedSlideIndex + 1})") },
            text = {
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    placeholder = { Text("Add presenter notes for this slide (hidden during audience slideshow)...") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateSpeakerNotes(notesText)
                    showSpeakerNotesDialog = false
                }) { Text("Save Notes") }
            },
            dismissButton = {
                TextButton(onClick = { showSpeakerNotesDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFullTextDialog && selectedElement != null) {
        var editedText by remember(selectedElement.id) { mutableStateOf(selectedElement.text) }
        AlertDialog(
            onDismissRequest = { showFullTextDialog = false },
            title = { Text("Edit Slide Text") },
            text = {
                OutlinedTextField(
                    value = editedText,
                    onValueChange = { editedText = it },
                    label = { Text("Supports English & Hindi (हिन्दी)") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateSelectedElement(true) { it.copy(text = editedText) }
                    showFullTextDialog = false
                }) { Text("Apply Text") }
            },
            dismissButton = {
                TextButton(onClick = { showFullTextDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFreehandDialog) {
        FreehandDrawingDialog(
            onDismiss = { showFreehandDialog = false },
            onConfirmDrawing = { pts -> onInsertShape(ShapeKind.FREEHAND, pts) }
        )
    }

    if (showChartEditorDialog && selectedElement != null) {
        ChartDataEditorDialog(
            element = selectedElement,
            onDismiss = { showChartEditorDialog = false },
            onSaveChart = { updatedChart ->
                onUpdateSelectedElement(true) { updatedChart }
            }
        )
    }

    if (showPdfRangeDialog) {
        var fromSlideText by remember { mutableStateOf("1") }
        var toSlideText by remember { mutableStateOf("${document.slides.size}") }
        AlertDialog(
            onDismissRequest = { showPdfRangeDialog = false },
            title = { Text("Export PDF Slide Range") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = fromSlideText,
                        onValueChange = { fromSlideText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("From Slide") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = toSlideText,
                        onValueChange = { toSlideText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("To Slide") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val start = ((fromSlideText.toIntOrNull() ?: 1) - 1).coerceIn(0, document.slides.lastIndex)
                    val end = ((toSlideText.toIntOrNull() ?: document.slides.size) - 1).coerceIn(start, document.slides.lastIndex)
                    showPdfRangeDialog = false
                    onExportPdfSaf((start..end).toList())
                }) { Text("Export Range") }
            },
            dismissButton = {
                TextButton(onClick = { showPdfRangeDialog = false }) { Text("Cancel") }
            }
        )
    }
}
