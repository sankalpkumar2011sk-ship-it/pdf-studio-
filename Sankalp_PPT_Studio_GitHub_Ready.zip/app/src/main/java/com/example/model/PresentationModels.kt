package com.example.model

import java.util.UUID

enum class SlideAspectRatio(val label: String, val widthPt: Float, val heightPt: Float, val emuCx: Long, val emuCy: Long) {
    WIDESCREEN_16_9("Widescreen 16:9", 960f, 540f, 12192000L, 6858000L),
    STANDARD_4_3("Standard 4:3", 960f, 720f, 9144000L, 6858000L),
    CUSTOM("Custom Size", 960f, 600f, 10800000L, 6750000L)
}

enum class SlideLayoutType(val displayName: String, val hindiName: String) {
    TITLE_SLIDE("Title Slide", "शीर्षक स्लाइड"),
    TITLE_AND_CONTENT("Title and Content", "शीर्षक और सामग्री"),
    SECTION_HEADER("Section Header", "अनुभाग शीर्षक"),
    TWO_CONTENT("Two Content", "दोहरी सामग्री"),
    COMPARISON("Comparison", "तुलना"),
    BLANK("Blank", "रिक्त स्लाइड"),
    PICTURE_WITH_CAPTION("Picture with Caption", "चित्र और विवरण"),
    TITLE_ONLY("Title Only", "केवल शीर्षक"),
    CONTENT_WITH_IMAGE("Content with Image", "सामग्री और चित्र")
}

data class PresentationTheme(
    val id: String,
    val name: String,
    val hindiName: String,
    val bgHex: String,
    val bgGradientEndHex: String?,
    val titleColorHex: String,
    val bodyColorHex: String,
    val primaryAccentHex: String,
    val secondaryAccentHex: String,
    val surfaceCardHex: String,
    val headingFont: String = "Plus Jakarta Sans",
    val bodyFont: String = "Plus Jakarta Sans"
)

object BuiltInThemes {
    val ALL = listOf(
        PresentationTheme(
            id = "professional_blue",
            name = "Professional Blue",
            hindiName = "प्रोफेशनल ब्लू",
            bgHex = "#F8FAFC",
            bgGradientEndHex = "#EFF6FF",
            titleColorHex = "#0F172A",
            bodyColorHex = "#334155",
            primaryAccentHex = "#1D4ED8",
            secondaryAccentHex = "#0EA5E9",
            surfaceCardHex = "#FFFFFF"
        ),
        PresentationTheme(
            id = "modern_dark",
            name = "Modern Dark",
            hindiName = "मॉडर्न डार्क",
            bgHex = "#0F172A",
            bgGradientEndHex = "#1E293B",
            titleColorHex = "#F8FAFC",
            bodyColorHex = "#CBD5E1",
            primaryAccentHex = "#38BDF8",
            secondaryAccentHex = "#818CF8",
            surfaceCardHex = "#1E293B"
        ),
        PresentationTheme(
            id = "minimal_white",
            name = "Minimal White",
            hindiName = "मिनिमल व्हाइट",
            bgHex = "#FFFFFF",
            bgGradientEndHex = null,
            titleColorHex = "#111827",
            bodyColorHex = "#4B5563",
            primaryAccentHex = "#111827",
            secondaryAccentHex = "#6B7280",
            surfaceCardHex = "#F9FAFB"
        ),
        PresentationTheme(
            id = "business",
            name = "Business",
            hindiName = "बिज़नेस",
            bgHex = "#FFFBF7",
            bgGradientEndHex = "#FEF3C7",
            titleColorHex = "#1C1917",
            bodyColorHex = "#44403C",
            primaryAccentHex = "#C43E1C",
            secondaryAccentHex = "#D97706",
            surfaceCardHex = "#FFFFFF"
        ),
        PresentationTheme(
            id = "education",
            name = "Education",
            hindiName = "शिक्षा",
            bgHex = "#FEFCE8",
            bgGradientEndHex = "#ECFDF5",
            titleColorHex = "#14532D",
            bodyColorHex = "#365314",
            primaryAccentHex = "#15803D",
            secondaryAccentHex = "#CA8A04",
            surfaceCardHex = "#FFFFFF"
        ),
        PresentationTheme(
            id = "creative",
            name = "Creative",
            hindiName = "क्रिएटिव",
            bgHex = "#FAF5FF",
            bgGradientEndHex = "#FDF2F8",
            titleColorHex = "#3B0764",
            bodyColorHex = "#581C87",
            primaryAccentHex = "#9333EA",
            secondaryAccentHex = "#EC4899",
            surfaceCardHex = "#FFFFFF"
        ),
        PresentationTheme(
            id = "nature",
            name = "Nature",
            hindiName = "प्रकृति",
            bgHex = "#F0FDF4",
            bgGradientEndHex = "#DCFCE7",
            titleColorHex = "#064E3B",
            bodyColorHex = "#166534",
            primaryAccentHex = "#059669",
            secondaryAccentHex = "#10B981",
            surfaceCardHex = "#FFFFFF"
        ),
        PresentationTheme(
            id = "elegant",
            name = "Elegant",
            hindiName = "एलिगेंट",
            bgHex = "#1C1917",
            bgGradientEndHex = "#292524",
            titleColorHex = "#FEF3C7",
            bodyColorHex = "#E7E5E4",
            primaryAccentHex = "#F59E0B",
            secondaryAccentHex = "#D97706",
            surfaceCardHex = "#292524",
            headingFont = "Playfair Display"
        ),
        PresentationTheme(
            id = "technology",
            name = "Technology",
            hindiName = "टेक्नोलॉजी",
            bgHex = "#090D16",
            bgGradientEndHex = "#111827",
            titleColorHex = "#ECFEFF",
            bodyColorHex = "#94A3B8",
            primaryAccentHex = "#06B6D4",
            secondaryAccentHex = "#3B82F6",
            surfaceCardHex = "#1E293B",
            bodyFont = "Roboto Mono"
        )
    )

    fun getById(id: String): PresentationTheme =
        ALL.find { it.id == id } ?: ALL.first()
}

enum class BackgroundType {
    SOLID, GRADIENT, IMAGE, PRESET
}

data class SlideBackground(
    val type: BackgroundType = BackgroundType.SOLID,
    val colorHex: String = "#FFFFFF",
    val gradientEndHex: String = "#EFF6FF",
    val gradientAngle: Float = 135f,
    val imagePath: String? = null,
    val presetName: String? = null
)

enum class TextAlignOption {
    LEFT, CENTER, RIGHT, JUSTIFY
}

enum class VerticalAlignOption {
    TOP, MIDDLE, BOTTOM
}

enum class ListStyleType {
    NONE, BULLET, NUMBERED
}

enum class ShapeKind(val label: String, val ooxmlPreset: String) {
    RECTANGLE("Rectangle", "rect"),
    ROUNDED_RECTANGLE("Rounded Rect", "roundRect"),
    CIRCLE("Circle", "ellipse"),
    OVAL("Oval", "ellipse"),
    TRIANGLE("Triangle", "triangle"),
    RIGHT_TRIANGLE("Right Triangle", "rtTriangle"),
    DIAMOND("Diamond", "diamond"),
    PENTAGON("Pentagon", "pentagon"),
    HEXAGON("Hexagon", "hexagon"),
    STAR("Star", "star5"),
    HEART("Heart", "heart"),
    LINE("Line", "line"),
    ARROW("Right Arrow", "rightArrow"),
    DOUBLE_ARROW("Double Arrow", "leftRightArrow"),
    CURVED_ARROW("Curved Arrow", "curvedRightArrow"),
    CALLOUT("Callout", "wedgeRectCallout"),
    SPEECH_BUBBLE("Speech Bubble", "wedgeRoundRectCallout"),
    FLOWCHART_PROCESS("Flowchart Process", "flowChartProcess"),
    FLOWCHART_DECISION("Flowchart Decision", "flowChartDecision"),
    FREEHAND("Freehand Drawing", "rect")
}

enum class ChartKind(val label: String) {
    COLUMN("Column Chart"),
    BAR("Bar Chart"),
    LINE("Line Chart"),
    PIE("Pie Chart"),
    DOUGHNUT("Doughnut Chart"),
    AREA("Area Chart"),
    SCATTER("Scatter Chart")
}

data class Point2D(
    val x: Float,
    val y: Float
)

data class ChartSeries(
    val name: String,
    val values: List<Float>,
    val colorHex: String
)

enum class ElementType {
    TEXT, IMAGE, SHAPE, TABLE, CHART
}

data class SlideElement(
    val id: String = UUID.randomUUID().toString(),
    val type: ElementType,
    // Position & size in logical slide coordinates (e.g., 0..960 x 0..540)
    val x: Float = 80f,
    val y: Float = 80f,
    val width: Float = 400f,
    val height: Float = 120f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    val zIndex: Int = 0,

    // Text properties
    val text: String = "",
    val fontFamily: String = "Plus Jakarta Sans",
    val fontSize: Float = 24f,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val isStrikethrough: Boolean = false,
    val textColorHex: String = "#0F172A",
    val highlightColorHex: String? = null,
    val textAlign: TextAlignOption = TextAlignOption.LEFT,
    val verticalAlign: VerticalAlignOption = VerticalAlignOption.TOP,
    val listType: ListStyleType = ListStyleType.NONE,
    val lineSpacing: Float = 1.2f,
    val paragraphSpacing: Float = 6f,
    val indentLevel: Int = 0,
    val isRtl: Boolean = false,
    val textPadding: Float = 12f,
    val wrapText: Boolean = true,

    // Box / Shape styling
    val fillColorHex: String? = null,
    val gradientEndColorHex: String? = null,
    val borderColorHex: String? = null,
    val borderWidth: Float = 0f,
    val hasShadow: Boolean = false,
    val shapeKind: ShapeKind = ShapeKind.RECTANGLE,
    val freehandPoints: List<Point2D> = emptyList(),

    // Image properties
    val imagePath: String? = null,
    val cropLeft: Float = 0f, // 0..0.45
    val cropTop: Float = 0f,
    val cropRight: Float = 0f,
    val cropBottom: Float = 0f,
    val flipHorizontal: Boolean = false,
    val flipVertical: Boolean = false,

    // Table properties
    val tableRows: Int = 3,
    val tableCols: Int = 3,
    val tableCells: List<List<String>> = emptyList(),
    val tableHeaderBgHex: String = "#1D4ED8",
    val tableHeaderTextHex: String = "#FFFFFF",
    val tableRowBgHex: String = "#FFFFFF",
    val tableAltRowBgHex: String = "#F1F5F9",
    val tableMergedFirstRow: Boolean = false,

    // Chart properties
    val chartKind: ChartKind = ChartKind.COLUMN,
    val chartTitle: String = "Performance Overview",
    val chartCategories: List<String> = listOf("Q1", "Q2", "Q3", "Q4"),
    val chartSeries: List<ChartSeries> = listOf(
        ChartSeries("Revenue", listOf(42f, 58f, 74f, 91f), "#1D4ED8"),
        ChartSeries("Profit", listOf(18f, 26f, 35f, 49f), "#0EA5E9")
    ),
    val showLegend: Boolean = true,
    val showDataLabels: Boolean = true,
    val showGridLines: Boolean = true,
    val xAxisLabel: String = "Quarter",
    val yAxisLabel: String = "Value (USD M)"
)

data class SlideModel(
    val id: String = UUID.randomUUID().toString(),
    val layoutType: SlideLayoutType = SlideLayoutType.TITLE_AND_CONTENT,
    val background: SlideBackground = SlideBackground(),
    val elements: List<SlideElement> = emptyList(),
    val speakerNotes: String = "",
    val isHidden: Boolean = false,
    val themeOverrideId: String? = null
)

data class PresentationDocument(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "Untitled Presentation",
    val filePath: String? = null,
    val externalUriString: String? = null,
    val aspectRatio: SlideAspectRatio = SlideAspectRatio.WIDESCREEN_16_9,
    val customWidthPt: Float = 960f,
    val customHeightPt: Float = 540f,
    val themeId: String = "professional_blue",
    val slides: List<SlideModel> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val hasUnsupportedElementsWarning: Boolean = false,
    val formatWarningMessage: String? = null
) {
    val logicalWidth: Float
        get() = if (aspectRatio == SlideAspectRatio.CUSTOM) customWidthPt else aspectRatio.widthPt

    val logicalHeight: Float
        get() = if (aspectRatio == SlideAspectRatio.CUSTOM) customHeightPt else aspectRatio.heightPt
}
