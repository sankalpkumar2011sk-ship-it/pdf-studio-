package com.example.model

enum class AppLanguage(val code: String, val label: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी (Hindi)")
}

enum class AppThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light Theme"),
    DARK("Dark Theme")
}

object AppStrings {
    fun get(key: String, lang: AppLanguage): String {
        if (lang == AppLanguage.HINDI) {
            HINDI_MAP[key]?.let { return it }
        }
        return ENGLISH_MAP[key] ?: key
    }

    private val ENGLISH_MAP = mapOf(
        "greeting_morning" to "Ready to build impactful slides?",
        "app_title" to "Sankalp PPT Studio",
        "app_subtitle" to "Professional PowerPoint Maker & Viewer",
        "create_new" to "Create New",
        "open_ppt" to "Open PPTX",
        "recent_files" to "Recent Presentations",
        "browse_templates" to "Browse Templates",
        "my_presentations" to "My Presentations",
        "settings" to "Settings",
        "home" to "Home",
        "templates" to "Templates",
        "files" to "Files",
        "empty_title" to "No Presentations Yet",
        "empty_subtitle" to "Tap Create (+) to design a new deck, start from 20+ templates, or open an existing PowerPoint (.pptx) file.",
        "unsaved_recovery_title" to "Recover Unsaved Presentation",
        "unsaved_recovery_desc" to "An automatically saved draft from your last editing session is available.",
        "recover_now" to "Recover Draft",
        "dismiss" to "Dismiss",
        "save" to "Save",
        "saved" to "Saved",
        "saving" to "Saving...",
        "slideshow" to "Slideshow",
        "export_pdf" to "Export PDF",
        "export_pptx" to "Export PPTX",
        "export_png" to "Export Slide PNG",
        "export_jpg" to "Export Slide JPEG",
        "viewer_mode" to "Viewer Mode",
        "edit_deck" to "Edit Presentation",
        "speaker_notes" to "Speaker Notes",
        "add_slide" to "Add Slide",
        "duplicate_slide" to "Duplicate Slide",
        "delete_slide" to "Delete Slide"
    )

    private val HINDI_MAP = mapOf(
        "greeting_morning" to "प्रभावशाली प्रेजेंटेशन बनाने के लिए तैयार हैं?",
        "app_title" to "Sankalp PPT Studio",
        "app_subtitle" to "प्रोफेशनल पावरपॉइंट मेकर और व्यूअर",
        "create_new" to "नया बनाएं",
        "open_ppt" to "PPTX खोलें",
        "recent_files" to "हाल की प्रेजेंटेशन",
        "browse_templates" to "टेम्पलेट्स देखें",
        "my_presentations" to "मेरी प्रेजेंटेशन",
        "settings" to "सेटिंग्स",
        "home" to "होम",
        "templates" to "टेम्पलेट्स",
        "files" to "फ़ाइलें",
        "empty_title" to "अभी कोई प्रेजेंटेशन नहीं है",
        "empty_subtitle" to "नया प्रेजेंटेशन बनाने के लिए (+) दबाएं, 20+ टेम्पलेट्स चुनें, या मौजूदा .pptx फ़ाइल खोलें।",
        "unsaved_recovery_title" to "असुरक्षित प्रेजेंटेशन रिकवर करें",
        "unsaved_recovery_desc" to "आपके पिछले सत्र का ऑटो-सेव किया गया ड्राफ्ट उपलब्ध है।",
        "recover_now" to "ड्राफ्ट खोलें",
        "dismiss" to "हटाएं",
        "save" to "सेव करें",
        "saved" to "सेव हो गया",
        "saving" to "सेव हो रहा है...",
        "slideshow" to "स्लाइडशो",
        "export_pdf" to "PDF एक्सपोर्ट करें",
        "export_pptx" to "PPTX एक्सपोर्ट करें",
        "export_png" to "PNG चित्र एक्सपोर्ट",
        "export_jpg" to "JPEG चित्र एक्सपोर्ट",
        "viewer_mode" to "व्यूअर मोड",
        "edit_deck" to "एडिट करें",
        "speaker_notes" to "स्पीकर नोट्स",
        "add_slide" to "नई स्लाइड",
        "duplicate_slide" to "स्लाइड डुप्लिकेट करें",
        "delete_slide" to "स्लाइड हटाएं"
    )
}
