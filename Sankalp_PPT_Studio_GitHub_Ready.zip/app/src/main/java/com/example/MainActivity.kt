package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppScreen
import com.example.viewmodel.PptStudioViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val incomingUri = if (intent?.action == Intent.ACTION_VIEW) intent?.data else null

        setContent {
            val vm: PptStudioViewModel = viewModel()
            val settings by vm.settings.collectAsStateWithLifecycle()

            LaunchedEffect(incomingUri) {
                if (incomingUri != null) {
                    vm.importExternalPresentationUri(incomingUri, openInViewer = true)
                }
            }

            val isDark = when (settings.themeMode) {
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
            }

            MyApplicationTheme(darkTheme = isDark) {
                PptStudioAppRoot(vm = vm)
            }
        }
    }
}

@Composable
fun PptStudioAppRoot(vm: PptStudioViewModel) {
    val context = LocalContext.current
    val currentScreen by vm.currentScreen.collectAsStateWithLifecycle()
    val presentations by vm.presentations.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val activeDocument by vm.activeDocument.collectAsStateWithLifecycle()
    val selectedSlideIndex by vm.selectedSlideIndex.collectAsStateWithLifecycle()
    val selectedElementId by vm.selectedElementId.collectAsStateWithLifecycle()
    val canUndo by vm.canUndo.collectAsStateWithLifecycle()
    val canRedo by vm.canRedo.collectAsStateWithLifecycle()
    val saveStatus by vm.saveStatus.collectAsStateWithLifecycle()
    val copiedSlide by vm.copiedSlide.collectAsStateWithLifecycle()
    val isBusy by vm.isBusy.collectAsStateWithLifecycle()
    val statusMessage by vm.statusMessage.collectAsStateWithLifecycle()
    val errorDialogMessage by vm.errorDialogMessage.collectAsStateWithLifecycle()
    val recoverableDraft by vm.recoverableDraft.collectAsStateWithLifecycle()
    val searchQuery by vm.searchQuery.collectAsStateWithLifecycle()
    val sortOption by vm.sortOption.collectAsStateWithLifecycle()
    val isGridView by vm.isGridView.collectAsStateWithLifecycle()
    val cacheSizeBytes by vm.cacheSizeBytes.collectAsStateWithLifecycle()

    var pendingPdfRangeIndices by remember { mutableStateOf<List<Int>?>(null) }

    // SAF & Media Launchers
    val openPptxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            vm.importExternalPresentationUri(uri, openInViewer = false)
        }
    }

    val savePptxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation")
    ) { uri ->
        if (uri != null) {
            vm.exportPptxToSafUri(uri)
        }
    }

    val exportPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            vm.exportPdfToSafUri(uri, pendingPdfRangeIndices)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) vm.insertImageFromUri(uri)
    }

    val replacePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) vm.replaceSelectedImageFromUri(uri)
    }

    val backgroundPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val doc = activeDocument ?: return@rememberLauncherForActivityResult
            val slide = doc.slides.getOrNull(selectedSlideIndex) ?: return@rememberLauncherForActivityResult
            vm.insertImageFromUri(uri)
        }
    }

    val documentImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.insertImageFromUri(uri)
    }

    val cameraPreviewLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) vm.insertImageFromBitmap(bitmap)
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            vm.clearStatusMessage()
        }
    }

    val showBottomHubNav = currentScreen in listOf(
        AppScreen.HOME,
        AppScreen.TEMPLATES,
        AppScreen.MY_PRESENTATIONS,
        AppScreen.SETTINGS
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomHubNav) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.HOME,
                        onClick = { vm.navigateTo(AppScreen.HOME) },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text(AppStrings.get("home", settings.language)) },
                        modifier = Modifier.testTag("nav_home")
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.TEMPLATES,
                        onClick = { vm.navigateTo(AppScreen.TEMPLATES) },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.TEMPLATES) Icons.Filled.AutoAwesomeMosaic else Icons.Outlined.AutoAwesomeMosaic,
                                contentDescription = "Templates"
                            )
                        },
                        label = { Text(AppStrings.get("templates", settings.language)) },
                        modifier = Modifier.testTag("nav_templates")
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.MY_PRESENTATIONS,
                        onClick = { vm.navigateTo(AppScreen.MY_PRESENTATIONS) },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.MY_PRESENTATIONS) Icons.Filled.Folder else Icons.Outlined.Folder,
                                contentDescription = "My Presentations"
                            )
                        },
                        label = { Text(AppStrings.get("files", settings.language)) },
                        modifier = Modifier.testTag("nav_files")
                    )
                    NavigationBarItem(
                        selected = currentScreen == AppScreen.SETTINGS,
                        onClick = { vm.navigateTo(AppScreen.SETTINGS) },
                        icon = {
                            Icon(
                                if (currentScreen == AppScreen.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = "Settings"
                            )
                        },
                        label = { Text(AppStrings.get("settings", settings.language)) },
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        }
    ) { rootPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(if (showBottomHubNav) PaddingValues(bottom = rootPadding.calculateBottomPadding()) else PaddingValues())
        ) {
            when (currentScreen) {
                AppScreen.HOME -> {
                    HomeScreen(
                        presentations = presentations,
                        language = settings.language,
                        recoverableDraftName = recoverableDraft?.name,
                        onRecoverDraft = { vm.recoverUnsavedDraft() },
                        onDismissDraft = { vm.dismissRecoverableDraft() },
                        onCreateNewClick = { vm.navigateTo(AppScreen.CREATE_NEW) },
                        onOpenPptClick = {
                            openPptxLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
                                    "application/vnd.ms-powerpoint",
                                    "application/octet-stream"
                                )
                            )
                        },
                        onBrowseTemplatesClick = { vm.navigateTo(AppScreen.TEMPLATES) },
                        onMyPresentationsClick = { vm.navigateTo(AppScreen.MY_PRESENTATIONS) },
                        onSettingsClick = { vm.navigateTo(AppScreen.SETTINGS) },
                        onToggleLanguage = {
                            vm.updateUserSettings { s ->
                                val next = if (s.language == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
                                s.copy(language = next)
                            }
                        },
                        onOpenPresentation = { id, viewer -> vm.openPresentationById(id, viewer) },
                        onRenamePresentation = { id, newName -> vm.renamePresentationById(id, newName) },
                        onDuplicatePresentation = { id -> vm.duplicatePresentationById(id) },
                        onSharePresentation = { id, asPdf ->
                            vm.shareSavedPresentationById(id, asPdf) { shareIntent ->
                                context.startActivity(shareIntent)
                            }
                        },
                        onDeletePresentation = { id -> vm.deletePresentationById(id) },
                        onQuickTemplateSelect = { tpl -> vm.createPresentationFromTemplate(tpl) }
                    )
                }

                AppScreen.CREATE_NEW -> {
                    CreatePresentationScreen(
                        defaultRatio = settings.defaultAspectRatio,
                        defaultThemeId = settings.defaultThemeId,
                        onBack = { vm.navigateBack() },
                        onCreateBlank = { name, ratio, themeId, cw, ch ->
                            vm.createNewBlankPresentation(name, ratio, themeId, cw, ch)
                        },
                        onOpenTemplateGallery = { vm.navigateTo(AppScreen.TEMPLATES) }
                    )
                }

                AppScreen.TEMPLATES -> {
                    TemplatesGalleryScreen(
                        onBack = { vm.navigateBack() },
                        onSelectTemplate = { tpl -> vm.createPresentationFromTemplate(tpl) }
                    )
                }

                AppScreen.MY_PRESENTATIONS -> {
                    MyPresentationsScreen(
                        presentations = presentations,
                        searchQuery = searchQuery,
                        sortOption = sortOption,
                        isGridView = isGridView,
                        onSearchChange = { vm.setSearchQuery(it) },
                        onSortChange = { vm.setSortOption(it) },
                        onToggleGridView = { vm.toggleGridView() },
                        onBack = { vm.navigateBack() },
                        onImportPptx = {
                            openPptxLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                    "application/vnd.ms-powerpoint",
                                    "application/octet-stream"
                                )
                            )
                        },
                        onOpenPresentation = { id, viewer -> vm.openPresentationById(id, viewer) },
                        onRenamePresentation = { id, newName -> vm.renamePresentationById(id, newName) },
                        onDuplicatePresentation = { id -> vm.duplicatePresentationById(id) },
                        onSharePresentation = { id, asPdf ->
                            vm.shareSavedPresentationById(id, asPdf) { shareIntent ->
                                context.startActivity(shareIntent)
                            }
                        },
                        onDeletePresentation = { id -> vm.deletePresentationById(id) }
                    )
                }

                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        settings = settings,
                        cacheSizeBytes = cacheSizeBytes,
                        onBack = { vm.navigateBack() },
                        onUpdateSettings = { tf -> vm.updateUserSettings(tf) },
                        onClearCache = { vm.clearThumbnailCache() }
                    )
                }

                AppScreen.EDITOR -> {
                    val doc = activeDocument
                    if (doc != null) {
                        SlideEditorScreen(
                            document = doc,
                            selectedSlideIndex = selectedSlideIndex,
                            selectedElementId = selectedElementId,
                            canUndo = canUndo,
                            canRedo = canRedo,
                            saveStatus = saveStatus,
                            hasCopiedSlide = copiedSlide != null,
                            onBack = { vm.navigateBack() },
                            onRenamePresentation = { vm.updatePresentationName(it) },
                            onUndo = { vm.undo() },
                            onRedo = { vm.redo() },
                            onSaveNow = { vm.saveActivePresentationNow() },
                            onStartSlideshow = { vm.startSlideshow(fromFirstSlide = false) },
                            onOpenInViewer = { vm.openDocumentInViewer(doc) },
                            onExportPptxSaf = {
                                savePptxLauncher.launch("${doc.name}.pptx")
                            },
                            onExportPdfSaf = { rangeIndices ->
                                pendingPdfRangeIndices = rangeIndices
                                exportPdfLauncher.launch("${doc.name}.pdf")
                            },
                            onShareFormat = { fmt ->
                                vm.sharePresentationAs(fmt) { shareIntent ->
                                    context.startActivity(shareIntent)
                                }
                            },
                            onSelectSlide = { vm.selectSlide(it) },
                            onAddSlide = { vm.addSlide(it) },
                            onDuplicateSlide = { vm.duplicateSlide(it) },
                            onDeleteSlide = { vm.deleteSlide(it) },
                            onMoveSlide = { from, to -> vm.moveSlide(from, to) },
                            onCopySlide = { vm.copyCurrentSlide() },
                            onPasteSlide = { vm.pasteCopiedSlide() },
                            onToggleHideSlide = { vm.toggleSlideHidden(it) },
                            onUpdateSpeakerNotes = { vm.updateSpeakerNotes(it) },
                            onChangeLayout = { vm.changeSlideLayout(it) },
                            onUpdateBackground = { bg, all -> vm.updateSlideBackground(bg, all) },
                            onApplyTheme = { th, all -> vm.applyTheme(th, all) },
                            onSelectElement = { vm.selectElement(it) },
                            onInsertTextBox = { vm.insertTextBox() },
                            onInsertShape = { kind, pts -> vm.insertShape(kind, pts) },
                            onPickGalleryImage = {
                                photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onPickDocumentImage = {
                                documentImageLauncher.launch(arrayOf("image/*"))
                            },
                            onTakeCameraPhoto = {
                                cameraPreviewLauncher.launch(null)
                            },
                            onReplaceGalleryImage = {
                                replacePhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onPickBackgroundImage = {
                                backgroundPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            onInsertTable = { r, c -> vm.insertTable(r, c) },
                            onInsertChart = { ck -> vm.insertChart(ck) },
                            onUpdateSelectedElement = { record, tf -> vm.updateSelectedElement(record, tf) },
                            onUpdateElementById = { id, record, tf -> vm.updateElementById(id, record, tf) },
                            onDuplicateSelectedElement = { vm.duplicateSelectedElement() },
                            onDeleteSelectedElement = { vm.deleteSelectedElement() },
                            onBringForward = { vm.bringSelectedElementForward() },
                            onSendBackward = { vm.sendSelectedElementBackward() },
                            onCopyText = { vm.copySelectedText() },
                            onPasteText = { vm.pasteTextToSelected() }
                        )
                    }
                }

                AppScreen.VIEWER -> {
                    val doc = activeDocument
                    if (doc != null) {
                        PresentationViewerScreen(
                            document = doc,
                            selectedSlideIndex = selectedSlideIndex,
                            onSelectSlide = { vm.selectSlide(it) },
                            onExitViewer = { vm.navigateBack() },
                            onSwitchToEditor = { vm.openDocumentInEditor(doc) },
                            onStartSlideshow = { vm.startSlideshow(fromFirstSlide = false) },
                            onExportPdf = {
                                pendingPdfRangeIndices = null
                                exportPdfLauncher.launch("${doc.name}.pdf")
                            }
                        )
                    }
                }

                AppScreen.SLIDESHOW -> {
                    val doc = activeDocument
                    if (doc != null) {
                        SlideshowScreen(
                            document = doc,
                            selectedSlideIndex = selectedSlideIndex,
                            onSelectSlide = { vm.selectSlide(it) },
                            onExitSlideshow = { vm.navigateBack() }
                        )
                    }
                }
            }

            if (isBusy) {
                Surface(
                    color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.35f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Card {
                            Row(
                                modifier = Modifier.padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(26.dp))
                                Text("Processing presentation...")
                            }
                        }
                    }
                }
            }
        }
    }

    if (errorDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { vm.dismissErrorDialog() },
            title = { Text("Document Notice") },
            text = { Text(errorDialogMessage ?: "") },
            confirmButton = {
                Button(onClick = { vm.dismissErrorDialog() }) {
                    Text("OK")
                }
            }
        )
    }
}
