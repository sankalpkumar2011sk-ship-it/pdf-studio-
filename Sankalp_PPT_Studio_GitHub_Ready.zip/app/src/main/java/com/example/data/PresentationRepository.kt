package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.local.AppDatabase
import com.example.data.local.PresentationEntity
import com.example.engine.OoxmlPptxEngine
import com.example.engine.PresentationJsonSerializer
import com.example.engine.SlideRendererAndPdfExporter
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

private val Context.dataStore by preferencesDataStore(name = "ppt_studio_settings")

data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val language: AppLanguage = AppLanguage.ENGLISH,
    val defaultAspectRatio: SlideAspectRatio = SlideAspectRatio.WIDESCREEN_16_9,
    val defaultThemeId: String = "professional_blue",
    val autosaveEnabled: Boolean = true,
    val defaultExportFormat: String = "PPTX"
)

class PresentationRepository(private val context: Context) {

    private val dao = AppDatabase.getInstance(context).presentationDao()
    private val presentationsDir = File(context.filesDir, "presentations").apply { mkdirs() }
    private val exportsDir = File(context.filesDir, "exports").apply { mkdirs() }
    private val thumbnailsDir = File(context.filesDir, "thumbnails").apply { mkdirs() }
    private val mediaCacheDir = File(context.filesDir, "media_extracted").apply { mkdirs() }
    private val autosaveDir = File(context.filesDir, "autosave").apply { mkdirs() }
    private val autosaveFile = File(autosaveDir, "active_draft.json")

    val allPresentations: Flow<List<PresentationEntity>> = dao.getAllPresentationsFlow()

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            themeMode = runCatching { AppThemeMode.valueOf(prefs[KEY_THEME_MODE] ?: "SYSTEM") }.getOrDefault(AppThemeMode.SYSTEM),
            language = runCatching { AppLanguage.valueOf(prefs[KEY_LANGUAGE] ?: "ENGLISH") }.getOrDefault(AppLanguage.ENGLISH),
            defaultAspectRatio = runCatching { SlideAspectRatio.valueOf(prefs[KEY_DEFAULT_RATIO] ?: "WIDESCREEN_16_9") }.getOrDefault(SlideAspectRatio.WIDESCREEN_16_9),
            defaultThemeId = prefs[KEY_DEFAULT_THEME] ?: "professional_blue",
            autosaveEnabled = prefs[KEY_AUTOSAVE] ?: true,
            defaultExportFormat = prefs[KEY_EXPORT_FORMAT] ?: "PPTX"
        )
    }

    suspend fun updateSettings(transform: (UserSettings) -> UserSettings) {
        context.dataStore.edit { prefs ->
            val current = UserSettings(
                themeMode = runCatching { AppThemeMode.valueOf(prefs[KEY_THEME_MODE] ?: "SYSTEM") }.getOrDefault(AppThemeMode.SYSTEM),
                language = runCatching { AppLanguage.valueOf(prefs[KEY_LANGUAGE] ?: "ENGLISH") }.getOrDefault(AppLanguage.ENGLISH),
                defaultAspectRatio = runCatching { SlideAspectRatio.valueOf(prefs[KEY_DEFAULT_RATIO] ?: "WIDESCREEN_16_9") }.getOrDefault(SlideAspectRatio.WIDESCREEN_16_9),
                defaultThemeId = prefs[KEY_DEFAULT_THEME] ?: "professional_blue",
                autosaveEnabled = prefs[KEY_AUTOSAVE] ?: true,
                defaultExportFormat = prefs[KEY_EXPORT_FORMAT] ?: "PPTX"
            )
            val updated = transform(current)
            prefs[KEY_THEME_MODE] = updated.themeMode.name
            prefs[KEY_LANGUAGE] = updated.language.name
            prefs[KEY_DEFAULT_RATIO] = updated.defaultAspectRatio.name
            prefs[KEY_DEFAULT_THEME] = updated.defaultThemeId
            prefs[KEY_AUTOSAVE] = updated.autosaveEnabled
            prefs[KEY_EXPORT_FORMAT] = updated.defaultExportFormat
        }
    }

    suspend fun ensureStarterPresentationIfNeeded() = withContext(Dispatchers.IO) {
        if (dao.getCount() == 0) {
            val starter = TemplateCatalog.createPresentationFromTemplate(
                template = TemplateCatalog.TEMPLATES.first(),
                customName = "Welcome to Sankalp PPT Studio"
            )
            savePresentationToLocal(starter)
        }
    }

    suspend fun savePresentationToLocal(doc: PresentationDocument): PresentationDocument = withContext(Dispatchers.IO) {
        val outFile = File(presentationsDir, "${doc.id}.pptx")
        val tmpFile = File(presentationsDir, "${doc.id}.pptx.tmp")
        FileOutputStream(tmpFile).use { fos ->
            OoxmlPptxEngine.writePptx(doc, fos)
        }
        if (outFile.exists()) outFile.delete()
        tmpFile.renameTo(outFile)

        val firstSlide = doc.slides.firstOrNull() ?: SlideModel()
        val thumbPath = SlideRendererAndPdfExporter.saveSlideThumbnail(context, doc, firstSlide)
        val updatedDoc = doc.copy(
            filePath = outFile.absolutePath,
            updatedAt = System.currentTimeMillis()
        )

        dao.upsert(
            PresentationEntity(
                id = updatedDoc.id,
                name = updatedDoc.name,
                filePath = outFile.absolutePath,
                externalUriString = updatedDoc.externalUriString,
                thumbnailPath = thumbPath,
                slideCount = updatedDoc.slides.size,
                fileSizeBytes = outFile.length(),
                aspectRatioName = updatedDoc.aspectRatio.name,
                themeId = updatedDoc.themeId,
                lastModified = updatedDoc.updatedAt,
                isAvailable = true
            )
        )
        clearAutosaveDraft()
        updatedDoc
    }

    suspend fun loadPresentationById(id: String): PresentationDocument? = withContext(Dispatchers.IO) {
        val entity = dao.getById(id) ?: return@withContext null
        val file = File(entity.filePath)
        if (!file.exists()) {
            dao.upsert(entity.copy(isAvailable = false))
            return@withContext null
        }
        FileInputStream(file).use { fis ->
            val parsed = OoxmlPptxEngine.readPptx(fis, entity.name, mediaCacheDir)
            parsed.copy(
                id = entity.id,
                name = entity.name,
                filePath = file.absolutePath,
                externalUriString = entity.externalUriString
            )
        }
    }

    suspend fun importPresentationFromUri(uri: Uri): PresentationDocument = withContext(Dispatchers.IO) {
        val displayName = resolveDisplayName(uri) ?: "Imported_Presentation.pptx"
        val doc = context.contentResolver.openInputStream(uri)?.use { inputStream ->
            OoxmlPptxEngine.readPptx(inputStream, displayName, mediaCacheDir)
        } ?: throw IllegalArgumentException("Unable to open selected file stream.")

        val withUri = doc.copy(externalUriString = uri.toString())
        savePresentationToLocal(withUri)
    }

    suspend fun exportPresentationPptxToUri(doc: PresentationDocument, targetUri: Uri) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(targetUri, "wt")?.use { os ->
            OoxmlPptxEngine.writePptx(doc, os)
        } ?: throw IllegalStateException("Cannot write to destination URI.")
    }

    suspend fun exportPresentationPdfToUri(
        doc: PresentationDocument,
        targetUri: Uri,
        slideIndices: List<Int>? = null
    ) = withContext(Dispatchers.IO) {
        context.contentResolver.openOutputStream(targetUri, "wt")?.use { os ->
            SlideRendererAndPdfExporter.exportToPdf(doc, os, slideIndices)
        } ?: throw IllegalStateException("Cannot write PDF to destination URI.")
    }

    suspend fun createShareablePdfFile(doc: PresentationDocument, slideIndices: List<Int>? = null): File = withContext(Dispatchers.IO) {
        val safeName = doc.name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "presentation" }
        val pdfFile = File(exportsDir, "$safeName.pdf")
        FileOutputStream(pdfFile).use { fos ->
            SlideRendererAndPdfExporter.exportToPdf(doc, fos, slideIndices)
        }
        pdfFile
    }

    suspend fun createShareablePptxFile(doc: PresentationDocument): File = withContext(Dispatchers.IO) {
        val safeName = doc.name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "presentation" }
        val pptxFile = File(exportsDir, "$safeName.pptx")
        FileOutputStream(pptxFile).use { fos ->
            OoxmlPptxEngine.writePptx(doc, fos)
        }
        pptxFile
    }

    suspend fun exportSlideAsImageFile(doc: PresentationDocument, slideIndex: Int, asJpeg: Boolean): File = withContext(Dispatchers.IO) {
        val slide = doc.slides.getOrElse(slideIndex) { doc.slides.first() }
        val bmp = SlideRendererAndPdfExporter.renderSlideToBitmap(doc, slide, targetWidthPx = 1920)
        val ext = if (asJpeg) "jpg" else "png"
        val safeName = doc.name.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").ifBlank { "slide" }
        val outFile = File(exportsDir, "${safeName}_slide_${slideIndex + 1}.$ext")
        FileOutputStream(outFile).use { fos ->
            bmp.compress(if (asJpeg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, 94, fos)
        }
        bmp.recycle()
        outFile
    }

    suspend fun renamePresentation(id: String, newName: String) = withContext(Dispatchers.IO) {
        val doc = loadPresentationById(id) ?: return@withContext
        savePresentationToLocal(doc.copy(name = newName.trim().ifBlank { doc.name }))
    }

    suspend fun duplicatePresentation(id: String): PresentationDocument? = withContext(Dispatchers.IO) {
        val original = loadPresentationById(id) ?: return@withContext null
        val duplicated = original.copy(
            id = UUID.randomUUID().toString(),
            name = "${original.name} (Copy)",
            filePath = null,
            externalUriString = null,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        savePresentationToLocal(duplicated)
    }

    suspend fun deletePresentation(id: String) = withContext(Dispatchers.IO) {
        val entity = dao.getById(id)
        if (entity != null) {
            runCatching { File(entity.filePath).delete() }
            entity.thumbnailPath?.let { runCatching { File(it).delete() } }
            dao.deleteById(id)
        }
    }

    suspend fun copyImageUriToInternalStorage(uri: Uri): String = withContext(Dispatchers.IO) {
        val outFile = File(mediaCacheDir, "img_${System.currentTimeMillis()}.png")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(outFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalArgumentException("Could not read selected image.")
        outFile.absolutePath
    }

    suspend fun saveBitmapToInternalStorage(bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        val outFile = File(mediaCacheDir, "cam_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { fos ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 92, fos)
        }
        outFile.absolutePath
    }

    // Autosave and Crash Recovery
    suspend fun writeAutosaveDraft(doc: PresentationDocument) = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(autosaveDir, "active_draft.tmp")
            tmp.writeText(PresentationJsonSerializer.toJsonString(doc), Charsets.UTF_8)
            if (autosaveFile.exists()) autosaveFile.delete()
            tmp.renameTo(autosaveFile)
        }
    }

    suspend fun readAutosaveDraft(): PresentationDocument? = withContext(Dispatchers.IO) {
        if (!autosaveFile.exists()) return@withContext null
        runCatching {
            PresentationJsonSerializer.fromJsonString(autosaveFile.readText(Charsets.UTF_8))
        }.getOrNull()
    }

    suspend fun clearAutosaveDraft() = withContext(Dispatchers.IO) {
        if (autosaveFile.exists()) autosaveFile.delete()
    }

    suspend fun getThumbnailCacheSizeBytes(): Long = withContext(Dispatchers.IO) {
        thumbnailsDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    suspend fun clearThumbnailCache() = withContext(Dispatchers.IO) {
        thumbnailsDir.listFiles()?.forEach { it.delete() }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment
    }

    companion object {
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_LANGUAGE = stringPreferencesKey("language")
        private val KEY_DEFAULT_RATIO = stringPreferencesKey("default_ratio")
        private val KEY_DEFAULT_THEME = stringPreferencesKey("default_theme")
        private val KEY_AUTOSAVE = booleanPreferencesKey("autosave")
        private val KEY_EXPORT_FORMAT = stringPreferencesKey("export_format")
    }
}
