package com.example.data

import com.example.model.*
import java.util.UUID

data class PresentationTemplateInfo(
    val id: String,
    val title: String,
    val category: String,
    val subtitle: String,
    val themeId: String,
    val accentHex: String,
    val bgHex: String,
    val slideCount: Int = 5
)

object TemplateCatalog {

    val CATEGORIES = listOf(
        "All",
        "Business",
        "Education",
        "Technology",
        "School Project",
        "Science",
        "Marketing",
        "Portfolio",
        "Resume",
        "Presentation Cover",
        "Minimal",
        "Modern",
        "Medical",
        "Finance",
        "Travel",
        "Environment"
    )

    val TEMPLATES: List<PresentationTemplateInfo> = listOf(
        PresentationTemplateInfo("tpl_biz_q4", "Executive Q4 Strategy", "Business", "Boardroom KPI review, revenue forecast & roadmap", "business", "#C43E1C", "#FFFBF7"),
        PresentationTemplateInfo("tpl_biz_corp", "Corporate Annual Report", "Business", "Company milestones, financial table & team overview", "professional_blue", "#1D4ED8", "#F8FAFC"),
        PresentationTemplateInfo("tpl_edu_quantum", "STEM Physics Lecture", "Education", "Structured academic lesson with diagrams & quiz slide", "education", "#15803D", "#FEFCE8"),
        PresentationTemplateInfo("tpl_edu_hindi", "डिजिटल शिक्षा नवाचार (Hindi/EN)", "Education", "Bilingual Hindi & English classroom presentation", "business", "#C43E1C", "#FFFBF7"),
        PresentationTemplateInfo("tpl_tech_ai", "AI Cloud Architecture", "Technology", "System architecture, latency benchmarks & API stack", "technology", "#06B6D4", "#090D16"),
        PresentationTemplateInfo("tpl_tech_saas", "SaaS Product Launch", "Technology", "Feature release, user adoption metrics & pricing table", "modern_dark", "#38BDF8", "#0F172A"),
        PresentationTemplateInfo("tpl_school_solar", "Solar System Explorer", "School Project", "Planetary comparison table, facts & visual layout", "modern_dark", "#818CF8", "#0F172A"),
        PresentationTemplateInfo("tpl_school_history", "World Civilizations Timeline", "School Project", "Historical milestones, cultural comparison & summary", "elegant", "#F59E0B", "#1C1917"),
        PresentationTemplateInfo("tpl_sci_biotech", "CRISPR & Genomics Lab", "Science", "Experimental hypothesis, lab data chart & conclusions", "professional_blue", "#0EA5E9", "#F8FAFC"),
        PresentationTemplateInfo("tpl_sci_climate", "Atmospheric Data Study", "Science", "Global temperature anomalies & emissions breakdown", "nature", "#059669", "#F0FDF4"),
        PresentationTemplateInfo("tpl_mkt_growth", "Omnichannel Growth Plan", "Marketing", "Funnel conversion chart, campaign ROI & personas", "creative", "#9333EA", "#FAF5FF"),
        PresentationTemplateInfo("tpl_mkt_brand", "Brand Identity Guidelines", "Marketing", "Typography, voice tone, color palette & market positioning", "elegant", "#F59E0B", "#1C1917"),
        PresentationTemplateInfo("tpl_port_ux", "UX/UI Design Case Study", "Portfolio", "Problem statement, wireframes, user testing & impact", "minimal_white", "#111827", "#FFFFFF"),
        PresentationTemplateInfo("tpl_resume_exec", "Modern Executive CV Deck", "Resume", "Career timeline, core competencies, leadership & metrics", "professional_blue", "#1D4ED8", "#F8FAFC"),
        PresentationTemplateInfo("tpl_cover_keynote", "Keynote Impact Opener", "Presentation Cover", "Bold typography cover, agenda & speaker spotlight", "modern_dark", "#38BDF8", "#0F172A"),
        PresentationTemplateInfo("tpl_min_nordic", "Nordic Minimal Pitch", "Minimal", "Clean whitespace, razor-sharp typography & core metrics", "minimal_white", "#111827", "#FFFFFF"),
        PresentationTemplateInfo("tpl_mod_cyber", "Next-Gen Product Vision", "Modern", "High-contrast dark cards, growth trajectory & milestones", "technology", "#06B6D4", "#090D16"),
        PresentationTemplateInfo("tpl_med_clinical", "Clinical Trial Phase III", "Medical", "Patient cohort outcomes, efficacy chart & safety profile", "professional_blue", "#0EA5E9", "#F8FAFC"),
        PresentationTemplateInfo("tpl_fin_vc", "Series B Investor Pitch", "Finance", "Unit economics, ARR growth column chart & cap table", "business", "#D97706", "#FFFBF7"),
        PresentationTemplateInfo("tpl_trv_himalaya", "Himalayan Expedition Guide", "Travel", "Altitude itinerary, gear checklist table & basecamp route", "nature", "#10B981", "#F0FDF4"),
        PresentationTemplateInfo("tpl_env_carbon", "Net-Zero 2030 Roadmap", "Environment", "Renewable transition chart, ESG targets & impact metrics", "nature", "#059669", "#F0FDF4")
    )

    fun buildSlideFromLayout(
        layout: SlideLayoutType,
        theme: PresentationTheme,
        slideNumber: Int = 1
    ): SlideModel {
        val bg = SlideBackground(
            type = if (theme.bgGradientEndHex != null) BackgroundType.GRADIENT else BackgroundType.SOLID,
            colorHex = theme.bgHex,
            gradientEndHex = theme.bgGradientEndHex ?: theme.bgHex
        )

        val elements = mutableListOf<SlideElement>()
        when (layout) {
            SlideLayoutType.TITLE_SLIDE -> {
                elements.add(
                    SlideElement(
                        type = ElementType.SHAPE,
                        shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                        x = 70f, y = 90f, width = 120f, height = 10f,
                        fillColorHex = theme.primaryAccentHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 70f, y = 120f, width = 820f, height = 140f,
                        text = "Presentation Title Goes Here",
                        fontFamily = theme.headingFont,
                        fontSize = 44f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 1
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 70f, y = 275f, width = 760f, height = 90f,
                        text = "Subtitle, key strategic objective, or presenter details",
                        fontFamily = theme.bodyFont,
                        fontSize = 22f,
                        textColorHex = theme.bodyColorHex,
                        zIndex = 2
                    )
                )
            }

            SlideLayoutType.TITLE_AND_CONTENT -> {
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 40f, width = 840f, height = 70f,
                        text = "Slide $slideNumber Headline",
                        fontFamily = theme.headingFont,
                        fontSize = 32f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 130f, width = 840f, height = 340f,
                        text = "First key insight or takeaway for your audience\nSecond supporting point with clear measurable impact\nThird action item or strategic recommendation",
                        fontFamily = theme.bodyFont,
                        fontSize = 22f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        borderColorHex = theme.primaryAccentHex,
                        borderWidth = 1.5f,
                        zIndex = 1
                    )
                )
            }

            SlideLayoutType.SECTION_HEADER -> {
                elements.add(
                    SlideElement(
                        type = ElementType.SHAPE,
                        shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                        x = 60f, y = 60f, width = 840f, height = 420f,
                        fillColorHex = theme.primaryAccentHex,
                        gradientEndColorHex = theme.secondaryAccentHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 100f, y = 170f, width = 760f, height = 120f,
                        text = "0$slideNumber — Section Header",
                        fontFamily = theme.headingFont,
                        fontSize = 42f,
                        isBold = true,
                        textColorHex = "#FFFFFF",
                        zIndex = 1
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 100f, y = 300f, width = 700f, height = 80f,
                        text = "Transitioning to the next phase of the presentation",
                        fontSize = 20f,
                        textColorHex = "#F8FAFC",
                        zIndex = 2
                    )
                )
            }

            SlideLayoutType.TWO_CONTENT -> {
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 40f, width = 840f, height = 65f,
                        text = "Two-Column Overview",
                        fontFamily = theme.headingFont,
                        fontSize = 30f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 125f, width = 405f, height = 355f,
                        text = "Core Pillars\nHigh reliability\nScalable architecture\nUser-centric workflow",
                        fontSize = 20f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        borderColorHex = theme.primaryAccentHex,
                        borderWidth = 1.5f,
                        zIndex = 1
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 495f, y = 125f, width = 405f, height = 355f,
                        text = "Key Outcomes\n38% faster delivery\nZero data loss\nCross-platform reach",
                        fontSize = 20f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        borderColorHex = theme.secondaryAccentHex,
                        borderWidth = 1.5f,
                        zIndex = 2
                    )
                )
            }

            SlideLayoutType.COMPARISON -> {
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 36f, width = 840f, height = 60f,
                        text = "Side-by-Side Comparison",
                        fontSize = 30f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.SHAPE,
                        shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                        x = 60f, y = 110f, width = 405f, height = 52f,
                        fillColorHex = theme.primaryAccentHex,
                        text = "Option A — Current State",
                        textColorHex = "#FFFFFF",
                        fontSize = 18f,
                        isBold = true,
                        zIndex = 1
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.SHAPE,
                        shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                        x = 495f, y = 110f, width = 405f, height = 52f,
                        fillColorHex = theme.secondaryAccentHex,
                        text = "Option B — Proposed Model",
                        textColorHex = "#FFFFFF",
                        fontSize = 18f,
                        isBold = true,
                        zIndex = 2
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 175f, width = 405f, height = 305f,
                        text = "Manual workflow steps\nHigher operational overhead\nLimited real-time visibility",
                        fontSize = 19f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        zIndex = 3
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 495f, y = 175f, width = 405f, height = 305f,
                        text = "Automated pipeline\n45% lower unit cost\nInstant analytics dashboard",
                        fontSize = 19f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        zIndex = 4
                    )
                )
            }

            SlideLayoutType.BLANK -> {
                // Blank canvas ready for custom elements
            }

            SlideLayoutType.PICTURE_WITH_CAPTION -> {
                elements.add(
                    SlideElement(
                        type = ElementType.SHAPE,
                        shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                        x = 60f, y = 45f, width = 840f, height = 320f,
                        fillColorHex = theme.primaryAccentHex,
                        gradientEndColorHex = theme.secondaryAccentHex,
                        text = "Tap Image tool below to insert photo or illustration",
                        textColorHex = "#FFFFFF",
                        fontSize = 20f,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 385f, width = 840f, height = 110f,
                        text = "Visual Highlight — Add a concise caption explaining the photograph or diagram above.",
                        fontSize = 20f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 1
                    )
                )
            }

            SlideLayoutType.TITLE_ONLY -> {
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 48f, width = 840f, height = 80f,
                        text = "Key Topic Title",
                        fontFamily = theme.headingFont,
                        fontSize = 34f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 0
                    )
                )
            }

            SlideLayoutType.CONTENT_WITH_IMAGE -> {
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 40f, width = 840f, height = 65f,
                        text = "Feature Spotlight & Visual",
                        fontSize = 30f,
                        isBold = true,
                        textColorHex = theme.titleColorHex,
                        zIndex = 0
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.TEXT,
                        x = 60f, y = 125f, width = 430f, height = 355f,
                        text = "Key capability overview\nBuilt for mobile & tablet\nFull OOXML .pptx compatibility\nInstant PDF export",
                        fontSize = 20f,
                        listType = ListStyleType.BULLET,
                        textColorHex = theme.bodyColorHex,
                        fillColorHex = theme.surfaceCardHex,
                        zIndex = 1
                    )
                )
                elements.add(
                    SlideElement(
                        type = ElementType.CHART,
                        chartKind = ChartKind.COLUMN,
                        chartTitle = "Growth Metrics",
                        x = 515f, y = 125f, width = 385f, height = 355f,
                        zIndex = 2
                    )
                )
            }
        }

        return SlideModel(
            id = UUID.randomUUID().toString(),
            layoutType = layout,
            background = bg,
            elements = elements,
            speakerNotes = "Speaker notes for ${layout.displayName} (Slide $slideNumber)."
        )
    }

    fun createPresentationFromTemplate(
        template: PresentationTemplateInfo,
        customName: String? = null,
        aspectRatio: SlideAspectRatio = SlideAspectRatio.WIDESCREEN_16_9
    ): PresentationDocument {
        val theme = BuiltInThemes.getById(template.themeId)
        val isHindi = template.id == "tpl_edu_hindi"
        val bg = SlideBackground(
            type = if (theme.bgGradientEndHex != null) BackgroundType.GRADIENT else BackgroundType.SOLID,
            colorHex = theme.bgHex,
            gradientEndHex = theme.bgGradientEndHex ?: theme.bgHex
        )

        // Slide 1: Cover Slide
        val slide1 = SlideModel(
            layoutType = SlideLayoutType.TITLE_SLIDE,
            background = bg,
            speakerNotes = "Welcome everyone to ${template.title}. Introduce core objectives.",
            elements = listOf(
                SlideElement(
                    type = ElementType.SHAPE,
                    shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                    x = 68f, y = 78f, width = 180f, height = 36f,
                    fillColorHex = theme.primaryAccentHex,
                    text = template.category.uppercase(),
                    textColorHex = "#FFFFFF",
                    fontSize = 13f,
                    isBold = true,
                    zIndex = 0
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 68f, y = 135f, width = 824f, height = 150f,
                    text = if (isHindi) "डिजिटल शिक्षा और नवाचार\nDigital Education & Innovation" else template.title,
                    fontFamily = if (isHindi) "Noto Sans Devanagari" else theme.headingFont,
                    fontSize = if (isHindi) 36f else 44f,
                    isBold = true,
                    textColorHex = theme.titleColorHex,
                    zIndex = 1
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 68f, y = 300f, width = 760f, height = 90f,
                    text = if (isHindi) "आधुनिक कक्षाओं के लिए स्मार्ट शिक्षण समाधान • प्रस्तुतकर्ता: PPT Studio" else template.subtitle,
                    fontFamily = if (isHindi) "Noto Sans Devanagari" else theme.bodyFont,
                    fontSize = 21f,
                    textColorHex = theme.bodyColorHex,
                    zIndex = 2
                ),
                SlideElement(
                    type = ElementType.SHAPE,
                    shapeKind = ShapeKind.RECTANGLE,
                    x = 68f, y = 435f, width = 824f, height = 6f,
                    fillColorHex = theme.secondaryAccentHex,
                    zIndex = 3
                )
            )
        )

        // Slide 2: Executive Agenda / Key Objectives
        val slide2 = SlideModel(
            layoutType = SlideLayoutType.TITLE_AND_CONTENT,
            background = bg,
            speakerNotes = "Walk through the four main pillars of ${template.title}.",
            elements = listOf(
                SlideElement(
                    type = ElementType.TEXT,
                    x = 60f, y = 42f, width = 840f, height = 64f,
                    text = if (isHindi) "मुख्य उद्देश्य (Key Objectives)" else "Executive Summary & Pillars",
                    fontFamily = if (isHindi) "Noto Sans Devanagari" else theme.headingFont,
                    fontSize = 32f,
                    isBold = true,
                    textColorHex = theme.titleColorHex,
                    zIndex = 0
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 60f, y = 125f, width = 840f, height = 355f,
                    text = if (isHindi) {
                        "छात्रों के लिए इंटरैक्टिव और सुलभ पाठ्यक्रम\nडेटा-आधारित प्रगति मूल्यांकन और विश्लेषण\nहिंदी और अंग्रेजी भाषा में पूर्ण समर्थन\nऑफ़लाइन और स्मार्ट क्लासरूम एकीकरण"
                    } else {
                        "Strategic alignment across core product & operational initiatives\nData-backed decision making with real-time performance tracking\nMeasurable efficiency gains and sustainable resource allocation\nClear milestone ownership for the upcoming quarter"
                    },
                    fontFamily = if (isHindi) "Noto Sans Devanagari" else theme.bodyFont,
                    fontSize = 22f,
                    listType = ListStyleType.BULLET,
                    lineSpacing = 1.35f,
                    textColorHex = theme.bodyColorHex,
                    fillColorHex = theme.surfaceCardHex,
                    borderColorHex = theme.primaryAccentHex,
                    borderWidth = 1.5f,
                    zIndex = 1
                )
            )
        )

        // Slide 3: Data Analytics & Chart Slide
        val slide3 = SlideModel(
            layoutType = SlideLayoutType.CONTENT_WITH_IMAGE,
            background = bg,
            speakerNotes = "Highlight the upward trajectory shown in the chart.",
            elements = listOf(
                SlideElement(
                    type = ElementType.TEXT,
                    x = 60f, y = 40f, width = 840f, height = 64f,
                    text = if (isHindi) "प्रगति और परिणाम (Growth Analytics)" else "Performance & Benchmark Analysis",
                    fontSize = 30f,
                    isBold = true,
                    textColorHex = theme.titleColorHex,
                    zIndex = 0
                ),
                SlideElement(
                    type = ElementType.CHART,
                    chartKind = ChartKind.COLUMN,
                    chartTitle = "${template.category} Trajectory",
                    chartCategories = listOf("Q1", "Q2", "Q3", "Q4"),
                    chartSeries = listOf(
                        ChartSeries("Target", listOf(45f, 62f, 78f, 95f), theme.primaryAccentHex),
                        ChartSeries("Actual", listOf(48f, 67f, 84f, 108f), theme.secondaryAccentHex)
                    ),
                    x = 60f, y = 120f, width = 520f, height = 360f,
                    zIndex = 1
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 600f, y = 120f, width = 300f, height = 360f,
                    text = "Key Metrics\n+34% YoY Growth\n99.4% Reliability\n2.4x ROI Multiplier\nAhead of Q4 Forecast",
                    fontSize = 20f,
                    listType = ListStyleType.BULLET,
                    textColorHex = theme.bodyColorHex,
                    fillColorHex = theme.surfaceCardHex,
                    borderColorHex = theme.secondaryAccentHex,
                    borderWidth = 1.5f,
                    zIndex = 2
                )
            )
        )

        // Slide 4: Structured Comparison Table
        val slide4 = SlideModel(
            layoutType = SlideLayoutType.TITLE_AND_CONTENT,
            background = bg,
            speakerNotes = "Review the milestone breakdown table row by row.",
            elements = listOf(
                SlideElement(
                    type = ElementType.TEXT,
                    x = 60f, y = 40f, width = 840f, height = 64f,
                    text = "Action Plan & Milestone Matrix",
                    fontSize = 30f,
                    isBold = true,
                    textColorHex = theme.titleColorHex,
                    zIndex = 0
                ),
                SlideElement(
                    type = ElementType.TABLE,
                    x = 60f, y = 125f, width = 840f, height = 340f,
                    tableRows = 4,
                    tableCols = 4,
                    tableHeaderBgHex = theme.primaryAccentHex,
                    tableHeaderTextHex = "#FFFFFF",
                    tableCells = listOf(
                        listOf("Workstream", "Owner", "Timeline", "Status"),
                        listOf("Phase 1: Research & Discovery", "Strategy Team", "Weeks 1–3", "Completed"),
                        listOf("Phase 2: Core Execution", "Engineering", "Weeks 4–8", "In Progress"),
                        listOf("Phase 3: Launch & Scale", "Operations", "Weeks 9–12", "Scheduled")
                    ),
                    fontSize = 16f,
                    zIndex = 1
                )
            )
        )

        // Slide 5: Closing & Next Steps
        val slide5 = SlideModel(
            layoutType = SlideLayoutType.SECTION_HEADER,
            background = bg,
            speakerNotes = "Thank the audience and open the floor for Q&A.",
            elements = listOf(
                SlideElement(
                    type = ElementType.SHAPE,
                    shapeKind = ShapeKind.ROUNDED_RECTANGLE,
                    x = 60f, y = 60f, width = 840f, height = 420f,
                    fillColorHex = theme.primaryAccentHex,
                    gradientEndColorHex = theme.secondaryAccentHex,
                    zIndex = 0
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 100f, y = 155f, width = 760f, height = 110f,
                    text = if (isHindi) "धन्यवाद! (Thank You & Q&A)" else "Thank You — Questions & Discussion",
                    fontSize = 40f,
                    isBold = true,
                    textColorHex = "#FFFFFF",
                    zIndex = 1
                ),
                SlideElement(
                    type = ElementType.TEXT,
                    x = 100f, y = 280f, width = 760f, height = 90f,
                    text = "Ready to export as genuine Microsoft PowerPoint (.pptx) or PDF.",
                    fontSize = 21f,
                    textColorHex = "#F8FAFC",
                    zIndex = 2
                )
            )
        )

        return PresentationDocument(
            id = UUID.randomUUID().toString(),
            name = customName?.takeIf { it.isNotBlank() } ?: template.title,
            aspectRatio = aspectRatio,
            themeId = template.themeId,
            slides = listOf(slide1, slide2, slide3, slide4, slide5)
        )
    }
}
