package com.example.data.local

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "presentations")
data class PresentationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val filePath: String,
    val externalUriString: String? = null,
    val thumbnailPath: String? = null,
    val slideCount: Int = 1,
    val fileSizeBytes: Long = 0L,
    val aspectRatioName: String = "WIDESCREEN_16_9",
    val themeId: String = "professional_blue",
    val lastModified: Long = System.currentTimeMillis(),
    val isAvailable: Boolean = true
)

@Dao
interface PresentationDao {
    @Query("SELECT * FROM presentations ORDER BY lastModified DESC")
    fun getAllPresentationsFlow(): Flow<List<PresentationEntity>>

    @Query("SELECT * FROM presentations WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): PresentationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PresentationEntity)

    @Query("DELETE FROM presentations WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT COUNT(*) FROM presentations")
    suspend fun getCount(): Int
}

@Database(entities = [PresentationEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun presentationDao(): PresentationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ppt_studio_db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
