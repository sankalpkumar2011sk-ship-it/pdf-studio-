package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PresentationRepository
import com.example.data.PresentationTemplateInfo
import com.example.data.TemplateCatalog
import com.example.data.UserSettings
import com.example.data.local.PresentationEntity
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class AppScreen {
    HOME,
    CREATE_NEW,
    TEMPLATES,
    MY_PRESENTATIONS,
    SETTINGS,
    EDITOR,
    VIEWER,
    SLIDESHOW
}

enum class SortOption(val label: String) {
    DATE("Date Modified"),
    NAME("Name (A-Z)"),
    SIZE("File Size")
}

enum class SaveStatus {
    IDLE, SAVING, SAVED, ERROR
}

class PptStudioViewModel(application: Application) : AndroidViewModel(application) {

    val repository = PresentationRepository(application.applicationContext)

    val presentations: StateFlow<List<PresentationEntity>> = repository.allPresentations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<UserSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _previousScreen = MutableStateFlow(AppScreen.HOME)

    private val _activeDocument = MutableStateFlow<PresentationDocument?>(null)
    val activeDocument: StateFlow<PresentationDocument?> = _activeDocument.asStateFlow()

    private val _selectedSlideIndex = MutableStateFlow(0)
    val selectedSlideIndex: StateFlow<Int> = _selectedSlideIndex.asStateFlow()

    private val _selectedElementId = MutableStateFlow<String?>(null)
    val selectedElementId: StateFlow<String?> = _selectedElementId.asStateFlow()

    private val _copiedSlide = MutableStateFlow<SlideModel?>(null)
    val copiedSlide: StateFlow<SlideModel?> = _copiedSlide.asStateFlow()

    private val _copiedText = MutableStateFlow<String?>(null)
    val copiedText: StateFlow<String?> = _copiedText.asStateFlow()

    // Undo / Redo Stacks (preserved across slide switches)
    private val undoStack = ArrayDeque<PresentationDocument>()
    private val redoStack = ArrayDeque<PresentationDocument>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _saveStatus = MutableStateFlow(SaveStatus.IDLE)
    val saveStatus: StateFlow<SaveStatus> = _saveStatus.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _errorDialogMessage = MutableStateFlow<String?>(null)
    val errorDialogMessage: StateFlow<String?> = _errorDialogMessage.asStateFlow()

    private val _recoverableDraft = MutableStateFlow<PresentationDocument?>(null)
    val recoverableDraft: StateFlow<PresentationDocument?> = _recoverableDraft.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.DATE)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _isGridView = MutableStateFlow(true)
    val isGridView: StateFlow<Boolean> = _isGridView.asStateFlow()

    private val _cacheSizeBytes = MutableStateFlow(0L)
    val cacheSizeBytes: StateFlow<Long> = _cacheSizeBytes.asStateFlow()

    private var autosaveJob: Job? = null

    init {
        viewModelScope.launch {
            repository.ensureStarterPresentationIfNeeded()
            _recoverableDraft.value = repository.readAutosaveDraft()
            _cacheSizeBytes.value = repository.getThumbnailCacheSizeBytes()
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            _previousScreen.value = _currentScreen.value
            _currentScreen.value = screen
        }
        if (screen == AppScreen.SETTINGS) {
            viewModelScope.launch {
                _cacheSizeBytes.value = repository.getThumbnailCacheSizeBytes()
            }
        }
    }

    fun navigateBack() {
        when (_currentScreen.value) {
            AppScreen.SLIDESHOW -> {
                _currentScreen.value = if (_previousScreen.value == AppScreen.VIEWER) AppScreen.VIEWER else AppScreen.EDITOR
            }
            AppScreen.EDITOR, AppScreen.VIEWER -> {
                _currentScreen.value = AppScreen.HOME
            }
            AppScreen.CREATE_NEW, AppScreen.TEMPLATES, AppScreen.MY_PRESENTATIONS, AppScreen.SETTINGS -> {
                _currentScreen.value = AppScreen.HOME
            }
            AppScreen.HOME -> {}
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    fun toggleGridView() {
        _isGridView.value = !_isGridView.value
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun dismissErrorDialog() {
        _errorDialogMessage.value = null
    }

    fun recoverUnsavedDraft() {
        val draft = _recoverableDraft.value ?: return
        _recoverableDraft.value = null
        openDocumentInEditor(draft)
        _statusMessage.value = "Recovered unsaved presentation: ${draft.name}"
    }

    fun dismissRecoverableDraft() {
        _recoverableDraft.value = null
        viewModelScope.launch { repository.clearAutosaveDraft() }
    }

    // Create Blank or Template Presentation
    fun createNewBlankPresentation(
        name: String,
        aspectRatio: SlideAspectRatio,
        themeId: String,
        customW: Float = 960f,
        customH: Float = 600f
    ) {
        val theme = BuiltInThemes.getById(themeId)
        val slide1 = TemplateCatalog.buildSlideFromLayout(SlideLayoutType.TITLE_SLIDE, theme, 1)
        val slide2 = TemplateCatalog.buildSlideFromLayout(SlideLayoutType.TITLE_AND_CONTENT, theme, 2)
        val doc = PresentationDocument(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Untitled Presentation" },
            aspectRatio = aspectRatio,
            customWidthPt = customW,
            customHeightPt = customH,
            themeId = themeId,
            slides = listOf(slide1, slide2)
        )
        viewModelScope.launch {
            _isBusy.value = true
            val saved = repository.savePresentationToLocal(doc)
            _isBusy.value = false
            openDocumentInEditor(saved)
        }
    }

    fun createPresentationFromTemplate(
        template: PresentationTemplateInfo,
        customName: String? = null,
        aspectRatio: SlideAspectRatio = settings.value.defaultAspectRatio
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val doc = TemplateCatalog.createPresentationFromTemplate(template, customName, aspectRatio)
            val saved = repository.savePresentationToLocal(doc)
            _isBusy.value = false
            openDocumentInEditor(saved)
        }
    }

    fun openPresentationById(id: String, inViewerMode: Boolean = false) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val doc = repository.loadPresentationById(id)
                if (doc == null) {
                    _errorDialogMessage.value = "Presentation file is unavailable or was moved from storage."
                } else {
                    if (inViewerMode) {
                        openDocumentInViewer(doc)
                    } else {
                        openDocumentInEditor(doc)
                    }
                }
            } catch (e: Exception) {
                _errorDialogMessage.value = e.message ?: "Failed to load presentation."
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun importExternalPresentationUri(uri: Uri, openInViewer: Boolean = false) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val doc = repository.importPresentationFromUri(uri)
                if (doc.hasUnsupportedElementsWarning && !doc.formatWarningMessage.isNullOrBlank()) {
                    _statusMessage.value = doc.formatWarningMessage
                }
                if (openInViewer) {
                    openDocumentInViewer(doc)
                } else {
                    openDocumentInEditor(doc)
                }
            } catch (e: Exception) {
                _errorDialogMessage.value = e.message ?: "Could not open the selected PowerPoint file."
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun openDocumentInEditor(doc: PresentationDocument) {
        undoStack.clear()
        redoStack.clear()
        updateUndoRedoFlags()
        _activeDocument.value = doc
        _selectedSlideIndex.value = 0
        _selectedElementId.value = null
        _saveStatus.value = SaveStatus.SAVED
        _currentScreen.value = AppScreen.EDITOR
    }

    fun openDocumentInViewer(doc: PresentationDocument) {
        _activeDocument.value = doc
        _selectedSlideIndex.value = 0
        _selectedElementId.value = null
        _currentScreen.value = AppScreen.VIEWER
    }

    fun startSlideshow(fromFirstSlide: Boolean = false) {
        val doc = _activeDocument.value ?: return
        if (fromFirstSlide) {
            val firstVisible = doc.slides.indexOfFirst { !it.isHidden }.takeIf { it >= 0 } ?: 0
            _selectedSlideIndex.value = firstVisible
        }
        _previousScreen.value = _currentScreen.value
        _currentScreen.value = AppScreen.SLIDESHOW
    }

    // Core State Mutation with Undo/Redo & Autosave
    private fun commitEdit(recordHistory: Boolean = true, transform: (PresentationDocument) -> PresentationDocument) {
        val current = _activeDocument.value ?: return
        if (recordHistory) {
            if (undoStack.size >= 40) undoStack.removeFirst()
            undoStack.addLast(current)
            redoStack.clear()
            updateUndoRedoFlags()
        }
        val updated = transform(current).copy(updatedAt = System.currentTimeMillis())
        _activeDocument.value = updated
        triggerAutosave(updated)
    }

    private fun updateUndoRedoFlags() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun undo() {
        val current = _activeDocument.value ?: return
        if (undoStack.isEmpty()) return
        val prev = undoStack.removeLast()
        redoStack.addLast(current)
        updateUndoRedoFlags()
        _activeDocument.value = prev
        _selectedSlideIndex.value = _selectedSlideIndex.value.coerceIn(0, (prev.slides.size - 1).coerceAtLeast(0))
        triggerAutosave(prev)
    }

    fun redo() {
        val current = _activeDocument.value ?: return
        if (redoStack.isEmpty()) return
        val next = redoStack.removeLast()
        undoStack.addLast(current)
        updateUndoRedoFlags()
        _activeDocument.value = next
        _selectedSlideIndex.value = _selectedSlideIndex.value.coerceIn(0, (next.slides.size - 1).coerceAtLeast(0))
        triggerAutosave(next)
    }

    private fun triggerAutosave(doc: PresentationDocument) {
        if (!settings.value.autosaveEnabled) return
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            _saveStatus.value = SaveStatus.SAVING
            delay(450)
            repository.writeAutosaveDraft(doc)
            repository.savePresentationToLocal(doc)
            _saveStatus.value = SaveStatus.SAVED
        }
    }

    fun saveActivePresentationNow() {
        val doc = _activeDocument.value ?: return
        viewModelScope.launch {
            _saveStatus.value = SaveStatus.SAVING
            try {
                val saved = repository.savePresentationToLocal(doc)
                _activeDocument.value = saved
                _saveStatus.value = SaveStatus.SAVED
                _statusMessage.value = "Saved \"${saved.name}.pptx\""
            } catch (e: Exception) {
                _saveStatus.value = SaveStatus.ERROR
                _errorDialogMessage.value = "Failed to save presentation: ${e.message}"
            }
        }
    }

    fun updatePresentationName(newName: String) {
        if (newName.isBlank()) return
        commitEdit { it.copy(name = newName.trim()) }
    }

    // Slide Selection & Management
    fun selectSlide(index: Int) {
        val doc = _activeDocument.value ?: return
        if (index in doc.slides.indices) {
            _selectedSlideIndex.value = index
            _selectedElementId.value = null
        }
    }

    fun selectElement(elementId: String?) {
        _selectedElementId.value = elementId
    }

    fun addSlide(layout: SlideLayoutType = SlideLayoutType.TITLE_AND_CONTENT) {
        val doc = _activeDocument.value ?: return
        val theme = BuiltInThemes.getById(doc.themeId)
        val newSlide = TemplateCatalog.buildSlideFromLayout(layout, theme, doc.slides.size + 1)
        val insertIdx = (_selectedSlideIndex.value + 1).coerceIn(0, doc.slides.size)
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            mutable.add(insertIdx, newSlide)
            d.copy(slides = mutable)
        }
        _selectedSlideIndex.value = insertIdx
        _selectedElementId.value = null
    }

    fun duplicateSlide(index: Int = _selectedSlideIndex.value) {
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(index) ?: return
        val copySlide = slide.copy(
            id = UUID.randomUUID().toString(),
            elements = slide.elements.map { it.copy(id = UUID.randomUUID().toString()) }
        )
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            mutable.add(index + 1, copySlide)
            d.copy(slides = mutable)
        }
        _selectedSlideIndex.value = index + 1
    }

    fun deleteSlide(index: Int = _selectedSlideIndex.value) {
        val doc = _activeDocument.value ?: return
        if (doc.slides.size <= 1) {
            _statusMessage.value = "A presentation must contain at least one slide."
            return
        }
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            if (index in mutable.indices) mutable.removeAt(index)
            d.copy(slides = mutable)
        }
        _selectedSlideIndex.value = (index - 1).coerceAtLeast(0)
        _selectedElementId.value = null
    }

    fun moveSlide(fromIndex: Int, toIndex: Int) {
        val doc = _activeDocument.value ?: return
        if (fromIndex !in doc.slides.indices || toIndex !in doc.slides.indices || fromIndex == toIndex) return
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val item = mutable.removeAt(fromIndex)
            mutable.add(toIndex, item)
            d.copy(slides = mutable)
        }
        _selectedSlideIndex.value = toIndex
    }

    fun copyCurrentSlide() {
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        _copiedSlide.value = slide
        _statusMessage.value = "Slide copied to clipboard"
    }

    fun pasteCopiedSlide() {
        val clip = _copiedSlide.value ?: return
        val doc = _activeDocument.value ?: return
        val pasted = clip.copy(
            id = UUID.randomUUID().toString(),
            elements = clip.elements.map { it.copy(id = UUID.randomUUID().toString()) }
        )
        val insertIdx = (_selectedSlideIndex.value + 1).coerceIn(0, doc.slides.size)
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            mutable.add(insertIdx, pasted)
            d.copy(slides = mutable)
        }
        _selectedSlideIndex.value = insertIdx
    }

    fun changeSlideLayout(layout: SlideLayoutType) {
        val doc = _activeDocument.value ?: return
        val idx = _selectedSlideIndex.value
        val theme = BuiltInThemes.getById(doc.themeId)
        val templateSlide = TemplateCatalog.buildSlideFromLayout(layout, theme, idx + 1)
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val existing = mutable.getOrNull(idx) ?: return@commitEdit d
            mutable[idx] = existing.copy(
                layoutType = layout,
                elements = if (existing.elements.isEmpty()) templateSlide.elements else existing.elements
            )
            d.copy(slides = mutable)
        }
    }

    fun toggleSlideHidden(index: Int = _selectedSlideIndex.value) {
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val s = mutable.getOrNull(index) ?: return@commitEdit d
            mutable[index] = s.copy(isHidden = !s.isHidden)
            d.copy(slides = mutable)
        }
    }

    fun updateSpeakerNotes(notes: String) {
        val idx = _selectedSlideIndex.value
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val s = mutable.getOrNull(idx) ?: return@commitEdit d
            mutable[idx] = s.copy(speakerNotes = notes)
            d.copy(slides = mutable)
        }
    }

    // Slide Background & Theme Application
    fun updateSlideBackground(bg: SlideBackground, applyToAllSlides: Boolean = false) {
        val idx = _selectedSlideIndex.value
        commitEdit { d ->
            val updatedSlides = d.slides.mapIndexed { i, s ->
                if (applyToAllSlides || i == idx) s.copy(background = bg) else s
            }
            d.copy(slides = updatedSlides)
        }
    }

    fun applyTheme(themeId: String, applyToAllSlides: Boolean = true) {
        val theme = BuiltInThemes.getById(themeId)
        val idx = _selectedSlideIndex.value
        val newBg = SlideBackground(
            type = if (theme.bgGradientEndHex != null) BackgroundType.GRADIENT else BackgroundType.SOLID,
            colorHex = theme.bgHex,
            gradientEndHex = theme.bgGradientEndHex ?: theme.bgHex
        )
        commitEdit { d ->
            val updatedSlides = d.slides.mapIndexed { i, s ->
                if (applyToAllSlides || i == idx) {
                    s.copy(
                        background = newBg,
                        themeOverrideId = themeId
                    )
                } else s
            }
            d.copy(themeId = if (applyToAllSlides) themeId else d.themeId, slides = updatedSlides)
        }
    }

    // Element Insertion & Manipulation
    fun insertTextBox(initialText: String = "Double-tap or use Format bar to edit text") {
        val doc = _activeDocument.value ?: return
        val theme = BuiltInThemes.getById(doc.themeId)
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val newEl = SlideElement(
            type = ElementType.TEXT,
            x = 120f,
            y = 140f,
            width = 480f,
            height = 110f,
            text = initialText,
            fontFamily = theme.bodyFont,
            fontSize = 24f,
            textColorHex = theme.titleColorHex,
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(newEl)
    }

    fun insertShape(shapeKind: ShapeKind, freehandPoints: List<Point2D> = emptyList()) {
        val doc = _activeDocument.value ?: return
        val theme = BuiltInThemes.getById(doc.themeId)
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val newEl = SlideElement(
            type = ElementType.SHAPE,
            shapeKind = shapeKind,
            x = 220f,
            y = 150f,
            width = if (shapeKind == ShapeKind.LINE) 320f else 220f,
            height = if (shapeKind == ShapeKind.LINE) 36f else 180f,
            fillColorHex = theme.primaryAccentHex,
            borderColorHex = theme.secondaryAccentHex,
            borderWidth = if (shapeKind == ShapeKind.LINE || shapeKind == ShapeKind.FREEHAND) 4f else 0f,
            textColorHex = "#FFFFFF",
            fontSize = 18f,
            freehandPoints = freehandPoints,
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(newEl)
    }

    fun insertImageFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                val path = repository.copyImageUriToInternalStorage(uri)
                insertImageWithPath(path)
            } catch (e: Exception) {
                _errorDialogMessage.value = "Failed to insert image: ${e.message}"
            }
        }
    }

    fun insertImageFromBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            try {
                val path = repository.saveBitmapToInternalStorage(bitmap)
                insertImageWithPath(path)
            } catch (e: Exception) {
                _errorDialogMessage.value = "Failed to capture camera image: ${e.message}"
            }
        }
    }

    fun replaceSelectedImageFromUri(uri: Uri) {
        val elId = _selectedElementId.value ?: return
        viewModelScope.launch {
            try {
                val path = repository.copyImageUriToInternalStorage(uri)
                updateSelectedElement { it.copy(imagePath = path) }
            } catch (e: Exception) {
                _errorDialogMessage.value = "Failed to replace image: ${e.message}"
            }
        }
    }

    private fun insertImageWithPath(path: String) {
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val newEl = SlideElement(
            type = ElementType.IMAGE,
            x = 200f,
            y = 110f,
            width = 380f,
            height = 280f,
            imagePath = path,
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(newEl)
    }

    fun insertTable(rows: Int, cols: Int) {
        val doc = _activeDocument.value ?: return
        val theme = BuiltInThemes.getById(doc.themeId)
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val rCount = rows.coerceIn(1, 10)
        val cCount = cols.coerceIn(1, 8)
        val cells = List(rCount) { r ->
            List(cCount) { c ->
                if (r == 0) "Header ${c + 1}" else "R${r}C${c + 1}"
            }
        }
        val newEl = SlideElement(
            type = ElementType.TABLE,
            x = 120f,
            y = 130f,
            width = 680f,
            height = (rCount * 58f).coerceIn(140f, 360f),
            tableRows = rCount,
            tableCols = cCount,
            tableCells = cells,
            tableHeaderBgHex = theme.primaryAccentHex,
            tableHeaderTextHex = "#FFFFFF",
            fontSize = 15f,
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(newEl)
    }

    fun insertChart(chartKind: ChartKind) {
        val doc = _activeDocument.value ?: return
        val theme = BuiltInThemes.getById(doc.themeId)
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val newEl = SlideElement(
            type = ElementType.CHART,
            chartKind = chartKind,
            chartTitle = "${chartKind.label} Analysis",
            x = 160f,
            y = 110f,
            width = 580f,
            height = 350f,
            chartCategories = listOf("Q1", "Q2", "Q3", "Q4"),
            chartSeries = listOf(
                ChartSeries("Series A", listOf(38f, 54f, 72f, 89f), theme.primaryAccentHex),
                ChartSeries("Series B", listOf(24f, 39f, 51f, 68f), theme.secondaryAccentHex)
            ),
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(newEl)
    }

    private fun addElementToCurrentSlide(newElement: SlideElement) {
        val idx = _selectedSlideIndex.value
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val slide = mutable.getOrNull(idx) ?: return@commitEdit d
            mutable[idx] = slide.copy(elements = slide.elements + newElement)
            d.copy(slides = mutable)
        }
        _selectedElementId.value = newElement.id
    }

    fun updateSelectedElement(recordHistory: Boolean = true, transform: (SlideElement) -> SlideElement) {
        val elId = _selectedElementId.value ?: return
        updateElementById(elId, recordHistory, transform)
    }

    fun updateElementById(elementId: String, recordHistory: Boolean = true, transform: (SlideElement) -> SlideElement) {
        val idx = _selectedSlideIndex.value
        commitEdit(recordHistory = recordHistory) { d ->
            val mutable = d.slides.toMutableList()
            val slide = mutable.getOrNull(idx) ?: return@commitEdit d
            val updatedElements = slide.elements.map { el ->
                if (el.id == elementId) transform(el) else el
            }
            mutable[idx] = slide.copy(elements = updatedElements)
            d.copy(slides = mutable)
        }
    }

    fun duplicateSelectedElement() {
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val el = slide.elements.find { it.id == _selectedElementId.value } ?: return
        val copyEl = el.copy(
            id = UUID.randomUUID().toString(),
            x = (el.x + 28f).coerceAtMost(doc.logicalWidth - 60f),
            y = (el.y + 28f).coerceAtMost(doc.logicalHeight - 60f),
            zIndex = (slide.elements.maxOfOrNull { it.zIndex } ?: 0) + 1
        )
        addElementToCurrentSlide(copyEl)
    }

    fun deleteSelectedElement() {
        val elId = _selectedElementId.value ?: return
        val idx = _selectedSlideIndex.value
        commitEdit { d ->
            val mutable = d.slides.toMutableList()
            val slide = mutable.getOrNull(idx) ?: return@commitEdit d
            mutable[idx] = slide.copy(elements = slide.elements.filterNot { it.id == elId })
            d.copy(slides = mutable)
        }
        _selectedElementId.value = null
    }

    fun bringSelectedElementForward() {
        val elId = _selectedElementId.value ?: return
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val maxZ = slide.elements.maxOfOrNull { it.zIndex } ?: 0
        updateElementById(elId) { it.copy(zIndex = maxZ + 1) }
    }

    fun sendSelectedElementBackward() {
        val elId = _selectedElementId.value ?: return
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val minZ = slide.elements.minOfOrNull { it.zIndex } ?: 0
        updateElementById(elId) { it.copy(zIndex = minZ - 1) }
    }

    fun copySelectedText() {
        val doc = _activeDocument.value ?: return
        val slide = doc.slides.getOrNull(_selectedSlideIndex.value) ?: return
        val el = slide.elements.find { it.id == _selectedElementId.value } ?: return
        _copiedText.value = el.text
        _statusMessage.value = "Copied text to clipboard"
    }

    fun pasteTextToSelected() {
        val clip = _copiedText.value ?: return
        updateSelectedElement { it.copy(text = if (it.text.isBlank()) clip else "${it.text}\n$clip") }
    }

    // Export & File Actions
    fun exportPptxToSafUri(uri: Uri) {
        val doc = _activeDocument.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                repository.exportPresentationPptxToUri(doc, uri)
                _statusMessage.value = "Exported genuine PowerPoint (.pptx) successfully!"
            } catch (e: Exception) {
                _errorDialogMessage.value = "PPTX Export failed: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun exportPdfToSafUri(uri: Uri, slideIndices: List<Int>? = null) {
        val doc = _activeDocument.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                repository.exportPresentationPdfToUri(doc, uri, slideIndices)
                _statusMessage.value = "Exported PDF presentation successfully!"
            } catch (e: Exception) {
                _errorDialogMessage.value = "PDF Export failed: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun sharePresentationAs(format: String, onShareIntentReady: (Intent) -> Unit) {
        val doc = _activeDocument.value ?: return
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val context = getApplication<Application>().applicationContext
                val (file, mime) = when (format.uppercase()) {
                    "PDF" -> repository.createShareablePdfFile(doc) to "application/pdf"
                    "PNG" -> repository.exportSlideAsImageFile(doc, _selectedSlideIndex.value, asJpeg = false) to "image/png"
                    "JPG", "JPEG" -> repository.exportSlideAsImageFile(doc, _selectedSlideIndex.value, asJpeg = true) to "image/jpeg"
                    else -> repository.createShareablePptxFile(doc) to "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                }
                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_SUBJECT, doc.name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                onShareIntentReady(Intent.createChooser(shareIntent, "Share ${doc.name}"))
            } catch (e: Exception) {
                _errorDialogMessage.value = "Unable to share file: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun shareSavedPresentationById(id: String, asPdf: Boolean, onShareIntentReady: (Intent) -> Unit) {
        viewModelScope.launch {
            _isBusy.value = true
            try {
                val doc = repository.loadPresentationById(id) ?: throw IllegalStateException("File not found")
                val context = getApplication<Application>().applicationContext
                val file: File
                val mime: String
                if (asPdf) {
                    file = repository.createShareablePdfFile(doc)
                    mime = "application/pdf"
                } else {
                    file = repository.createShareablePptxFile(doc)
                    mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                }
                val contentUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_SUBJECT, doc.name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                onShareIntentReady(Intent.createChooser(shareIntent, "Share ${doc.name}"))
            } catch (e: Exception) {
                _errorDialogMessage.value = "Share failed: ${e.message}"
            } finally {
                _isBusy.value = false
            }
        }
    }

    fun renamePresentationById(id: String, newName: String) {
        viewModelScope.launch {
            repository.renamePresentation(id, newName)
            _statusMessage.value = "Renamed presentation to \"$newName\""
        }
    }

    fun duplicatePresentationById(id: String) {
        viewModelScope.launch {
            val copy = repository.duplicatePresentation(id)
            if (copy != null) {
                _statusMessage.value = "Created duplicate \"${copy.name}\""
            }
        }
    }

    fun deletePresentationById(id: String) {
        viewModelScope.launch {
            repository.deletePresentation(id)
            _statusMessage.value = "Presentation deleted"
        }
    }

    fun updateUserSettings(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch {
            repository.updateSettings(transform)
        }
    }

    fun clearThumbnailCache() {
        viewModelScope.launch {
            repository.clearThumbnailCache()
            _cacheSizeBytes.value = repository.getThumbnailCacheSizeBytes()
            _statusMessage.value = "Thumbnail cache cleared"
        }
    }
}
