package com.example.engine

import android.graphics.Bitmap
import com.example.model.*
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import java.io.*
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import kotlin.math.roundToLong

class UnsupportedLegacyPptException(message: String) : IOException(message)
class CorruptedPptxException(message: String) : IOException(message)

object OoxmlPptxEngine {

    private const val MAX_ZIP_ENTRIES = 2500
    private const val MAX_UNCOMPRESSED_BYTES = 150L * 1024L * 1024L

    // Minimal valid 1x1 PNG fallback when running in headless JVM unit tests
    private val MINIMAL_PNG_BYTES = byteArrayOf(
        0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
        0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
        0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4.toByte(),
        0x89.toByte(), 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41,
        0x54, 0x78, 0x9C.toByte(), 0x63, 0x00, 0x01, 0x00, 0x00,
        0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4.toByte(), 0x00,
        0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(),
        0x42, 0x60, 0x82.toByte()
    )

    fun writePptx(doc: PresentationDocument, outputStream: OutputStream) {
        val slides = doc.slides.ifEmpty { listOf(SlideModel()) }
        val emuCx = if (doc.aspectRatio == SlideAspectRatio.CUSTOM) {
            (doc.customWidthPt * 12700f).roundToLong()
        } else {
            doc.aspectRatio.emuCx
        }
        val emuCy = if (doc.aspectRatio == SlideAspectRatio.CUSTOM) {
            (doc.customHeightPt * 12700f).roundToLong()
        } else {
            doc.aspectRatio.emuCy
        }

        val scaleX = emuCx.toDouble() / doc.logicalWidth.toDouble()
        val scaleY = emuCy.toDouble() / doc.logicalHeight.toDouble()

        val notesIndices = mutableSetOf<Int>()
        slides.forEachIndexed { idx, s ->
            if (s.speakerNotes.isNotBlank()) notesIndices.add(idx + 1)
        }

        ZipOutputStream(BufferedOutputStream(outputStream)).use { zos ->
            putTextEntry(zos, "[Content_Types].xml", OoxmlXmlTemplates.buildContentTypesXml(slides.size, notesIndices))
            putTextEntry(zos, "_rels/.rels", OoxmlXmlTemplates.buildRootRelsXml())
            putTextEntry(zos, "docProps/core.xml", OoxmlXmlTemplates.buildDocPropsCoreXml(doc.name))
            putTextEntry(zos, "docProps/app.xml", OoxmlXmlTemplates.buildDocPropsAppXml(slides.size))
            putTextEntry(zos, "ppt/presentation.xml", OoxmlXmlTemplates.buildPresentationXml(slides.size, emuCx, emuCy))
            putTextEntry(zos, "ppt/_rels/presentation.xml.rels", OoxmlXmlTemplates.buildPresentationRelsXml(slides.size))
            putTextEntry(zos, "ppt/presProps.xml", OoxmlXmlTemplates.buildPresPropsXml())
            putTextEntry(zos, "ppt/viewProps.xml", OoxmlXmlTemplates.buildViewPropsXml())
            putTextEntry(zos, "ppt/tableStyles.xml", OoxmlXmlTemplates.buildTableStylesXml())
            putTextEntry(zos, "ppt/theme/theme1.xml", OoxmlXmlTemplates.buildThemeXml())
            putTextEntry(zos, "ppt/slideMasters/slideMaster1.xml", OoxmlXmlTemplates.buildSlideMasterXml())
            putTextEntry(zos, "ppt/slideMasters/_rels/slideMaster1.xml.rels", OoxmlXmlTemplates.buildSlideMasterRelsXml())
            putTextEntry(zos, "ppt/slideLayouts/slideLayout1.xml", OoxmlXmlTemplates.buildSlideLayoutXml())
            putTextEntry(zos, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", OoxmlXmlTemplates.buildSlideLayoutRelsXml())

            val writtenMediaNames = mutableSetOf<String>()

            slides.forEachIndexed { idx, slide ->
                val slideNum = idx + 1
                val mediaRels = mutableListOf<Pair<String, String>>()
                val slideXml = buildSlideXml(
                    doc = doc,
                    slide = slide,
                    slideNum = slideNum,
                    scaleX = scaleX,
                    scaleY = scaleY,
                    zos = zos,
                    writtenMediaNames = writtenMediaNames,
                    mediaRels = mediaRels
                )
                putTextEntry(zos, "ppt/slides/slide$slideNum.xml", slideXml)

                val hasNotes = slide.speakerNotes.isNotBlank()
                val relsXml = buildSlideRelsXml(slideNum, mediaRels, hasNotes)
                putTextEntry(zos, "ppt/slides/_rels/slide$slideNum.xml.rels", relsXml)

                if (hasNotes) {
                    putTextEntry(zos, "ppt/notesSlides/notesSlide$slideNum.xml", OoxmlXmlTemplates.buildNotesSlideXml(slide.speakerNotes))
                    putTextEntry(zos, "ppt/notesSlides/_rels/notesSlide$slideNum.xml.rels", OoxmlXmlTemplates.buildNotesSlideRelsXml(slideNum))
                }
            }

            putTextEntry(zos, "ppt/tags/pptstudio_state.json", PresentationJsonSerializer.toJsonString(doc))
        }
    }

    private fun buildSlideXml(
        doc: PresentationDocument,
        slide: SlideModel,
        slideNum: Int,
        scaleX: Double,
        scaleY: Double,
        zos: ZipOutputStream,
        writtenMediaNames: MutableSet<String>,
        mediaRels: MutableList<Pair<String, String>>
    ): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" ${if (slide.isHidden) """show="0"""" else ""}>""")
        append("""<p:cSld>""")

        val theme = BuiltInThemes.getById(slide.themeOverrideId ?: doc.themeId)
        val bgHex = OoxmlXmlTemplates.cleanHex6(slide.background.colorHex, OoxmlXmlTemplates.cleanHex6(theme.bgHex, "FFFFFF"))
        append("""<p:bg><p:bgPr>""")
        if (slide.background.type == BackgroundType.GRADIENT || slide.background.type == BackgroundType.PRESET) {
            val endHex = OoxmlXmlTemplates.cleanHex6(slide.background.gradientEndHex, bgHex)
            append("""<a:gradFill><a:gsLst><a:gs pos="0"><a:srgbClr val="$bgHex"/></a:gs><a:gs pos="100000"><a:srgbClr val="$endHex"/></a:gs></a:gsLst><a:lin ang="8100000" scaled="1"/></a:gradFill>""")
        } else {
            append("""<a:solidFill><a:srgbClr val="$bgHex"/></a:solidFill>""")
        }
        append("""<a:effectLst/></p:bgPr></p:bg>""")

        append("""<p:spTree>""")
        append("""<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>""")
        append("""<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>""")

        val sorted = slide.elements.sortedBy { it.zIndex }
        sorted.forEachIndexed { elIndex, el ->
            val objId = elIndex + 2
            val offX = (el.x * scaleX).roundToLong().coerceAtLeast(0L)
            val offY = (el.y * scaleY).roundToLong().coerceAtLeast(0L)
            val extCx = (el.width * scaleX).roundToLong().coerceAtLeast(12700L)
            val extCy = (el.height * scaleY).roundToLong().coerceAtLeast(12700L)
            val rotAttr = if (el.rotation != 0f) """ rot="${(el.rotation * 60000f).toInt()}"""" else ""

            when (el.type) {
                ElementType.TEXT, ElementType.SHAPE -> {
                    val isTextOnly = el.type == ElementType.TEXT
                    val prst = if (isTextOnly) "rect" else el.shapeKind.ooxmlPreset
                    val shapeName = if (isTextOnly) "TextBox $objId" else "Shape $objId"
                    append("""<p:sp>""")
                    append("""<p:nvSpPr><p:cNvPr id="$objId" name="${OoxmlXmlTemplates.escapeXml(shapeName)}"/><p:cNvSpPr ${if (isTextOnly) """txBox="1"""" else ""}/><p:nvPr/></p:nvSpPr>""")
                    append("""<p:spPr>""")
                    append("""<a:xfrm$rotAttr><a:off x="$offX" y="$offY"/><a:ext cx="$extCx" cy="$extCy"/></a:xfrm>""")
                    append("""<a:prstGeom prst="$prst"><a:avLst/></a:prstGeom>""")
                    if (!el.fillColorHex.isNullOrBlank()) {
                        val fillHex = OoxmlXmlTemplates.cleanHex6(el.fillColorHex, "1D4ED8")
                        if (!el.gradientEndColorHex.isNullOrBlank()) {
                            val gEnd = OoxmlXmlTemplates.cleanHex6(el.gradientEndColorHex, fillHex)
                            append("""<a:gradFill><a:gsLst><a:gs pos="0"><a:srgbClr val="$fillHex"/></a:gs><a:gs pos="100000"><a:srgbClr val="$gEnd"/></a:gs></a:gsLst></a:gradFill>""")
                        } else {
                            append("""<a:solidFill><a:srgbClr val="$fillHex"/></a:solidFill>""")
                        }
                    } else if (isTextOnly) {
                        append("""<a:noFill/>""")
                    } else {
                        append("""<a:solidFill><a:srgbClr val="1D4ED8"/></a:solidFill>""")
                    }
                    if (el.borderWidth > 0f && !el.borderColorHex.isNullOrBlank()) {
                        val lnW = (el.borderWidth * 12700f).toInt().coerceAtLeast(9525)
                        val bHex = OoxmlXmlTemplates.cleanHex6(el.borderColorHex, "0F172A")
                        append("""<a:ln w="$lnW"><a:solidFill><a:srgbClr val="$bHex"/></a:solidFill></a:ln>""")
                    }
                    append("""</p:spPr>""")

                    val anchor = when (el.verticalAlign) {
                        VerticalAlignOption.TOP -> "t"
                        VerticalAlignOption.MIDDLE -> "ctr"
                        VerticalAlignOption.BOTTOM -> "b"
                    }
                    append("""<p:txBody><a:bodyPr wrap="${if (el.wrapText) "square" else "none"}" anchor="$anchor"/><a:lstStyle/>""")
                    val lines = el.text.split("\n")
                    val algn = when (el.textAlign) {
                        TextAlignOption.LEFT -> "l"
                        TextAlignOption.CENTER -> "ctr"
                        TextAlignOption.RIGHT -> "r"
                        TextAlignOption.JUSTIFY -> "just"
                    }
                    val szHundredths = (el.fontSize * 100f).toInt().coerceIn(600, 12000)
                    val bAttr = if (el.isBold) """ b="1"""" else """ b="0""""
                    val iAttr = if (el.isItalic) """ i="1"""" else """ i="0""""
                    val uAttr = if (el.isUnderline) """ u="sng"""" else ""
                    val strikeAttr = if (el.isStrikethrough) """ strike="sngStrike"""" else ""
                    val txtHex = OoxmlXmlTemplates.cleanHex6(el.textColorHex, "0F172A")

                    for (line in lines) {
                        append("""<a:p><a:pPr algn="$algn" lvl="${el.indentLevel.coerceIn(0, 4)}">""")
                        when (el.listType) {
                            ListStyleType.BULLET -> append("""<a:buChar char="•"/>""")
                            ListStyleType.NUMBERED -> append("""<a:buAutoNum type="arabicPeriod"/>""")
                            ListStyleType.NONE -> append("""<a:buNone/>""")
                        }
                        append("""</a:pPr>""")
                        append("""<a:r><a:rPr lang="en-US" sz="$szHundredths"$bAttr$iAttr$uAttr$strikeAttr>""")
                        append("""<a:solidFill><a:srgbClr val="$txtHex"/></a:solidFill>""")
                        append("""<a:latin typeface="${OoxmlXmlTemplates.escapeXml(el.fontFamily)}"/><a:cs typeface="Noto Sans Devanagari"/>""")
                        append("""</a:rPr><a:t>${OoxmlXmlTemplates.escapeXml(line)}</a:t></a:r></a:p>""")
                    }
                    append("""</p:txBody></p:sp>""")
                }

                ElementType.IMAGE -> {
                    val imgPath = el.imagePath
                    val mediaFileName = "image_s${slideNum}_e${objId}.png"
                    val rId = "rIdImg$objId"
                    val written = writeImageToMediaZip(imgPath, mediaFileName, zos, writtenMediaNames)
                    if (written) {
                        mediaRels.add(rId to "../media/$mediaFileName")
                        append("""<p:pic>""")
                        append("""<p:nvPicPr><p:cNvPr id="$objId" name="Picture $objId"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr>""")
                        append("""<p:blipFill><a:blip r:embed="$rId"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>""")
                        append("""<p:spPr><a:xfrm$rotAttr><a:off x="$offX" y="$offY"/><a:ext cx="$extCx" cy="$extCy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>""")
                        append("""</p:pic>""")
                    }
                }

                ElementType.TABLE -> {
                    val rows = el.tableRows.coerceAtLeast(1)
                    val cols = el.tableCols.coerceAtLeast(1)
                    val colW = (extCx / cols).coerceAtLeast(12700L)
                    val rowH = (extCy / rows).coerceAtLeast(12700L)
                    append("""<p:graphicFrame>""")
                    append("""<p:nvGraphicFramePr><p:cNvPr id="$objId" name="Table $objId"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>""")
                    append("""<p:xfrm><a:off x="$offX" y="$offY"/><a:ext cx="$extCx" cy="$extCy"/></p:xfrm>""")
                    append("""<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">""")
                    append("""<a:tbl><a:tblPr firstRow="1" bandRow="1"/><a:tblGrid>""")
                    repeat(cols) { append("""<a:gridCol w="$colW"/>""") }
                    append("""</a:tblGrid>""")
                    for (r in 0 until rows) {
                        append("""<a:tr h="$rowH">""")
                        val cellBg = if (r == 0) OoxmlXmlTemplates.cleanHex6(el.tableHeaderBgHex, "1D4ED8")
                        else if (r % 2 == 1) OoxmlXmlTemplates.cleanHex6(el.tableRowBgHex, "FFFFFF")
                        else OoxmlXmlTemplates.cleanHex6(el.tableAltRowBgHex, "F1F5F9")
                        val txtColor = if (r == 0) OoxmlXmlTemplates.cleanHex6(el.tableHeaderTextHex, "FFFFFF")
                        else OoxmlXmlTemplates.cleanHex6(el.textColorHex, "0F172A")

                        for (c in 0 until cols) {
                            val cellText = el.tableCells.getOrNull(r)?.getOrNull(c) ?: ""
                            append("""<a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r>""")
                            append("""<a:rPr lang="en-US" sz="${(el.fontSize * 100).toInt()}" b="${if (r == 0) 1 else 0}"><a:solidFill><a:srgbClr val="$txtColor"/></a:solidFill></a:rPr>""")
                            append("""<a:t>${OoxmlXmlTemplates.escapeXml(cellText)}</a:t></a:r></a:p></a:txBody>""")
                            append("""<a:tcPr><a:solidFill><a:srgbClr val="$cellBg"/></a:solidFill></a:tcPr></a:tc>""")
                        }
                        append("""</a:tr>""")
                    }
                    append("""</a:tbl></a:graphicData></a:graphic></p:graphicFrame>""")
                }

                ElementType.CHART -> {
                    val mediaFileName = "chart_s${slideNum}_e${objId}.png"
                    val rId = "rIdChart$objId"
                    if (!writtenMediaNames.contains(mediaFileName)) {
                        writtenMediaNames.add(mediaFileName)
                        zos.putNextEntry(ZipEntry("ppt/media/$mediaFileName"))
                        val wroteBitmap = runCatching {
                            val bmp = SlideRendererAndPdfExporter.renderChartElementToBitmap(el, 960, 560)
                            val baos = ByteArrayOutputStream()
                            bmp.compress(Bitmap.CompressFormat.PNG, 95, baos)
                            bmp.recycle()
                            val bytes = baos.toByteArray()
                            if (bytes.isNotEmpty()) {
                                zos.write(bytes)
                                true
                            } else false
                        }.getOrDefault(false)
                        if (!wroteBitmap) {
                            zos.write(MINIMAL_PNG_BYTES)
                        }
                        zos.closeEntry()
                    }
                    mediaRels.add(rId to "../media/$mediaFileName")
                    val descrMeta = "PPTSTUDIO_CHART:${el.chartKind.name}:${el.chartTitle}"
                    append("""<p:pic>""")
                    append("""<p:nvPicPr><p:cNvPr id="$objId" name="Chart $objId" descr="${OoxmlXmlTemplates.escapeXml(descrMeta)}"/><p:cNvPicPr/><p:nvPr/></p:nvPicPr>""")
                    append("""<p:blipFill><a:blip r:embed="$rId"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>""")
                    append("""<p:spPr><a:xfrm$rotAttr><a:off x="$offX" y="$offY"/><a:ext cx="$extCx" cy="$extCy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr>""")
                    append("""</p:pic>""")
                }
            }
        }

        append("""</p:spTree></p:cSld></p:sld>""")
    }

    private fun writeImageToMediaZip(
        imgPath: String?,
        mediaFileName: String,
        zos: ZipOutputStream,
        writtenMediaNames: MutableSet<String>
    ): Boolean {
        if (imgPath.isNullOrBlank()) return false
        val file = File(imgPath)
        if (!file.exists() || !file.canRead()) return false
        if (!writtenMediaNames.contains(mediaFileName)) {
            writtenMediaNames.add(mediaFileName)
            zos.putNextEntry(ZipEntry("ppt/media/$mediaFileName"))
            FileInputStream(file).use { fis -> fis.copyTo(zos) }
            zos.closeEntry()
        }
        return true
    }

    private fun buildSlideRelsXml(
        slideNum: Int,
        mediaRels: List<Pair<String, String>>,
        hasNotes: Boolean
    ): String = buildString {
        append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        append("""<Relationship Id="rIdLayout1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>""")
        for ((rId, target) in mediaRels) {
            append("""<Relationship Id="$rId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="$target"/>""")
        }
        if (hasNotes) {
            append("""<Relationship Id="rIdNotes1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/notesSlide" Target="../notesSlides/notesSlide$slideNum.xml"/>""")
        }
        append("""</Relationships>""")
    }

    private fun putTextEntry(zos: ZipOutputStream, entryPath: String, content: String) {
        zos.putNextEntry(ZipEntry(entryPath))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    fun readPptx(
        inputStream: InputStream,
        fileName: String,
        mediaCacheDir: File
    ): PresentationDocument {
        mediaCacheDir.mkdirs()
        val buffered = BufferedInputStream(inputStream)
        buffered.mark(16)
        val header = ByteArray(8)
        val readCount = buffered.read(header)
        buffered.reset()

        if (readCount < 4) {
            throw CorruptedPptxException("File is empty or too small to be a valid PowerPoint presentation.")
        }
        if (header[0] == 0xD0.toByte() && header[1] == 0xCF.toByte() && header[2] == 0x11.toByte() && header[3] == 0xE0.toByte()) {
            throw UnsupportedLegacyPptException("Legacy binary PowerPoint 97-2003 (.ppt) format detected. Please convert or save the file as .pptx (Office Open XML) for full slide editing.")
        }
        if (header[0] != 0x50.toByte() || header[1] != 0x4B.toByte()) {
            throw CorruptedPptxException("Invalid PPTX archive signature. The selected file is not a valid Office Open XML (.pptx) package.")
        }

        val xmlEntries = mutableMapOf<String, String>()
        val extractedMediaPaths = mutableMapOf<String, String>()
        var entryCount = 0
        var totalBytesRead = 0L

        ZipInputStream(buffered).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                entryCount++
                if (entryCount > MAX_ZIP_ENTRIES) {
                    throw CorruptedPptxException("Archive contains too many entries ($entryCount). Aborting for ZIP bomb safety.")
                }
                val name = entry.name.replace('\\', '/').removePrefix("/")
                if (name.contains("..")) {
                    throw CorruptedPptxException("Unsafe ZIP path traversal detected in archive entry: $name")
                }

                if (!entry.isDirectory) {
                    val baos = ByteArrayOutputStream()
                    val buf = ByteArray(8192)
                    var n = zis.read(buf)
                    while (n != -1) {
                        totalBytesRead += n
                        if (totalBytesRead > MAX_UNCOMPRESSED_BYTES) {
                            throw CorruptedPptxException("Presentation exceeds safe uncompressed size limit (150 MB).")
                        }
                        baos.write(buf, 0, n)
                        n = zis.read(buf)
                    }
                    val bytes = baos.toByteArray()
                    when {
                        name.endsWith(".xml", true) || name.endsWith(".rels", true) || name.endsWith(".json", true) -> {
                            xmlEntries[name] = bytes.toString(Charsets.UTF_8)
                        }
                        name.startsWith("ppt/media/") -> {
                            val cleanMediaName = File(name).name
                            val destFile = File(mediaCacheDir, "${System.currentTimeMillis()}_$cleanMediaName")
                            FileOutputStream(destFile).use { it.write(bytes) }
                            extractedMediaPaths[name] = destFile.absolutePath
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        if (!xmlEntries.containsKey("[Content_Types].xml") || !xmlEntries.containsKey("ppt/presentation.xml")) {
            throw CorruptedPptxException("Missing required Office Open XML presentation parts ([Content_Types].xml or ppt/presentation.xml).")
        }

        val studioStateJson = xmlEntries["ppt/tags/pptstudio_state.json"]
        if (!studioStateJson.isNullOrBlank()) {
            runCatching {
                val restored = PresentationJsonSerializer.fromJsonString(studioStateJson)
                val relinkedSlides = restored.slides.mapIndexed { sIdx, s ->
                    val slideNum = sIdx + 1
                    s.copy(
                        elements = s.elements.mapIndexed { eIdx, el ->
                            val objId = eIdx + 2
                            if (el.type == ElementType.IMAGE && (el.imagePath == null || !File(el.imagePath).exists())) {
                                val fallbackKey = "ppt/media/image_s${slideNum}_e${objId}.png"
                                el.copy(imagePath = extractedMediaPaths[fallbackKey] ?: extractedMediaPaths.values.firstOrNull())
                            } else el
                        }
                    )
                }
                return restored.copy(
                    name = fileName.removeSuffix(".pptx").removeSuffix(".ppsx"),
                    slides = relinkedSlides
                )
            }
        }

        return parseStandardOoxmlPresentation(fileName, xmlEntries, extractedMediaPaths)
    }

    private fun parseStandardOoxmlPresentation(
        fileName: String,
        xmlEntries: Map<String, String>,
        extractedMediaPaths: Map<String, String>
    ): PresentationDocument {
        val presXml = xmlEntries["ppt/presentation.xml"] ?: ""
        val presRelsXml = xmlEntries["ppt/_rels/presentation.xml.rels"] ?: ""

        var emuCx = 12192000L
        var emuCy = 6858000L
        val slideRelIds = mutableListOf<String>()

        parseXmlDom(presXml)?.let { doc ->
            val nodes = doc.getElementsByTagName("*")
            for (i in 0 until nodes.length) {
                val el = nodes.item(i) as? Element ?: continue
                when (el.tagName.substringAfterLast(':')) {
                    "sldSz" -> {
                        el.getAttribute("cx").toLongOrNull()?.let { emuCx = it }
                        el.getAttribute("cy").toLongOrNull()?.let { emuCy = it }
                    }
                    "sldId" -> {
                        val rId = el.getAttribute("r:id").ifBlank { el.getAttribute("id") }
                        if (rId.startsWith("rId")) slideRelIds.add(rId)
                    }
                }
            }
        }

        val rIdToTarget = parseRelsMap(presRelsXml)
        val orderedSlidePaths = if (slideRelIds.isNotEmpty()) {
            slideRelIds.mapNotNull { rId ->
                val target = rIdToTarget[rId]?.removePrefix("/") ?: return@mapNotNull null
                if (target.startsWith("ppt/")) target else "ppt/$target"
            }
        } else {
            xmlEntries.keys
                .filter { it.matches(Regex("ppt/slides/slide\\d+\\.xml")) }
                .sortedBy { it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0 }
        }

        val aspectRatio = if (emuCx.toDouble() / emuCy.toDouble() > 1.55) {
            SlideAspectRatio.WIDESCREEN_16_9
        } else {
            SlideAspectRatio.STANDARD_4_3
        }
        val scaleX = aspectRatio.widthPt / emuCx.toFloat()
        val scaleY = aspectRatio.heightPt / emuCy.toFloat()

        var hasComplexWarning = false
        val slides = orderedSlidePaths.map { slidePath ->
            val slideXml = xmlEntries[slidePath] ?: ""
            val slideFileName = slidePath.substringAfterLast('/')
            val slideRelsPath = "ppt/slides/_rels/$slideFileName.rels"
            val slideRelsMap = parseRelsMap(xmlEntries[slideRelsPath] ?: "")

            if (slideXml.contains("SmartArt", true) || slideXml.contains("dgm:", true) || slideXml.contains("oleObj", true)) {
                hasComplexWarning = true
            }

            val notesTarget = slideRelsMap.values.firstOrNull { it.contains("notesSlide") }
            val notesPath = notesTarget?.let { "ppt/notesSlides/${it.substringAfterLast('/')}" }
            val speakerNotes = notesPath?.let { extractPlainTextFromXml(xmlEntries[it] ?: "") } ?: ""

            parseSingleSlideDom(
                slideXml = slideXml,
                slideRelsMap = slideRelsMap,
                extractedMediaPaths = extractedMediaPaths,
                scaleX = scaleX,
                scaleY = scaleY,
                speakerNotes = speakerNotes
            )
        }.ifEmpty {
            listOf(SlideModel(layoutType = SlideLayoutType.TITLE_SLIDE))
        }

        return PresentationDocument(
            id = UUID.randomUUID().toString(),
            name = fileName.removeSuffix(".pptx").removeSuffix(".ppsx").removeSuffix(".ppt"),
            aspectRatio = aspectRatio,
            slides = slides,
            hasUnsupportedElementsWarning = hasComplexWarning,
            formatWarningMessage = if (hasComplexWarning) {
                "This presentation contains advanced SmartArt or embedded OLE objects. Core slides, text, shapes, tables, and images have been imported."
            } else null
        )
    }

    private fun parseSingleSlideDom(
        slideXml: String,
        slideRelsMap: Map<String, String>,
        extractedMediaPaths: Map<String, String>,
        scaleX: Float,
        scaleY: Float,
        speakerNotes: String
    ): SlideModel {
        var bgHex = "#FFFFFF"
        val elements = mutableListOf<SlideElement>()
        var zOrder = 0

        val dom = parseXmlDom(slideXml) ?: return SlideModel(speakerNotes = speakerNotes)
        val allNodes = dom.getElementsByTagName("*")
        for (i in 0 until allNodes.length) {
            val el = allNodes.item(i) as? Element ?: continue
            when (el.tagName.substringAfterLast(':')) {
                "bg" -> {
                    val clrs = el.getElementsByTagName("*")
                    for (j in 0 until clrs.length) {
                        val c = clrs.item(j) as? Element ?: continue
                        if (c.tagName.endsWith("srgbClr")) {
                            val v = c.getAttribute("val")
                            if (v.isNotBlank()) { bgHex = "#$v"; break }
                        }
                    }
                }
                "sp" -> {
                    if (el.parentNode?.nodeName?.endsWith("spTree") == true) {
                        parseDomSp(el, scaleX, scaleY, zOrder++)?.let { elements.add(it) }
                    }
                }
                "pic" -> {
                    parseDomPic(el, slideRelsMap, extractedMediaPaths, scaleX, scaleY, zOrder++)?.let { elements.add(it) }
                }
                "graphicFrame" -> {
                    parseDomTable(el, scaleX, scaleY, zOrder++)?.let { elements.add(it) }
                }
            }
        }

        return SlideModel(
            background = SlideBackground(type = BackgroundType.SOLID, colorHex = bgHex),
            elements = elements,
            speakerNotes = speakerNotes
        )
    }

    private fun parseDomSp(
        spEl: Element,
        scaleX: Float,
        scaleY: Float,
        zIndex: Int
    ): SlideElement? {
        var x = 80f
        var y = 80f
        var w = 420f
        var h = 110f
        var isTxBox = false
        var prst = "rect"
        var fillHex: String? = null
        var textColorHex = "#0F172A"
        var fontSize = 22f
        var isBold = false
        var isItalic = false
        val paragraphs = mutableListOf<String>()

        val children = spEl.getElementsByTagName("*")
        for (i in 0 until children.length) {
            val node = children.item(i) as? Element ?: continue
            when (node.tagName.substringAfterLast(':')) {
                "cNvSpPr" -> if (node.getAttribute("txBox") == "1") isTxBox = true
                "off" -> {
                    node.getAttribute("x").toLongOrNull()?.let { x = it * scaleX }
                    node.getAttribute("y").toLongOrNull()?.let { y = it * scaleY }
                }
                "ext" -> {
                    node.getAttribute("cx").toLongOrNull()?.let { if (it > 0) w = (it * scaleX).coerceAtLeast(40f) }
                    node.getAttribute("cy").toLongOrNull()?.let { if (it > 0) h = (it * scaleY).coerceAtLeast(30f) }
                }
                "prstGeom" -> prst = node.getAttribute("prst").ifBlank { "rect" }
                "rPr" -> {
                    node.getAttribute("sz").toFloatOrNull()?.let { fontSize = (it / 100f).coerceIn(10f, 72f) }
                    if (node.getAttribute("b") == "1") isBold = true
                    if (node.getAttribute("i") == "1") isItalic = true
                }
                "p" -> {
                    val sb = StringBuilder()
                    val tNodes = node.getElementsByTagName("*")
                    for (tIdx in 0 until tNodes.length) {
                        val tEl = tNodes.item(tIdx) as? Element ?: continue
                        if (tEl.tagName.substringAfterLast(':') == "t") {
                            sb.append(tEl.textContent ?: "")
                        } else if (tEl.tagName.substringAfterLast(':') == "srgbClr") {
                            val v = tEl.getAttribute("val")
                            if (v.isNotBlank()) textColorHex = "#$v"
                        }
                    }
                    if (sb.isNotEmpty()) paragraphs.add(sb.toString())
                }
            }
        }

        val fullText = paragraphs.joinToString("\n")
        val mappedShape = ShapeKind.entries.find { it.ooxmlPreset == prst } ?: ShapeKind.RECTANGLE
        val isPureText = isTxBox || (prst == "rect" && fillHex == null && fullText.isNotBlank())
        if (isPureText && fullText.isBlank()) return null

        return SlideElement(
            type = if (isPureText) ElementType.TEXT else ElementType.SHAPE,
            x = x, y = y, width = w, height = h,
            zIndex = zIndex,
            text = fullText,
            fontSize = fontSize,
            isBold = isBold,
            isItalic = isItalic,
            textColorHex = textColorHex,
            fillColorHex = fillHex,
            shapeKind = mappedShape
        )
    }

    private fun parseDomPic(
        picEl: Element,
        slideRelsMap: Map<String, String>,
        extractedMediaPaths: Map<String, String>,
        scaleX: Float,
        scaleY: Float,
        zIndex: Int
    ): SlideElement? {
        var x = 100f
        var y = 100f
        var w = 320f
        var h = 220f
        var embedId: String? = null

        val children = picEl.getElementsByTagName("*")
        for (i in 0 until children.length) {
            val node = children.item(i) as? Element ?: continue
            when (node.tagName.substringAfterLast(':')) {
                "blip" -> embedId = node.getAttribute("r:embed").ifBlank { node.getAttribute("embed") }
                "off" -> {
                    node.getAttribute("x").toLongOrNull()?.let { x = it * scaleX }
                    node.getAttribute("y").toLongOrNull()?.let { y = it * scaleY }
                }
                "ext" -> {
                    node.getAttribute("cx").toLongOrNull()?.let { if (it > 0) w = it * scaleX }
                    node.getAttribute("cy").toLongOrNull()?.let { if (it > 0) h = it * scaleY }
                }
            }
        }

        val target = embedId?.let { slideRelsMap[it] } ?: return null
        val mediaFileName = target.substringAfterLast('/')
        val localPath = extractedMediaPaths["ppt/media/$mediaFileName"]
            ?: extractedMediaPaths.entries.firstOrNull { it.key.endsWith(mediaFileName) }?.value
        return SlideElement(type = ElementType.IMAGE, x = x, y = y, width = w, height = h, zIndex = zIndex, imagePath = localPath)
    }

    private fun parseDomTable(
        gfEl: Element,
        scaleX: Float,
        scaleY: Float,
        zIndex: Int
    ): SlideElement? {
        var x = 100f
        var y = 140f
        var w = 500f
        var h = 220f
        val rows = mutableListOf<List<String>>()

        val children = gfEl.getElementsByTagName("*")
        for (i in 0 until children.length) {
            val node = children.item(i) as? Element ?: continue
            when (node.tagName.substringAfterLast(':')) {
                "off" -> {
                    node.getAttribute("x").toLongOrNull()?.let { x = it * scaleX }
                    node.getAttribute("y").toLongOrNull()?.let { y = it * scaleY }
                }
                "ext" -> {
                    node.getAttribute("cx").toLongOrNull()?.let { if (it > 0) w = it * scaleX }
                    node.getAttribute("cy").toLongOrNull()?.let { if (it > 0) h = it * scaleY }
                }
                "tr" -> {
                    val rowCells = mutableListOf<String>()
                    val childNodes = node.childNodes
                    for (cIdx in 0 until childNodes.length) {
                        val tc = childNodes.item(cIdx) as? Element ?: continue
                        if (tc.tagName.substringAfterLast(':') == "tc") {
                            rowCells.add(tc.textContent?.trim() ?: "")
                        }
                    }
                    if (rowCells.isNotEmpty()) rows.add(rowCells)
                }
            }
        }

        if (rows.isEmpty()) return null
        return SlideElement(
            type = ElementType.TABLE,
            x = x, y = y, width = w, height = h,
            zIndex = zIndex,
            tableRows = rows.size,
            tableCols = rows.maxOfOrNull { it.size } ?: 1,
            tableCells = rows,
            fontSize = 14f
        )
    }

    private fun parseRelsMap(relsXml: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        val dom = parseXmlDom(relsXml) ?: return map
        val rels = dom.getElementsByTagName("*")
        for (i in 0 until rels.length) {
            val el = rels.item(i) as? Element ?: continue
            if (el.tagName.endsWith("Relationship")) {
                val id = el.getAttribute("Id")
                val target = el.getAttribute("Target")
                if (id.isNotBlank() && target.isNotBlank()) map[id] = target
            }
        }
        return map
    }

    private fun extractPlainTextFromXml(xml: String): String {
        val dom = parseXmlDom(xml) ?: return ""
        val sb = StringBuilder()
        val nodes = dom.getElementsByTagName("*")
        for (i in 0 until nodes.length) {
            val el = nodes.item(i) as? Element ?: continue
            if (el.tagName.substringAfterLast(':') == "t") {
                val txt = el.textContent ?: ""
                if (txt.isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append(" ")
                    sb.append(txt)
                }
            }
        }
        return sb.toString()
    }

    private fun parseXmlDom(xmlContent: String): Document? {
        if (xmlContent.isBlank()) return null
        return try {
            val factory = DocumentBuilderFactory.newInstance().apply {
                isNamespaceAware = false
            }
            val builder = factory.newDocumentBuilder()
            builder.parse(InputSource(StringReader(xmlContent)))
        } catch (_: Exception) {
            null
        }
    }
}
