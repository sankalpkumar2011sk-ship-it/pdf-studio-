package com.example.engine

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.model.*
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

object SlideRendererAndPdfExporter {

    fun parseColorSafe(hex: String?, defaultColor: Int = Color.BLACK): Int {
        if (hex.isNullOrBlank()) return defaultColor
        return try {
            val cleaned = if (hex.startsWith("#")) hex else "#$hex"
            Color.parseColor(cleaned)
        } catch (_: Exception) {
            defaultColor
        }
    }

    fun renderSlideToBitmap(
        doc: PresentationDocument,
        slide: SlideModel,
        targetWidthPx: Int = 1280
    ): Bitmap {
        val logicalW = doc.logicalWidth.coerceAtLeast(320f)
        val logicalH = doc.logicalHeight.coerceAtLeast(240f)
        val scale = targetWidthPx.toFloat() / logicalW
        val targetHeightPx = (logicalH * scale).toInt().coerceAtLeast(180)

        val bitmap = Bitmap.createBitmap(targetWidthPx, targetHeightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        renderSlideToCanvas(canvas, doc, slide, scale)
        return bitmap
    }

    fun renderChartElementToBitmap(element: SlideElement, widthPx: Int = 800, heightPx: Int = 500): Bitmap {
        val bmp = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val localEl = element.copy(x = 0f, y = 0f, width = widthPx.toFloat(), height = heightPx.toFloat(), rotation = 0f)
        drawChartElement(canvas, localEl)
        return bmp
    }

    fun renderSlideToCanvas(
        canvas: Canvas,
        doc: PresentationDocument,
        slide: SlideModel,
        scale: Float
    ) {
        val logicalW = doc.logicalWidth
        val logicalH = doc.logicalHeight
        canvas.save()
        canvas.scale(scale, scale)

        // 1. Background
        drawSlideBackground(canvas, slide.background, doc.themeId, logicalW, logicalH)

        // 2. Elements ordered by zIndex
        val sortedElements = slide.elements.sortedBy { it.zIndex }
        for (el in sortedElements) {
            canvas.save()
            val cx = el.x + el.width / 2f
            val cy = el.y + el.height / 2f
            if (el.rotation != 0f) {
                canvas.rotate(el.rotation, cx, cy)
            }
            when (el.type) {
                ElementType.SHAPE -> drawShapeElement(canvas, el)
                ElementType.TEXT -> drawTextElement(canvas, el)
                ElementType.IMAGE -> drawImageElement(canvas, el)
                ElementType.TABLE -> drawTableElement(canvas, el)
                ElementType.CHART -> drawChartElement(canvas, el)
            }
            canvas.restore()
        }

        canvas.restore()
    }

    private fun drawSlideBackground(
        canvas: Canvas,
        bg: SlideBackground,
        themeId: String,
        w: Float,
        h: Float
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val theme = BuiltInThemes.getById(themeId)
        when (bg.type) {
            BackgroundType.SOLID -> {
                paint.color = parseColorSafe(bg.colorHex, parseColorSafe(theme.bgHex, Color.WHITE))
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundType.GRADIENT, BackgroundType.PRESET -> {
                val c1 = parseColorSafe(bg.colorHex, parseColorSafe(theme.bgHex, Color.WHITE))
                val c2 = parseColorSafe(bg.gradientEndHex, parseColorSafe(theme.bgGradientEndHex ?: theme.bgHex, Color.LTGRAY))
                val rad = Math.toRadians(bg.gradientAngle.toDouble())
                val x1 = (w / 2f + cos(rad) * w / 2f).toFloat()
                val y1 = (h / 2f + sin(rad) * h / 2f).toFloat()
                paint.shader = LinearGradient(0f, 0f, x1, y1, c1, c2, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, 0f, w, h, paint)
            }
            BackgroundType.IMAGE -> {
                paint.color = parseColorSafe(bg.colorHex, Color.WHITE)
                canvas.drawRect(0f, 0f, w, h, paint)
                val path = bg.imagePath
                if (!path.isNullOrBlank() && File(path).exists()) {
                    val bmp = decodeSampledBitmap(path, 1280, 720)
                    if (bmp != null) {
                        val dst = RectF(0f, 0f, w, h)
                        canvas.drawBitmap(bmp, null, dst, paint)
                    }
                }
            }
        }
    }

    private fun drawShapeElement(canvas: Canvas, el: SlideElement) {
        val alphaInt = (el.opacity.coerceIn(0.05f, 1f) * 255).toInt()
        val rect = RectF(el.x, el.y, el.x + el.width, el.y + el.height)

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            val startCol = parseColorSafe(el.fillColorHex, Color.parseColor("#1D4ED8"))
            if (!el.gradientEndColorHex.isNullOrBlank()) {
                val endCol = parseColorSafe(el.gradientEndColorHex, startCol)
                shader = LinearGradient(rect.left, rect.top, rect.right, rect.bottom, startCol, endCol, Shader.TileMode.CLAMP)
            } else {
                color = startCol
            }
            alpha = alphaInt
            if (el.hasShadow) {
                setShadowLayer(8f, 0f, 4f, Color.argb(80, 0, 0, 0))
            }
        }

        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = el.borderWidth.coerceAtLeast(1f)
            color = parseColorSafe(el.borderColorHex, Color.parseColor("#0F172A"))
            alpha = alphaInt
        }

        val path = buildShapePath(el.shapeKind, rect, el.freehandPoints)
        if (el.shapeKind == ShapeKind.LINE || el.shapeKind == ShapeKind.FREEHAND) {
            strokePaint.strokeWidth = el.borderWidth.coerceAtLeast(3f)
            strokePaint.color = parseColorSafe(el.fillColorHex ?: el.borderColorHex, Color.parseColor("#1D4ED8"))
            canvas.drawPath(path, strokePaint)
        } else {
            if (!el.fillColorHex.isNullOrBlank()) {
                canvas.drawPath(path, fillPaint)
            }
            if (el.borderWidth > 0f && !el.borderColorHex.isNullOrBlank()) {
                canvas.drawPath(path, strokePaint)
            }
        }

        if (el.text.isNotBlank()) {
            drawTextElement(canvas, el.copy(fillColorHex = null, borderWidth = 0f, verticalAlign = VerticalAlignOption.MIDDLE, textAlign = TextAlignOption.CENTER))
        }
    }

    private fun buildShapePath(kind: ShapeKind, r: RectF, freehand: List<Point2D>): Path {
        val p = Path()
        val cx = r.centerX()
        val cy = r.centerY()
        val w = r.width()
        val h = r.height()
        when (kind) {
            ShapeKind.RECTANGLE, ShapeKind.FLOWCHART_PROCESS -> p.addRect(r, Path.Direction.CW)
            ShapeKind.ROUNDED_RECTANGLE -> p.addRoundRect(r, 18f, 18f, Path.Direction.CW)
            ShapeKind.CIRCLE -> {
                val radius = min(w, h) / 2f
                p.addCircle(cx, cy, radius, Path.Direction.CW)
            }
            ShapeKind.OVAL -> p.addOval(r, Path.Direction.CW)
            ShapeKind.TRIANGLE -> {
                p.moveTo(cx, r.top)
                p.lineTo(r.right, r.bottom)
                p.lineTo(r.left, r.bottom)
                p.close()
            }
            ShapeKind.RIGHT_TRIANGLE -> {
                p.moveTo(r.left, r.top)
                p.lineTo(r.right, r.bottom)
                p.lineTo(r.left, r.bottom)
                p.close()
            }
            ShapeKind.DIAMOND, ShapeKind.FLOWCHART_DECISION -> {
                p.moveTo(cx, r.top)
                p.lineTo(r.right, cy)
                p.lineTo(cx, r.bottom)
                p.lineTo(r.left, cy)
                p.close()
            }
            ShapeKind.PENTAGON -> addRegularPolygon(p, cx, cy, min(w, h) / 2f, 5)
            ShapeKind.HEXAGON -> addRegularPolygon(p, cx, cy, min(w, h) / 2f, 6)
            ShapeKind.STAR -> {
                val outer = min(w, h) / 2f
                val inner = outer * 0.42f
                for (i in 0 until 10) {
                    val rad = Math.toRadians((i * 36 - 90).toDouble())
                    val dist = if (i % 2 == 0) outer else inner
                    val px = (cx + cos(rad) * dist).toFloat()
                    val py = (cy + sin(rad) * dist).toFloat()
                    if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
                }
                p.close()
            }
            ShapeKind.HEART -> {
                p.moveTo(cx, r.bottom)
                p.cubicTo(r.left - w * 0.1f, cy + h * 0.1f, r.left, r.top, cx, r.top + h * 0.28f)
                p.cubicTo(r.right, r.top, r.right + w * 0.1f, cy + h * 0.1f, cx, r.bottom)
                p.close()
            }
            ShapeKind.LINE -> {
                p.moveTo(r.left, cy)
                p.lineTo(r.right, cy)
            }
            ShapeKind.ARROW, ShapeKind.CURVED_ARROW -> {
                val headW = w * 0.3f
                val shaftTop = cy - h * 0.22f
                val shaftBot = cy + h * 0.22f
                p.moveTo(r.left, shaftTop)
                p.lineTo(r.right - headW, shaftTop)
                p.lineTo(r.right - headW, r.top)
                p.lineTo(r.right, cy)
                p.lineTo(r.right - headW, r.bottom)
                p.lineTo(r.right - headW, shaftBot)
                p.lineTo(r.left, shaftBot)
                p.close()
            }
            ShapeKind.DOUBLE_ARROW -> {
                val headW = w * 0.25f
                val shaftTop = cy - h * 0.2f
                val shaftBot = cy + h * 0.2f
                p.moveTo(r.left, cy)
                p.lineTo(r.left + headW, r.top)
                p.lineTo(r.left + headW, shaftTop)
                p.lineTo(r.right - headW, shaftTop)
                p.lineTo(r.right - headW, r.top)
                p.lineTo(r.right, cy)
                p.lineTo(r.right - headW, r.bottom)
                p.lineTo(r.right - headW, shaftBot)
                p.lineTo(r.left + headW, shaftBot)
                p.lineTo(r.left + headW, r.bottom)
                p.close()
            }
            ShapeKind.CALLOUT, ShapeKind.SPEECH_BUBBLE -> {
                val bodyBottom = r.top + h * 0.78f
                p.addRoundRect(RectF(r.left, r.top, r.right, bodyBottom), 14f, 14f, Path.Direction.CW)
                p.moveTo(r.left + w * 0.25f, bodyBottom)
                p.lineTo(r.left + w * 0.18f, r.bottom)
                p.lineTo(r.left + w * 0.42f, bodyBottom)
                p.close()
            }
            ShapeKind.FREEHAND -> {
                if (freehand.size >= 2) {
                    freehand.forEachIndexed { idx, pt ->
                        val px = r.left + pt.x * w
                        val py = r.top + pt.y * h
                        if (idx == 0) p.moveTo(px, py) else p.lineTo(px, py)
                    }
                } else {
                    p.moveTo(r.left, r.bottom)
                    p.quadTo(cx, r.top, r.right, r.bottom)
                }
            }
        }
        return p
    }

    private fun addRegularPolygon(path: Path, cx: Float, cy: Float, radius: Float, sides: Int) {
        for (i in 0 until sides) {
            val angle = Math.toRadians((i * 360.0 / sides) - 90.0)
            val px = (cx + cos(angle) * radius).toFloat()
            val py = (cy + sin(angle) * radius).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
    }

    private fun drawTextElement(canvas: Canvas, el: SlideElement) {
        val alphaInt = (el.opacity.coerceIn(0.05f, 1f) * 255).toInt()
        val rect = RectF(el.x, el.y, el.x + el.width, el.y + el.height)

        if (!el.fillColorHex.isNullOrBlank()) {
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
                color = parseColorSafe(el.fillColorHex, Color.TRANSPARENT)
                alpha = alphaInt
            }
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
        }

        if (el.borderWidth > 0f && !el.borderColorHex.isNullOrBlank()) {
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = el.borderWidth
                color = parseColorSafe(el.borderColorHex, Color.GRAY)
                alpha = alphaInt
            }
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)
        }

        if (el.text.isEmpty()) return

        val formattedLines = el.text.split("\n").mapIndexed { index, rawLine ->
            val indentPrefix = "    ".repeat(el.indentLevel.coerceIn(0, 5))
            val listPrefix = when (el.listType) {
                ListStyleType.NONE -> ""
                ListStyleType.BULLET -> "• "
                ListStyleType.NUMBERED -> "${index + 1}. "
            }
            "$indentPrefix$listPrefix$rawLine"
        }.joinToString("\n")

        val styleFlag = when {
            el.isBold && el.isItalic -> Typeface.BOLD_ITALIC
            el.isBold -> Typeface.BOLD
            el.isItalic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val baseTypeface = when {
            el.fontFamily.contains("Playfair", true) -> Typeface.SERIF
            el.fontFamily.contains("Mono", true) -> Typeface.MONOSPACE
            else -> Typeface.SANS_SERIF
        }

        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = parseColorSafe(el.textColorHex, Color.BLACK)
            alpha = alphaInt
            textSize = el.fontSize.coerceAtLeast(8f)
            typeface = Typeface.create(baseTypeface, styleFlag)
            isUnderlineText = el.isUnderline
            isStrikeThruText = el.isStrikethrough
        }

        val pad = el.textPadding.coerceAtLeast(4f)
        val availWidth = (el.width - pad * 2).toInt().coerceAtLeast(20)
        val align = when (el.textAlign) {
            TextAlignOption.LEFT -> Layout.Alignment.ALIGN_NORMAL
            TextAlignOption.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignOption.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
            TextAlignOption.JUSTIFY -> Layout.Alignment.ALIGN_NORMAL
        }

        val staticLayout = StaticLayout.Builder
            .obtain(formattedLines, 0, formattedLines.length, textPaint, availWidth)
            .setAlignment(align)
            .setLineSpacing(el.paragraphSpacing, el.lineSpacing.coerceAtLeast(0.8f))
            .setIncludePad(false)
            .build()

        val textH = staticLayout.height.toFloat()
        val startY = when (el.verticalAlign) {
            VerticalAlignOption.TOP -> el.y + pad
            VerticalAlignOption.MIDDLE -> el.y + ((el.height - textH) / 2f).coerceAtLeast(pad)
            VerticalAlignOption.BOTTOM -> (el.y + el.height - textH - pad).coerceAtLeast(el.y + pad)
        }

        canvas.save()
        canvas.clipRect(rect)
        if (!el.highlightColorHex.isNullOrBlank()) {
            val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = parseColorSafe(el.highlightColorHex, Color.YELLOW)
                alpha = 140
            }
            canvas.drawRoundRect(
                RectF(el.x + pad, startY, el.x + pad + availWidth, (startY + textH).coerceAtMost(rect.bottom)),
                4f, 4f, hlPaint
            )
        }
        canvas.translate(el.x + pad, startY)
        staticLayout.draw(canvas)
        canvas.restore()
    }

    private fun drawImageElement(canvas: Canvas, el: SlideElement) {
        val rect = RectF(el.x, el.y, el.x + el.width, el.y + el.height)
        val path = el.imagePath
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            alpha = (el.opacity.coerceIn(0.05f, 1f) * 255).toInt()
        }

        if (!path.isNullOrBlank() && File(path).exists()) {
            val bmp = decodeSampledBitmap(path, 1024, 1024)
            if (bmp != null) {
                val srcLeft = (bmp.width * el.cropLeft.coerceIn(0f, 0.45f)).toInt()
                val srcTop = (bmp.height * el.cropTop.coerceIn(0f, 0.45f)).toInt()
                val srcRight = (bmp.width * (1f - el.cropRight.coerceIn(0f, 0.45f))).toInt().coerceAtLeast(srcLeft + 1)
                val srcBottom = (bmp.height * (1f - el.cropBottom.coerceIn(0f, 0.45f))).toInt().coerceAtLeast(srcTop + 1)
                val srcRect = Rect(srcLeft, srcTop, srcRight, srcBottom)

                canvas.save()
                val sx = if (el.flipHorizontal) -1f else 1f
                val sy = if (el.flipVertical) -1f else 1f
                canvas.scale(sx, sy, rect.centerX(), rect.centerY())
                canvas.drawBitmap(bmp, srcRect, rect, paint)
                canvas.restore()
            }
        } else {
            paint.color = Color.parseColor("#E2E8F0")
            canvas.drawRoundRect(rect, 8f, 8f, paint)
        }

        if (el.borderWidth > 0f && !el.borderColorHex.isNullOrBlank()) {
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = el.borderWidth
                color = parseColorSafe(el.borderColorHex, Color.DKGRAY)
            }
            canvas.drawRect(rect, stroke)
        }
    }

    private fun drawTableElement(canvas: Canvas, el: SlideElement) {
        val rows = el.tableRows.coerceAtLeast(1)
        val cols = el.tableCols.coerceAtLeast(1)
        val cellW = el.width / cols
        val cellH = el.height / rows

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = el.borderWidth.coerceAtLeast(1.2f)
            color = parseColorSafe(el.borderColorHex ?: "#CBD5E1", Color.LTGRAY)
        }
        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = el.fontSize.coerceIn(10f, 28f)
        }

        for (r in 0 until rows) {
            if (r == 0 && el.tableMergedFirstRow) {
                val cellRect = RectF(el.x, el.y, el.x + el.width, el.y + cellH)
                bgPaint.color = parseColorSafe(el.tableHeaderBgHex, Color.parseColor("#1D4ED8"))
                canvas.drawRect(cellRect, bgPaint)
                canvas.drawRect(cellRect, borderPaint)
                val text = el.tableCells.getOrNull(0)?.getOrNull(0) ?: ""
                textPaint.color = parseColorSafe(el.tableHeaderTextHex, Color.WHITE)
                textPaint.typeface = Typeface.DEFAULT_BOLD
                drawSingleCellText(canvas, text, cellRect, textPaint)
                continue
            }
            for (c in 0 until cols) {
                val left = el.x + c * cellW
                val top = el.y + r * cellH
                val cellRect = RectF(left, top, left + cellW, top + cellH)

                bgPaint.color = when {
                    r == 0 -> parseColorSafe(el.tableHeaderBgHex, Color.parseColor("#1D4ED8"))
                    r % 2 == 1 -> parseColorSafe(el.tableRowBgHex, Color.WHITE)
                    else -> parseColorSafe(el.tableAltRowBgHex, Color.parseColor("#F1F5F9"))
                }
                canvas.drawRect(cellRect, bgPaint)
                canvas.drawRect(cellRect, borderPaint)

                val cellText = el.tableCells.getOrNull(r)?.getOrNull(c) ?: ""
                if (cellText.isNotEmpty()) {
                    textPaint.color = if (r == 0) {
                        parseColorSafe(el.tableHeaderTextHex, Color.WHITE)
                    } else {
                        parseColorSafe(el.textColorHex, Color.parseColor("#0F172A"))
                    }
                    textPaint.typeface = if (r == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    drawSingleCellText(canvas, cellText, cellRect, textPaint)
                }
            }
        }
    }

    private fun drawSingleCellText(canvas: Canvas, text: String, rect: RectF, paint: TextPaint) {
        canvas.save()
        canvas.clipRect(rect)
        val availW = (rect.width() - 12f).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, availW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        val ty = rect.top + ((rect.height() - layout.height) / 2f).coerceAtLeast(4f)
        canvas.translate(rect.left + 6f, ty)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawChartElement(canvas: Canvas, el: SlideElement) {
        val rect = RectF(el.x, el.y, el.x + el.width, el.y + el.height)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = parseColorSafe(el.fillColorHex ?: "#FFFFFF", Color.WHITE)
        }
        canvas.drawRoundRect(rect, 12f, 12f, bgPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            color = parseColorSafe(el.borderColorHex ?: "#E2E8F0", Color.LTGRAY)
        }
        canvas.drawRoundRect(rect, 12f, 12f, borderPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = parseColorSafe(el.textColorHex, Color.parseColor("#0F172A"))
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(el.chartTitle, rect.centerX(), rect.top + 26f, titlePaint)

        val plotLeft = rect.left + 48f
        val plotTop = rect.top + 42f
        val plotRight = rect.right - 24f
        val plotBottom = rect.bottom - if (el.showLegend) 52f else 32f
        val plotW = (plotRight - plotLeft).coerceAtLeast(40f)
        val plotH = (plotBottom - plotTop).coerceAtLeast(40f)

        val seriesList = el.chartSeries.ifEmpty {
            listOf(ChartSeries("Series 1", listOf(25f, 50f, 75f, 60f), "#1D4ED8"))
        }
        val maxVal = seriesList.flatMap { it.values }.maxOrNull()?.coerceAtLeast(1f) ?: 100f
        val categories = el.chartCategories.ifEmpty { listOf("A", "B", "C", "D") }

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 11f
            textAlign = Paint.Align.CENTER
        }

        if (el.chartKind == ChartKind.PIE || el.chartKind == ChartKind.DOUGHNUT) {
            val firstSeries = seriesList.first()
            val total = firstSeries.values.sum().coerceAtLeast(1f)
            val radius = min(plotW, plotH) * 0.42f
            val cx = (plotLeft + plotRight) / 2f
            val cy = (plotTop + plotBottom) / 2f
            val oval = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
            val sliceColors = listOf("#1D4ED8", "#0EA5E9", "#F59E0B", "#10B981", "#8B5CF6", "#EC4899")
            var startAngle = -90f
            val slicePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
            firstSeries.values.forEachIndexed { idx, value ->
                val sweep = (value / total) * 360f
                slicePaint.color = parseColorSafe(sliceColors[idx % sliceColors.size])
                canvas.drawArc(oval, startAngle, sweep, true, slicePaint)
                if (el.showDataLabels && sweep > 18f) {
                    val midRad = Math.toRadians((startAngle + sweep / 2f).toDouble())
                    val lx = (cx + cos(midRad) * radius * 0.65f).toFloat()
                    val ly = (cy + sin(midRad) * radius * 0.65f).toFloat()
                    labelPaint.color = Color.WHITE
                    canvas.drawText("${value.toInt()}", lx, ly + 4f, labelPaint)
                }
                startAngle += sweep
            }
            if (el.chartKind == ChartKind.DOUGHNUT) {
                slicePaint.color = parseColorSafe(el.fillColorHex ?: "#FFFFFF", Color.WHITE)
                canvas.drawCircle(cx, cy, radius * 0.5f, slicePaint)
            }
        } else {
            // Grid lines
            if (el.showGridLines) {
                val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#E2E8F0")
                    strokeWidth = 1f
                }
                for (g in 0..4) {
                    val gy = plotBottom - (g / 4f) * plotH
                    canvas.drawLine(plotLeft, gy, plotRight, gy, gridPaint)
                    labelPaint.textAlign = Paint.Align.RIGHT
                    labelPaint.color = Color.parseColor("#64748B")
                    canvas.drawText("${((maxVal * g) / 4f).toInt()}", plotLeft - 6f, gy + 4f, labelPaint)
                }
            }

            val catCount = categories.size.coerceAtLeast(1)
            val groupW = plotW / catCount
            labelPaint.textAlign = Paint.Align.CENTER

            categories.forEachIndexed { cIdx, catName ->
                val gx = plotLeft + cIdx * groupW + groupW / 2f
                canvas.drawText(catName, gx, plotBottom + 16f, labelPaint)
            }

            when (el.chartKind) {
                ChartKind.COLUMN -> {
                    val barW = (groupW * 0.68f) / seriesList.size.coerceAtLeast(1)
                    seriesList.forEachIndexed { sIdx, s ->
                        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = parseColorSafe(s.colorHex, Color.BLUE)
                        }
                        s.values.forEachIndexed { cIdx, v ->
                            if (cIdx < catCount) {
                                val bh = (v / maxVal) * plotH
                                val left = plotLeft + cIdx * groupW + groupW * 0.16f + sIdx * barW
                                val top = plotBottom - bh
                                canvas.drawRoundRect(RectF(left, top, left + barW - 2f, plotBottom), 4f, 4f, barPaint)
                                if (el.showDataLabels) {
                                    canvas.drawText("${v.toInt()}", left + barW / 2f, top - 4f, labelPaint)
                                }
                            }
                        }
                    }
                }
                ChartKind.BAR -> {
                    val rowH = plotH / catCount
                    val barH = (rowH * 0.68f) / seriesList.size.coerceAtLeast(1)
                    seriesList.forEachIndexed { sIdx, s ->
                        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = parseColorSafe(s.colorHex, Color.BLUE)
                        }
                        s.values.forEachIndexed { cIdx, v ->
                            if (cIdx < catCount) {
                                val bw = (v / maxVal) * plotW
                                val top = plotTop + cIdx * rowH + rowH * 0.16f + sIdx * barH
                                canvas.drawRoundRect(RectF(plotLeft, top, plotLeft + bw, top + barH - 2f), 4f, 4f, barPaint)
                            }
                        }
                    }
                }
                ChartKind.LINE, ChartKind.AREA, ChartKind.SCATTER -> {
                    seriesList.forEach { s ->
                        val sColor = parseColorSafe(s.colorHex, Color.BLUE)
                        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            style = Paint.Style.STROKE
                            strokeWidth = 3f
                            color = sColor
                        }
                        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            style = Paint.Style.FILL
                            color = sColor
                        }
                        val linePath = Path()
                        val areaPath = Path()
                        s.values.forEachIndexed { cIdx, v ->
                            if (cIdx < catCount) {
                                val px = plotLeft + cIdx * groupW + groupW / 2f
                                val py = plotBottom - (v / maxVal) * plotH
                                if (cIdx == 0) {
                                    linePath.moveTo(px, py)
                                    areaPath.moveTo(px, plotBottom)
                                    areaPath.lineTo(px, py)
                                } else {
                                    linePath.lineTo(px, py)
                                    areaPath.lineTo(px, py)
                                }
                                if (cIdx == s.values.lastIndex || cIdx == catCount - 1) {
                                    areaPath.lineTo(px, plotBottom)
                                    areaPath.close()
                                }
                                canvas.drawCircle(px, py, 4.5f, dotPaint)
                                if (el.showDataLabels) {
                                    canvas.drawText("${v.toInt()}", px, py - 8f, labelPaint)
                                }
                            }
                        }
                        if (el.chartKind == ChartKind.AREA) {
                            val areaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                style = Paint.Style.FILL
                                color = sColor
                                alpha = 55
                            }
                            canvas.drawPath(areaPath, areaPaint)
                        }
                        if (el.chartKind != ChartKind.SCATTER) {
                            canvas.drawPath(linePath, linePaint)
                        }
                    }
                }
                else -> {}
            }
        }

        if (el.showLegend) {
            var lx = rect.left + 24f
            val ly = rect.bottom - 14f
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            labelPaint.textAlign = Paint.Align.LEFT
            labelPaint.color = Color.parseColor("#334155")
            seriesList.forEach { s ->
                dotPaint.color = parseColorSafe(s.colorHex, Color.BLUE)
                canvas.drawCircle(lx, ly - 4f, 5f, dotPaint)
                canvas.drawText(s.name, lx + 10f, ly, labelPaint)
                lx += labelPaint.measureText(s.name) + 28f
            }
        }
    }

    fun exportToPdf(
        doc: PresentationDocument,
        outputStream: OutputStream,
        slideIndices: List<Int>? = null
    ) {
        val pdfDocument = PdfDocument()
        try {
            val pageW = doc.logicalWidth.toInt().coerceAtLeast(320)
            val pageH = doc.logicalHeight.toInt().coerceAtLeast(240)
            val indicesToExport = slideIndices ?: doc.slides.indices.toList()

            indicesToExport.forEachIndexed { pageIndex, slideIdx ->
                val slide = doc.slides.getOrNull(slideIdx) ?: return@forEachIndexed
                val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                renderSlideToCanvas(page.canvas, doc, slide, 1f)
                pdfDocument.finishPage(page)
            }
            pdfDocument.writeTo(outputStream)
        } finally {
            pdfDocument.close()
        }
    }

    fun saveSlideThumbnail(context: Context, doc: PresentationDocument, slide: SlideModel): String {
        val thumbDir = File(context.filesDir, "thumbnails").apply { mkdirs() }
        val outFile = File(thumbDir, "thumb_${doc.id}_${slide.id}.png")
        val bmp = renderSlideToBitmap(doc, slide, targetWidthPx = 480)
        FileOutputStream(outFile).use { fos ->
            bmp.compress(Bitmap.CompressFormat.PNG, 85, fos)
        }
        bmp.recycle()
        return outFile.absolutePath
    }

    private fun decodeSampledBitmap(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, options)
            var inSampleSize = 1
            if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
                val halfH = options.outHeight / 2
                val halfW = options.outWidth / 2
                while ((halfH / inSampleSize) >= reqHeight && (halfW / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(path, decodeOptions)
        } catch (_: Exception) {
            null
        }
    }
}
