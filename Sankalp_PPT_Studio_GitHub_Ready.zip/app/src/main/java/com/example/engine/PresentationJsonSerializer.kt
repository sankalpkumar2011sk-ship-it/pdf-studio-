package com.example.engine

import com.example.model.PresentationDocument
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object PresentationJsonSerializer {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val docAdapter = moshi.adapter(PresentationDocument::class.java)

    fun toJsonString(doc: PresentationDocument): String {
        return docAdapter.toJson(doc)
    }

    fun fromJsonString(jsonStr: String): PresentationDocument {
        return docAdapter.fromJson(jsonStr) ?: PresentationDocument()
    }
}
