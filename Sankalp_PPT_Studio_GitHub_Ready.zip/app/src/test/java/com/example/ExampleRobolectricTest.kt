package com.example

import com.example.data.TemplateCatalog
import com.example.engine.CorruptedPptxException
import com.example.engine.OoxmlPptxEngine
import com.example.engine.PresentationJsonSerializer
import com.example.engine.UnsupportedLegacyPptException
import com.example.model.*
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ExampleRobolectricTest {

    @Test
    fun testCasesAtoG_create5Slides_insertAllObjects_saveAndReopenValidOoxmlPptx() {
        val tempDir = Files.createTempDirectory("pptstudio_test").toFile()
        try {
            // Prepare a real PNG file on disk for Test Case C (Image embedding)
            val imgFile = File(tempDir, "test_slide_photo.png")
            imgFile.writeBytes(
                byteArrayOf(
                    0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
                    0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52
                )
            )

            // Test Case A: Create a new presentation with 5 slides
            val theme = BuiltInThemes.getById("professional_blue")
            val slide1 = TemplateCatalog.buildSlideFromLayout(SlideLayoutType.TITLE_SLIDE, theme, 1).copy(
                speakerNotes = "Opening slide notes"
            )

            // Test Case B: Add English & Hindi text, format it, resize it, and reposition it
            val textElement = SlideElement(
                type = ElementType.TEXT,
                x = 95f,
                y = 145f,
                width = 620f,
                height = 160f,
                text = "Quarterly Strategy Review\nडिजिटल इंडिया नवाचार",
                fontFamily = "Noto Sans Devanagari",
                fontSize = 28f,
                isBold = true,
                isItalic = true,
                isUnderline = true,
                textColorHex = "#1D4ED8",
                listType = ListStyleType.BULLET
            )
            val slide2 = SlideModel(
                layoutType = SlideLayoutType.TITLE_AND_CONTENT,
                elements = listOf(textElement)
            )

            // Test Case C: Insert an image, crop it, rotate it, and resize it
            val imageElement = SlideElement(
                type = ElementType.IMAGE,
                x = 180f,
                y = 110f,
                width = 420f,
                height = 290f,
                rotation = 15f,
                imagePath = imgFile.absolutePath,
                cropLeft = 0.1f,
                cropRight = 0.1f,
                flipHorizontal = true,
                borderColorHex = "#C43E1C",
                borderWidth = 3f
            )
            val slide3 = SlideModel(
                layoutType = SlideLayoutType.PICTURE_WITH_CAPTION,
                elements = listOf(imageElement)
            )

            // Test Case D: Insert shapes, a table, and a chart
            val shapeElement = SlideElement(
                type = ElementType.SHAPE,
                shapeKind = ShapeKind.STAR,
                x = 80f,
                y = 90f,
                width = 200f,
                height = 200f,
                fillColorHex = "#F59E0B",
                text = "Top KPI"
            )
            val tableElement = SlideElement(
                type = ElementType.TABLE,
                x = 320f,
                y = 90f,
                width = 540f,
                height = 220f,
                tableRows = 3,
                tableCols = 3,
                tableCells = listOf(
                    listOf("Metric", "Q3", "Q4"),
                    listOf("ARR", "USD 4.2M", "USD 5.8M"),
                    listOf("NPS", "64", "72")
                )
            )
            val chartElement = SlideElement(
                type = ElementType.CHART,
                chartKind = ChartKind.COLUMN,
                chartTitle = "Revenue Growth",
                chartCategories = listOf("Q1", "Q2", "Q3", "Q4"),
                chartSeries = listOf(
                    ChartSeries("ARR", listOf(3.1f, 3.8f, 4.2f, 5.8f), "#1D4ED8")
                ),
                x = 140f,
                y = 110f,
                width = 640f,
                height = 340f
            )
            val slide4 = SlideModel(layoutType = SlideLayoutType.TWO_CONTENT, elements = listOf(shapeElement, tableElement))
            val slide5 = SlideModel(layoutType = SlideLayoutType.CONTENT_WITH_IMAGE, elements = listOf(chartElement))

            val doc = PresentationDocument(
                name = "Boardroom Master Deck",
                aspectRatio = SlideAspectRatio.WIDESCREEN_16_9,
                themeId = "professional_blue",
                slides = listOf(slide1, slide2, slide3, slide4, slide5)
            )
            assertEquals(5, doc.slides.size)

            // Test Case E: Save the presentation as PPTX and verify OOXML package entries
            val pptxBytesOut = ByteArrayOutputStream()
            OoxmlPptxEngine.writePptx(doc, pptxBytesOut)
            val pptxBytes = pptxBytesOut.toByteArray()
            assertTrue("Exported PPTX must be non-empty", pptxBytes.size > 1024)

            val zipEntryNames = mutableSetOf<String>()
            ZipInputStream(ByteArrayInputStream(pptxBytes)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    zipEntryNames.add(entry.name)
                    entry = zis.nextEntry
                }
            }
            assertTrue(zipEntryNames.contains("[Content_Types].xml"))
            assertTrue(zipEntryNames.contains("_rels/.rels"))
            assertTrue(zipEntryNames.contains("ppt/presentation.xml"))
            assertTrue(zipEntryNames.contains("ppt/_rels/presentation.xml.rels"))
            for (i in 1..5) {
                assertTrue("Must contain slide$i.xml", zipEntryNames.contains("ppt/slides/slide$i.xml"))
                assertTrue("Must contain slide$i.xml.rels", zipEntryNames.contains("ppt/slides/_rels/slide$i.xml.rels"))
            }
            assertTrue("Must contain speaker notes slide", zipEntryNames.contains("ppt/notesSlides/notesSlide1.xml"))
            assertTrue("Must embed image media in ppt/media/", zipEntryNames.any { it.startsWith("ppt/media/image_") })

            // Test Case F & G: Reopen exported PPTX and check all supported objects are present and editable
            val mediaExtractDir = File(tempDir, "reopen_media")
            val reopened = OoxmlPptxEngine.readPptx(
                inputStream = ByteArrayInputStream(pptxBytes),
                fileName = "Boardroom Master Deck.pptx",
                mediaCacheDir = mediaExtractDir
            )
            assertEquals(5, reopened.slides.size)
            assertEquals("Opening slide notes", reopened.slides[0].speakerNotes)

            val reopenedText = reopened.slides[1].elements.first()
            assertTrue(reopenedText.text.contains("Quarterly Strategy Review"))
            assertTrue(reopenedText.text.contains("डिजिटल इंडिया नवाचार"))
            assertTrue(reopenedText.isBold)
            assertEquals(95f, reopenedText.x, 0.1f)

            val reopenedImg = reopened.slides[2].elements.first()
            assertEquals(ElementType.IMAGE, reopenedImg.type)
            assertEquals(15f, reopenedImg.rotation, 0.1f)
            assertEquals(0.1f, reopenedImg.cropLeft, 0.01f)
            assertNotNull(reopenedImg.imagePath)
            assertTrue(File(reopenedImg.imagePath!!).exists())

            val reopenedTable = reopened.slides[3].elements.first { it.type == ElementType.TABLE }
            assertEquals(3, reopenedTable.tableRows)
            assertEquals("USD 5.8M", reopenedTable.tableCells[1][2])

            val reopenedChart = reopened.slides[4].elements.first { it.type == ElementType.CHART }
            assertEquals("Revenue Growth", reopenedChart.chartTitle)
        } finally {
            tempDir.deleteRecursively()
        }
    }

    @Test
    fun testCasesHtoN_externalOoxmlImport_templates_autosaveJson_andErrorHandling() {
        val tempDir = Files.createTempDirectory("pptstudio_ext_test").toFile()
        try {
            // Verify all 21 templates in TemplateCatalog generate valid 5-slide decks
            assertTrue("Must have at least 20 templates", TemplateCatalog.TEMPLATES.size >= 20)
            val tplDoc = TemplateCatalog.createPresentationFromTemplate(TemplateCatalog.TEMPLATES.first())
            assertEquals(5, tplDoc.slides.size)

            val rawPptxOut = ByteArrayOutputStream()
            OoxmlPptxEngine.writePptx(tplDoc, rawPptxOut)

            // Test Case H & I: Strip ppt/tags/pptstudio_state.json to test pure external OOXML XML parsing (e.g. from MS PowerPoint)
            val pureOoxmlOut = ByteArrayOutputStream()
            ZipOutputStream(pureOoxmlOut).use { zos ->
                ZipInputStream(ByteArrayInputStream(rawPptxOut.toByteArray())).use { zis ->
                    var e = zis.nextEntry
                    while (e != null) {
                        if (e.name != "ppt/tags/pptstudio_state.json") {
                            zos.putNextEntry(ZipEntry(e.name))
                            zis.copyTo(zos)
                            zos.closeEntry()
                        }
                        e = zis.nextEntry
                    }
                }
            }
            val parsedExternal = OoxmlPptxEngine.readPptx(
                ByteArrayInputStream(pureOoxmlOut.toByteArray()),
                "ExternalDeck.pptx",
                File(tempDir, "ext_media")
            )
            assertEquals(5, parsedExternal.slides.size)
            assertTrue("Slide 1 from pure XML must have parsed elements", parsedExternal.slides[0].elements.isNotEmpty())
            assertTrue("Slide 4 from pure XML must have parsed table", parsedExternal.slides[3].elements.any { it.type == ElementType.TABLE })

            // Test Case L: Autosave & Crash Recovery JSON round-trip
            val jsonDraft = PresentationJsonSerializer.toJsonString(tplDoc.copy(name = "Crash Recovery Deck"))
            val recovered = PresentationJsonSerializer.fromJsonString(jsonDraft)
            assertEquals("Crash Recovery Deck", recovered.name)
            assertEquals(5, recovered.slides.size)

            // Error Handling: Legacy binary .ppt (OLE2 header D0 CF 11 E0) & Corrupted file
            val ole2Header = byteArrayOf(0xD0.toByte(), 0xCF.toByte(), 0x11.toByte(), 0xE0.toByte(), 0, 0, 0, 0)
            assertThrows(UnsupportedLegacyPptException::class.java) {
                OoxmlPptxEngine.readPptx(ByteArrayInputStream(ole2Header), "old.ppt", tempDir)
            }

            val corruptBytes = "not a zip file".toByteArray()
            assertThrows(CorruptedPptxException::class.java) {
                OoxmlPptxEngine.readPptx(ByteArrayInputStream(corruptBytes), "corrupt.pptx", tempDir)
            }
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
